"""카드뉴스 만들기 — 템플릿(static/cardnews_templates.json)에 글·사진을 넣어 1080×1080 그림(PNG)으로 저장.

그림은 이 컴퓨터의 크롬(없으면 엣지)을 화면 없이(headless) 띄워 찍습니다. 따로 설치할 것 없음.
유튜브 '게시물'은 유튜브가 바깥 프로그램에 올리는 길을 열어 주지 않아서, 저장한 그림을 스튜디오에서 직접 올립니다.
"""
import base64
import json
import mimetypes
import os
import re
import shutil
import subprocess
import tempfile
from datetime import datetime
from pathlib import Path

from .store import BASE
from . import setup

TPL_PATH = BASE / "static" / "cardnews_templates.json"
TMP = BASE / "data" / "card_tmp"


def templates():
    return json.loads(TPL_PATH.read_text(encoding="utf-8"))


def headless_browser():
    """그림 찍기에 쓸 브라우저 실행 파일"""
    c = setup.find_chrome()
    if c and c.endswith(".app"):
        c = str(Path(c) / "Contents" / "MacOS" / "Google Chrome")
    if c and Path(c).exists():
        return c
    if setup.IS_WIN:
        for base in (os.environ.get("PROGRAMFILES(X86)"), os.environ.get("PROGRAMFILES")):
            if base:
                p = Path(base) / "Microsoft" / "Edge" / "Application" / "msedge.exe"
                if p.exists():
                    return str(p)
    if setup.IS_MAC:
        p = Path("/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge")
        if p.exists():
            return str(p)
    for n in ("google-chrome", "chromium", "chromium-browser", "chrome"):
        if shutil.which(n):
            return shutil.which(n)
    return None


def find_ffmpeg():
    exe = shutil.which("ffmpeg")
    if exe:
        return exe
    fp = setup.find_ffprobe()
    if fp:
        p = Path(fp).with_name("ffmpeg" + (".exe" if setup.IS_WIN else ""))
        if p.exists():
            return str(p)
    return None


def _esc(t):
    t = str(t or "")
    t = t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    t = re.sub(r"\*([^*\n]+)\*", r"<b>\1</b>", t)  # *강조*
    return t.replace("\n", "<br>")


def rows_html(body, tpl):
    """목록·표 카드: 본문을 한 줄에 한 항목으로. '항목 : 내용' 또는 'A | B | C'. (화면 쪽 cnRows와 같은 규칙)"""
    lines = [x.strip() for x in str(body or "").split("\n") if x.strip()]
    n = max(len(lines), 1)
    per = (n + 1) // 2 if tpl.get("grid") else n
    fs = max(24, min(52, int(640 / (per * float(tpl.get("rowh", 1.75))))))
    out = []
    for i, ln in enumerate(lines):
        if "|" in ln:
            cols = [c.strip() for c in ln.split("|")]
        elif re.search(r"\s:\s|:\s", ln) and not tpl.get("cols"):
            a, b = re.split(r"\s*:\s+|\s+:\s*", ln, 1)
            cols = [a, b]
        else:
            cols = [ln]
        cols = (cols + ["", "", ""])[:3]
        cls = "r hd" if (tpl.get("hdr") and i == 0) else "r"
        out.append(f'<div class="{cls}">' + "".join(f'<span class="c{j + 1}">{_esc(c)}</span>' for j, c in enumerate(cols)) + "</div>")
    return f'<div class="rows" style="font-size:{fs}px">' + "".join(out) + "</div>"


def _fill(s, o, tpl=None):
    def rep(m):
        k = m.group(1)
        if k == "rows":
            return rows_html(o.get("body", ""), tpl or {})
        if re.match(r"^l[1-6]$", k):  # 본문의 n번째 줄 (이름표 등)
            ls = [x.strip() for x in str(o.get("body", "")).split("\n") if x.strip()]
            return _esc(ls[int(k[1]) - 1]) if len(ls) >= int(k[1]) else ""
        return _esc(o.get(k, ""))
    return re.sub(r"\{(\w+)\}", rep, s)


def _scope_css(css):
    """템플릿 CSS의 선택자 앞에 .c 를 붙임 (원본 템플릿 페이지와 같은 방식)"""
    def rep(m):
        a, sel = m.group(1), m.group(2)
        out = []
        for x in sel.split(","):
            x = x.strip()
            out.append(x if re.match(r"^\.c(?![\w-])", x) else ".c " + x)
        return a + ",".join(out) + "{"
    return re.sub(r"(^|\})\s*([^{}]+)\{", rep, css)


def _img_css(path_or_css):
    """사진 경로 → CSS 배경값 (그림 파일에 직접 넣어서 인터넷 없이도 보이게)"""
    v = str(path_or_css or "")
    if not v:
        return None
    if v.startswith("linear-gradient") or v.startswith("url("):
        return v
    p = Path(v)
    if not p.is_file():
        return None
    mt = mimetypes.guess_type(p.name)[0] or "image/jpeg"
    return f"url('data:{mt};base64,{base64.b64encode(p.read_bytes()).decode()}')"


def card_html(tpl, kind, fields, img, fonts, pos="center", dim=0, color="", imgs=None):
    PH = ["linear-gradient(160deg,#8aa4c8,#2c3e5c)", "linear-gradient(160deg,#e7b9a5,#6b3b3b)",
          "linear-gradient(160deg,#a5d6c1,#24524a)", "linear-gradient(160deg,#cdb6e6,#3d2b5c)"]
    ph = _img_css(img) or PH[int(tpl.get("no", 0)) % 4]  # 사진이 없으면 처음 38종의 기본 그림(색 바탕)
    extra = ""
    for i, x in enumerate((imgs or [])[:3]):  # 사진을 여러 장 쓰는 모양(--img2~4)
        v = _img_css(x)
        if v:
            extra += f";--img{i + 2}:{v}"
    links = "\n".join(f'<link href="{f}" rel="stylesheet">' for f in fonts)
    body = _fill(tpl[kind], fields, tpl)
    return f"""<!doctype html><html lang="ko"><head><meta charset="utf-8">{links}<style>
html,body{{margin:0;padding:0;width:1080px;height:1080px;overflow:hidden;background:#000}}
body{{font-family:Pretendard,sans-serif}}
.c{{position:relative;width:1080px;height:1080px;overflow:hidden;box-sizing:border-box;word-break:keep-all}}
.c .ph{{background:var(--img);background-size:cover;background-position:var(--pos,center)}}
.c .ph::after{{content:"";position:absolute;inset:0;background:rgba(0,0,0,var(--dim,0))}}
{_scope_css(tpl["css"])}</style></head><body><div class="c" style="--img:{ph}{extra};--pos:{pos if pos in ("top", "center", "bottom") else "center"};--dim:{max(0.0, min(0.8, float(dim or 0)))}{(";--bgc:" + color) if re.match(r"^#[0-9a-fA-F]{6}$", str(color or "")) else ""}">{body}</div></body></html>"""


class _WS:
    """아주 작은 웹소켓 클라이언트 (크롬 DevTools와 이야기하는 용도, 따로 설치할 것 없음)"""
    def __init__(self, url, timeout=60):
        import socket
        import urllib.parse
        u = urllib.parse.urlparse(url)
        self.s = socket.create_connection((u.hostname, u.port), timeout=timeout)
        key = base64.b64encode(os.urandom(16)).decode()
        req = (f"GET {u.path} HTTP/1.1\r\nHost: {u.hostname}:{u.port}\r\nUpgrade: websocket\r\n"
               f"Connection: Upgrade\r\nSec-WebSocket-Key: {key}\r\nSec-WebSocket-Version: 13\r\n\r\n")
        self.s.sendall(req.encode())
        buf = b""
        while b"\r\n\r\n" not in buf:
            ch = self.s.recv(4096)
            if not ch:
                raise RuntimeError("크롬 연결 실패")
            buf += ch
        self.rest = buf.split(b"\r\n\r\n", 1)[1]
        self.n = 0

    def _recv_exact(self, n):
        while len(self.rest) < n:
            ch = self.s.recv(1 << 20)
            if not ch:
                raise RuntimeError("크롬 연결이 끊겼어요")
            self.rest += ch
        out, self.rest = self.rest[:n], self.rest[n:]
        return out

    def send(self, obj):
        import struct
        data = json.dumps(obj).encode()
        hdr = bytearray([0x81])
        n = len(data)
        if n < 126:
            hdr.append(0x80 | n)
        elif n < 65536:
            hdr.append(0x80 | 126); hdr += struct.pack(">H", n)
        else:
            hdr.append(0x80 | 127); hdr += struct.pack(">Q", n)
        mask = os.urandom(4)
        hdr += mask
        self.s.sendall(bytes(hdr) + bytes(b ^ mask[i % 4] for i, b in enumerate(data)))

    def recv(self):
        import struct
        msg = b""
        while True:
            b1, b2 = self._recv_exact(2)
            n = b2 & 0x7F
            if n == 126:
                n = struct.unpack(">H", self._recv_exact(2))[0]
            elif n == 127:
                n = struct.unpack(">Q", self._recv_exact(8))[0]
            if b2 & 0x80:
                self._recv_exact(4)
            payload = self._recv_exact(n)
            op = b1 & 0x0F
            if op == 8:
                raise RuntimeError("크롬 연결이 끊겼어요")
            if op in (0, 1, 2):
                msg += payload
                if b1 & 0x80:
                    return json.loads(msg.decode("utf-8", "ignore"))

    def call(self, method, params=None):
        self.n += 1
        my = self.n
        self.send({"id": my, "method": method, "params": params or {}})
        while True:
            m = self.recv()
            if m.get("id") == my:
                if "error" in m:
                    raise RuntimeError(str(m["error"]))
                return m.get("result", {})

    def close(self):
        try:
            self.s.close()
        except Exception:
            pass


class Shooter:
    """크롬(엣지)을 화면 없이 한 번 띄워 놓고 카드를 한 장씩 그림으로 찍음"""
    def __init__(self, browser):
        import time
        import urllib.request
        self.prof = tempfile.mkdtemp(prefix="cardshot_")
        cmd = [browser, "--headless=new", "--disable-gpu", "--hide-scrollbars", "--no-first-run",
               "--no-default-browser-check", "--disable-extensions", "--disable-background-networking",
               "--disable-component-update", "--disable-sync", f"--user-data-dir={self.prof}",
               "--remote-debugging-port=0", "--remote-allow-origins=*", "about:blank"]
        if hasattr(os, "geteuid") and os.geteuid() == 0:
            cmd.insert(1, "--no-sandbox")
        kw = {"creationflags": 0x08000000} if setup.IS_WIN else {}
        self.proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, **kw)
        port_file = Path(self.prof) / "DevToolsActivePort"
        port = None
        for _ in range(150):
            if port_file.exists():
                try:
                    port = int(port_file.read_text().split()[0])
                    break
                except Exception:
                    pass
            time.sleep(0.1)
        if not port:
            self.close()
            raise RuntimeError("그림 만들 크롬을 켜지 못했어요")
        self.port = port
        tabs = []
        for _ in range(50):
            try:
                with urllib.request.urlopen(f"http://127.0.0.1:{port}/json/list", timeout=3) as r:
                    tabs = [t for t in json.loads(r.read()) if t.get("type") == "page"]
                if tabs:
                    break
            except Exception:
                pass
            time.sleep(0.1)
        if not tabs:
            self.close()
            raise RuntimeError("그림 만들 크롬 창을 찾지 못했어요")
        self.ws = _WS(tabs[0]["webSocketDebuggerUrl"])
        self.ws.call("Emulation.setDeviceMetricsOverride",
                     {"width": 1080, "height": 1080, "deviceScaleFactor": 1, "mobile": False})

    def shot(self, html_path, png_path):
        import time
        self.ws.call("Page.navigate", {"url": Path(html_path).resolve().as_uri()})
        # 글꼴·사진이 다 뜰 때까지 기다림 (최대 15초)
        js = ("new Promise(r=>{const t=setTimeout(()=>r('t'),15000);"
              "const go=()=>Promise.all([document.fonts.ready,...[...document.images].map(i=>i.decode().catch(()=>0))])"
              ".then(()=>{clearTimeout(t);setTimeout(()=>r('ok'),300)});"
              "if(document.readyState==='complete')go();else addEventListener('load',go)})")
        for _ in range(3):
            try:
                self.ws.call("Runtime.evaluate", {"expression": js, "awaitPromise": True})
                break
            except Exception:
                time.sleep(0.5)
        r = self.ws.call("Page.captureScreenshot", {"format": "png",
                         "clip": {"x": 0, "y": 0, "width": 1080, "height": 1080, "scale": 1}})
        Path(png_path).write_bytes(base64.b64decode(r["data"]))
        return Path(png_path).stat().st_size > 1000

    def close(self):
        try:
            self.ws.close()
        except Exception:
            pass
        try:
            self.proc.kill()
            self.proc.wait(timeout=10)
        except Exception:
            pass
        shutil.rmtree(self.prof, ignore_errors=True)


def safe(t, n=40):
    t = re.sub(r'[\\/:*?"<>|\n\r\t]', " ", str(t or "")).strip()
    return re.sub(r"\s+", " ", t)[:n] or "카드뉴스"


def render(channel, tpl_no, cards, title, out_root, color=""):
    """cards: [{kind: cover|mid|end, fields:{...}, img: 경로}] → out_root/카드뉴스/날짜_제목/01.png …"""
    D = templates()
    tpl = next((t for t in D["T"] if int(t["no"]) == int(tpl_no)), None)
    if not tpl:
        raise ValueError("템플릿을 찾을 수 없어요")
    browser = headless_browser()
    if not browser:
        raise RuntimeError("그림을 만들려면 크롬(또는 엣지)이 있어야 해요")
    out = Path(out_root) / "카드뉴스" / f"{datetime.now():%Y%m%d_%H%M}_{safe(title)}"
    out.mkdir(parents=True, exist_ok=True)
    work = Path(tempfile.mkdtemp(prefix="cardnews_"))
    made = []
    sh = Shooter(browser)
    try:
        for i, c in enumerate(cards, 1):
            kind = c.get("kind") if c.get("kind") in ("cover", "mid", "end") else "mid"
            f = dict(D.get("S", {}))
            f.update({k: v for k, v in (c.get("fields") or {}).items() if v is not None})
            f["ch"] = (c.get("fields") or {}).get("ch") or channel
            f["pg"] = f"{i} / {len(cards)}"
            f["n"] = f"{max(i - 1, 1):02d}"
            h = work / f"{i:02d}.html"
            h.write_text(card_html(tpl, kind, f, c.get("img"), D.get("FONTS", []), c.get("pos") or "center", c.get("dim") or 0, color, c.get("imgs")), encoding="utf-8")
            png = out / f"{i:02d}.png"
            if not sh.shot(h, png):
                raise RuntimeError(f"{i}번째 장을 그림으로 만들지 못했어요")
            made.append(str(png))
    finally:
        sh.close()
        shutil.rmtree(work, ignore_errors=True)
    return {"folder": str(out), "files": made}


def frames(video_file, n=6, thumb=None):
    """영상에 어울리는 사진 고르기: ① 내가 만든 썸네일 먼저 ② 영상 여러 곳에서 장면을 넉넉히 뽑아
    너무 어둡거나 밋밋한 장면·서로 똑같은 장면은 빼고 서로 다른 장면 n장."""
    ff = find_ffmpeg()
    TMP.mkdir(parents=True, exist_ok=True)
    stem = safe(Path(video_file).stem, 30).replace(" ", "_")
    out = []
    if thumb and Path(thumb).is_file():
        t = TMP / f"{stem}_썸네일{Path(thumb).suffix.lower() or '.jpg'}"
        try:
            shutil.copy2(thumb, t)
            out.append(str(t))
        except Exception:
            pass
    if not ff:
        if out:
            return out
        raise RuntimeError("장면을 뽑으려면 ffmpeg가 필요해요 (설정 → 영상 검사 도구 설치)")
    dur = 0.0
    fp = setup.find_ffprobe()
    if fp:
        try:
            r = subprocess.run([fp, "-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1",
                                str(video_file)], capture_output=True, timeout=30)
            dur = float(r.stdout.decode().strip() or 0)
        except Exception:
            dur = 0.0
    kw = {"creationflags": 0x08000000} if setup.IS_WIN else {}
    cand = []  # (경로, 밝기, 뚜렷함, 작은그림)
    m = max(n * 3, 12)
    for i in range(m):
        t = (dur * (i + 0.5) / m) if dur > 0 else (i * 2 + 1)
        p = TMP / f"{stem}_{i + 1:02d}.jpg"
        try:
            r = subprocess.run([ff, "-y", "-v", "error", "-ss", f"{t:.2f}", "-i", str(video_file),
                                "-map", "0:v:0", "-frames:v", "1", "-vf", "scale=1080:-2", "-q:v", "2", str(p),
                                "-map", "0:v:0", "-frames:v", "1", "-vf", "scale=16:16,format=gray",
                                "-f", "rawvideo", "-"], capture_output=True, timeout=60, **kw)
        except Exception:
            continue
        g = r.stdout[:256]
        if not (p.exists() and p.stat().st_size > 0 and len(g) == 256):
            continue
        mean = sum(g) / 256.0
        sd = (sum((x - mean) ** 2 for x in g) / 256.0) ** 0.5
        cand.append((str(p), mean, sd, g))
    good = [c for c in cand if 28 < c[1] < 240 and c[2] > 14] or cand
    picked = []
    def dist(a, b):
        return sum(abs(x - y) for x, y in zip(a, b)) / 256.0
    for c in sorted(good, key=lambda c: -c[2]):  # 뚜렷한 장면부터, 이미 고른 것과 비슷하면 건너뜀
        if all(dist(c[3], q[3]) > 12 for q in picked):
            picked.append(c)
        if len(picked) >= n:
            break
    keep = {c[0] for c in picked}
    for c in cand:
        if c[0] not in keep:
            try:
                os.remove(c[0])
            except Exception:
                pass
    out += [c[0] for c in sorted(picked, key=lambda c: c[0])]
    if not out:
        raise RuntimeError("장면을 뽑지 못했어요")
    return out


def is_landscape(video_file):
    """가로 영상인지 (가로 영상은 정사각형에 꽉 채우면 양옆이 잘려요)"""
    fp = setup.find_ffprobe()
    if not fp:
        return False
    try:
        kw = {"creationflags": 0x08000000} if setup.IS_WIN else {}
        r = subprocess.run([fp, "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height",
                            "-of", "csv=p=0:s=x", str(video_file)], capture_output=True, timeout=30, **kw)
        w, h = [int(x) for x in r.stdout.decode().strip().split("x")[:2]]
        return w > h * 1.2
    except Exception:
        return False


def ai_text(channel, topic, pages, video=None, style=""):
    """Claude로 카드뉴스 글 채우기 → {tag, t1, t2, pages:[{m1,m2,body}], e1, e2}"""
    from . import claude_ai
    src = ""
    if video:
        src += f"\n영상 제목: {video.get('title','')}\n영상 설명: {(video.get('description') or '')[:800]}"
        try:
            sc = claude_ai.find_script(video.get("file", ""))
            if sc:
                src += f"\n대본: {sc[:6000]}"
        except Exception:
            pass
    prompt = f"""너는 유튜브 채널 게시물(카드뉴스)로 시청자를 채널로 끌어오는 일을 10년 한 카피라이터야.
목표는 하나: 이 카드뉴스를 본 사람이 "뒷이야기가 궁금해서" 채널에 들어와 영상을 보게 만드는 것.

채널: {channel} {('· 채널 스타일: ' + style) if style else ''}
내용 메모: {topic or '(아래 영상 내용으로)'}{src}

쓰는 법:
1. 위 자료에서 가장 궁금증을 일으키는 '진짜 내용'(누가·무슨 일·어떤 갈등/반전/숫자)을 찾아. 자료에 없는 사실은 지어내지 마.
2. 첫 장(표지)은 스크롤을 멈추게 해야 해. t1=상황을 구체적으로(28자 이내, 예: "언니한텐 7억 집을 5억에 넘기고 저한텐 지방 집 사 준다는 부모님"),
   t2=가장 센 한마디·대사(12자 이내, 예: "기껏 키워 놨더니…"), body=다음 장을 넘기게 하는 한 줄(20자 이내, 예: "거절하자 돌아온 말은…").
   "충격", "대박", "화제" 같은 빈말, 내용 없는 감탄은 금지. 구체적인 사람·상황·숫자·대사로.
3. 중간 장 {pages}장은 이야기를 차례로 풀어. 각 장 m1(소제목 14자 이내), m2(강조 낱말 8자 이내, 없어도 됨),
   body(그 장의 이야기 2~3문단, 문단 사이는 \n\n, 합쳐서 150자 이내, 쉬운 말로, 말하듯이).
   한 장에 한 장면만. 마지막 중간 장은 결말 직전, 가장 궁금한 데서 끊어. 결말·반전의 답은 절대 쓰지 마.
4. 마지막 장: e1=시청자에게 던지는 질문이나 "과연 결말은?"(18자 이내), e2=강조 한마디(10자 이내).
5. kind: 넘겨 읽는 이야기가 좋으면 "story", 사진(장면) 자체가 볼거리면 "photo",
   한 장에 정리해 보여 주는 게 좋으면(순위·목록·비교·시간순·발언 모음·숫자) "list".
5-1. list: 같은 내용을 '한 장 정리'로도 써 줘. lt1=제목 첫 줄(14자 이내), lt2=제목 강조 줄(14자 이내),
   rows=6~9줄, 한 줄에 한 항목, "항목 : 내용" 꼴(각 줄 26자 이내), 줄마다 가장 중요한 낱말 하나를 *별표*로 감싸.
   table=비교할 게 있으면 첫 줄은 칸 이름, 그다음 줄들은 "왼쪽 | 가운데(관계·차이) | 오른쪽" 꼴 5~7줄(없으면 빈 배열).
   음악 플레이리스트·모음 영상이면 rows는 곡(항목) 목록으로("곡명 : 가수"), 제목은 언제·어떤 기분에 듣는지.
   자료에 있는 사실만. 실존 인물은 자료에 없는 관계·발언·숫자를 절대 지어내지 마.
6. post: 게시물에 같이 올릴 글. 첫 줄은 궁금증 한 줄, 둘째 줄은 "전체 이야기는 채널 영상에서 볼 수 있어요" 같은 안내, 마지막 줄 해시태그 3개.
7. tag: 2~4글자 말머리(사연, 줄거리, 명장면 등).
말투는 친근하게, 거짓·과장·낚시 금지(카드에 쓴 내용은 영상에 실제로 있어야 함).
다른 말 없이 JSON 한 개만: {{"kind":"story","tag":"","t1":"","t2":"","body":"","pages":[{{"m1":"","m2":"","body":""}}],"e1":"","e2":"","post":"","list":{{"lt1":"","lt2":"","rows":[""],"table":[""]}}}}"""
    d = claude_ai._extract_json(claude_ai._run_claude("claude", prompt, timeout=180))
    d["pages"] = (d.get("pages") or [])[:pages]
    return d


# ───────── 어울리는 템플릿 추천 ─────────
GENRES = [
    ("정치·시사", ["정치", "국회", "대통령", "선거", "여당", "야당", "의원", "장관", "외교", "정상회의", "뉴스", "이슈",
               "속보", "경제", "사건", "사고", "시사", "단독", "논란", "발언"], [1, 7, 2, 8, 4, 3, 6, 29, 30, 27]),
    ("해외·모음", ["해외", "외국", "미국", "일본", "중국", "유럽", "세계", "반응", "짜집기", "모음", "레전드", "해외반응",
               "월드", "글로벌"], [17, 3, 16, 1, 29, 31, 5, 28, 7]),
    ("음악·플레이리스트", ["플레이리스트", "playlist", "플리", "r&b", "알앤비", "노래", "음악", "발라드", "힙합", "재즈",
                    "팝송", "가수", "앨범", "듣기", "bgm", "lofi", "감성", "트로트"], [15, 9, 5, 14, 11, 12, 26, 17]),
    ("드라마", ["드라마", "드짜", "중드", "영드", "한드", "일드", "미드", "웹드", "줄거리", "회차", "명장면", "로맨스",
             "주인공", "결말", "남주", "여주", "영화"], [26, 17, 3, 5, 22, 4, 1, 24, 6, 19, 27]),
    ("연예·아이돌", ["아이돌", "kpop", "케이팝", "무대", "뮤직뱅크", "콘서트", "연예", "컴백", "팬", "배우", "스타"],
     [9, 11, 14, 15, 13, 12, 10, 22]),
    ("예능·웃음", ["예능", "웃긴", "브이로그", "vlog", "먹방", "챌린지", "몰카", "썰", "ㅋㅋ", "유머"],
     [16, 17, 18, 21, 22, 23, 20, 31, 19]),
    ("정보·공부", ["정보", "꿀팁", "공부", "영어", "강의", "건강", "재테크", "요리", "레시피", "리뷰", "비교", "방법",
               "top", "순위", "추천", "mbti", "심리"], [28, 32, 30, 29, 18, 25, 33, 34, 35, 36, 37, 38]),
]
# 분야별로 어울리는 새 모양(39~59)
EXTRA = {
    "정치·시사": [57, 58, 53, 54, 44, 59, 51],
    "해외·모음": [54, 55, 57, 47, 39, 43, 52],
    "음악·플레이리스트": [39, 40, 48, 55, 52, 50],
    "드라마": [42, 43, 45, 58, 47, 48, 41, 40],
    "연예·아이돌": [39, 48, 53, 55, 40, 58],
    "예능·웃음": [45, 41, 50, 52, 48, 49],
    "정보·공부": [51, 52, 56, 59, 55, 49, 46, 54],
}
GENRE_NAMES = [g[0] for g in GENRES]

# 사진에 글씨가 많아도 글이 또렷한 모양 (상자·단색 바탕)
CLEAR = [6, 36, 2, 37, 34, 27, 38, 35, 33, 7]
# 사진과 글 자리가 따로라 사진이 가려지지 않는 모양
SEP = [11, 18, 16, 14, 25, 8, 24]


# 가로 영상이어도 사진이 잘리지 않는 모양(사진 칸이 가로이거나 사진을 안 씀)
LAND_OK = {2, 8, 10, 11, 13, 14, 16, 20, 23, 24, 25, 27, 28, 30, 31, 32, 33, 34, 35, 36, 37, 38,
           39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59}


def suggest(channel_cfg, titles, focus="", kind="", land=False):
    """이번 카드뉴스 내용(focus: 영상 제목·주제·글)을 먼저 보고, 채널 이름·최근 제목을 참고해 5개 추천.
    부를 때마다 조금씩 다르게: 사진이 안 가려지는 모양 2 + 그 분야 사진형 2 + 글이 또렷한 모양 1."""
    import random
    ftxt = str(focus or "").lower()
    ctxt = " ".join([channel_cfg.get("name", ""), channel_cfg.get("style", "")] + list(titles or [])).lower()
    best, score = None, 0
    for g in GENRES:
        # 고른 채널(이름·스타일·최근 영상 제목)을 먼저 보고, 이번 내용은 참고
        sc = sum(ctxt.count(k) for k in g[1]) * 3 + sum(ftxt.count(k) for k in g[1])
        if sc > score:
            best, score = g, sc
    fixed = channel_cfg.get("card_genre")
    if fixed in GENRE_NAMES:  # 채널 분야를 직접 정해 둔 경우
        best = next(g for g in GENRES if g[0] == fixed)
    if not best:
        best = ("두루두루", [], [17, 5, 1, 26, 18, 3, 22, 28, 36, 6])
    pool1 = list(best[2])
    if land:  # 가로 영상: 양옆이 잘리는 모양은 빼고, 모자라면 가로 영상용으로 채움
        pool1 = [n for n in pool1 if n in LAND_OK]
        pool1 += [n for n in [11, 16, 14, 8, 25, 2, 28] if n not in pool1]
    orig = random.sample(pool1, min(4, len(pool1)))  # 처음 38종 중 이 채널에 어울리는 것
    extra = list(EXTRA.get(best[0], [42, 51, 40, 41, 52, 43]))  # 새 모양 중 이 채널에 어울리는 것
    if land:
        extra = [n for n in extra if n in LAND_OK] or [40, 47, 42, 51]
        if 40 not in extra:
            extra.append(40)
    more = random.sample(extra, min(4, len(extra)))
    if land and 40 not in more:
        more[0] = 40  # 사진 전체가 다 보이는 모양은 꼭 하나
    return {"genre": best[0], "nos": orig + more, "pool": best[2] + EXTRA.get(best[0], [])}

