"""나만의 자동 업로더 — 실행: python app.py  →  브라우저에서 http://127.0.0.1:5577"""
import os
import threading
import time
import webbrowser
from datetime import datetime
from pathlib import Path

from flask import Flask, abort, jsonify, request, send_file, send_from_directory

from uploader import claude_ai, engine, gdrive, growth, setup, updater, youtube
from uploader.store import (BASE, add_alert, add_log, edit, get_channel, load_config,
                            load_state, save_config)

app = Flask(__name__, static_folder=None)
PORT = 5577
_connecting = {}
_conn_gen = {}


def ok(**kw):
    return jsonify({"ok": True, **kw})


def err(msg, code=400):
    return jsonify({"ok": False, "error": str(msg)}), code


@app.get("/")
def index():
    return send_from_directory(BASE / "static", "index.html")


BOOT_ID = f"{os.getpid()}-{int(time.time())}"


@app.get("/api/ping")
def api_ping():
    """켜져 있는 업로더가 어느 것인지 (업데이트로 새로 켜지면 값이 바뀜)"""
    return jsonify({"boot": BOOT_ID, "version": updater.version()})


@app.get("/api/state")
def api_state():
    if request.args.get("ui"):  # 화면(창)이 열려 있음 → 업데이트 뒤 다시 켤 때 창도 다시 열기
        updater.LAST_UI = time.time()
    cfg = load_config()
    st = load_state()
    today = datetime.now().strftime("%Y-%m-%d")
    channels = []
    for ch in cfg["channels"]:
        files = engine.scan_channel(ch, st)
        vids = [v for v in st["videos"].values() if v["channel"] == ch["name"]]
        free = sum(1 for f in files if f["stage"] == "free")
        g = ((st.get("gdrive") or {}).get(ch["name"]) or {}) if ch.get("gdrive") else {}
        drive_left = int(g.get("left") or 0)
        waiting = sum(1 for v in vids if v["stage"] in ("basket", "queued", "uploading", "review", "check"))
        done = sum(1 for v in vids if v["stage"] in ("scheduled", "published"))
        per_day = len(engine._times(ch))
        taken = engine._taken(st, ch["name"])
        now_hm = datetime.now().strftime("%H:%M")
        today_left = sum(1 for hh, mm in engine._times(ch)
                         if f"{hh:02d}:{mm:02d}" > now_hm and f"{today}T{hh:02d}:{mm:02d}" not in taken)
        channels.append({
            **ch,
            "connected": youtube.is_connected(ch["name"]),
            "connecting": _connecting.get(ch["name"], ""),
            "info": (st["channel_info"].get(ch["name"]) or {}) if (st["channel_info"].get(ch["name"]) or {}).get("title") else None,
            "folder_ok": bool(ch.get("folder")) and Path(ch["folder"]).is_dir(),
            "files": files,
            "free": free,
            "waiting": waiting,
            "done": done,
            "per_day": per_day,
            "today_left": today_left,
            "stock_days": round((free + waiting + drive_left) / per_day, 1) if per_day else 0,
            "drive_left": drive_left,
            "drive_error": g.get("error", ""),
            "drive_error_url": g.get("error_url", ""),
            "today_uploaded": sum(1 for v in vids if (v.get("uploaded_at") or "").startswith(today)),
            "reserved": sum(1 for v in vids if v["stage"] in ("queued", "uploading", "review", "check", "scheduled")),
            "stock": free + drive_left,
            # 왕관은 지금까지 달성한 가장 높은 단계로 계속 유지
            "tier": int((st["channel_info"].get(ch["name"]) or {}).get("best_tier") or 0),
            "tier_now": int((st["channel_info"].get(ch["name"]) or {}).get("tier") or 0),
            "shine": growth.shining(st["channel_info"].get(ch["name"]) or {}),  # 달성 후 24시간 반짝임
            "celebrate": int((st["channel_info"].get(ch["name"]) or {}).get("best_tier") or 0)
                         > int((st["channel_info"].get(ch["name"]) or {}).get("celebrated") or 0),  # 축하 창 1번
            "ypp": (st["channel_info"].get(ch["name"]) or {}).get("ypp"),
            "views": (st["channel_info"].get(ch["name"]) or {}).get("views"),
            "rule_count": growth.rule_count((st["channel_info"].get(ch["name"]) or {}).get("views") or 0, cfg),
        })
    # 2차 수창 → 1차 수창 → 나머지 순서로 (같은 단계는 원래 순서)
    channels.sort(key=lambda c: -c["tier"])
    safe_cfg = {k: v for k, v in cfg.items() if k not in ("channels", "notify")}
    safe_cfg["daily_count_rules"] = cfg.get("daily_count_rules")
    safe_cfg["ypp"] = cfg.get("ypp")
    safe_cfg["humanize"] = cfg.get("humanize")
    safe_cfg["notify"] = {**cfg["notify"], "smtp_app_password": "●●●●" if cfg["notify"].get("smtp_app_password") else ""}
    return jsonify({
        "now": datetime.now().strftime("%Y-%m-%dT%H:%M:%S"),
        "night": engine.is_night(cfg),
        "busy": engine.busy(),
        "client_secret": youtube.has_client_secret(),
        "config": safe_cfg,
        "channels": channels,
        "videos": sorted(st["videos"].values(), key=lambda v: v.get("added", ""), reverse=True),
        "alerts": [a for a in st["alerts"] if not a["ack"]],
        "log": st["log"][:200],
    })


@app.get("/static/<path:name>")
def static_files(name):
    return send_from_directory(BASE / "static", name)


@app.get("/media")
def media():
    """채널 폴더 안의 썸네일만 보여줌"""
    p = Path(request.args.get("p", "")).resolve()
    cfg = load_config()
    for ch in cfg["channels"]:
        if ch.get("folder") and str(p).startswith(str(Path(ch["folder"]).resolve())) and p.is_file():
            return send_file(p)
    abort(404)


@app.post("/api/basket")
def api_basket():
    d = request.json
    n = engine.add_to_basket(d["channel"], d.get("paths", []))
    return ok(msg=f"{n}개 골랐습니다")


@app.post("/api/launch")
def api_launch():
    d = request.json or {}
    n = engine.launch(ids=d.get("ids"), channel=d.get("channel"))
    return ok(msg=f"{n}개 업로드 대기로 넘겼습니다" if n else "고른 영상이 없습니다")


@app.post("/api/video/edit")
def api_video_edit():
    d = request.json
    engine.update_video(d["id"], d.get("title"), d.get("description"),
                        d.get("tags"), d.get("publish_at"))
    return ok(msg="저장했습니다")


@app.post("/api/video/action")
def api_video_action():
    d = request.json
    try:
        return ok(msg=engine.video_action(d["id"], d["action"]))
    except Exception as e:
        return err(e)


@app.post("/api/alert/ack")
def api_alert_ack():
    d = request.json or {}
    with edit() as st:
        for a in st["alerts"]:
            if d.get("all") or a["id"] == d.get("id"):
                a["ack"] = True
    return ok()


@app.post("/api/channel/save")
def api_channel_save():
    d = request.json
    cfg = load_config()
    name = (d.get("name") or "").strip()
    if not name:
        return err("채널 이름을 적어 주세요")
    orig = d.get("original_name") or name
    if orig != name and get_channel(cfg, name):
        return err("같은 이름의 채널이 이미 있습니다")
    times = [t.strip() for t in str(d.get("publish_times", "19:00")).replace("，", ",").split(",") if t.strip()]
    data = {
        "name": name,
        "folder": (d.get("folder") or "").strip().strip('"'),
        "publish_times": times or ["19:00"],
        "style": d.get("style", ""),
        "language": d.get("language", "ko"),
        "category_id": str(d.get("category_id", "24")),
        "synthetic_media": bool(d.get("synthetic_media", True)),
        "notify_subscribers": bool(d.get("notify_subscribers", True)),
        "embeddable": bool(d.get("embeddable", False)),
        "paid_promo": bool(d.get("paid_promo", False)),
        "title_hashtags": bool(d.get("title_hashtags", True)),
        "chrome_profile": str(d.get("chrome_profile") or ""),
        "copyright_check": bool(d.get("copyright_check")),
    }
    gd = None
    if data["folder"].startswith("gdrive:"):  # 구글 드라이브(인터넷) 폴더: gdrive:<id>:<이름>
        _, gid, gname = (data["folder"] + "::").split(":", 2)
        gd = {"id": gid, "name": gname.rstrip(":") or "구글 드라이브 폴더"}
        data["folder"] = str(gdrive.cache_dir(name))
        data["gdrive"] = gd
    ch = get_channel(cfg, orig)
    if ch:
        if not gd:
            ch.pop("gdrive", None)
        ch.update(data)
    else:
        cfg["channels"].append(data)
    save_config(cfg)
    if orig != name:
        old, new = youtube.token_path(orig), youtube.token_path(name)
        if old.exists() and not new.exists():
            old.rename(new)
        with edit() as st:
            for v in st["videos"].values():
                if v["channel"] == orig:
                    v["channel"] = name
            if orig in st["channel_info"]:
                st["channel_info"][name] = st["channel_info"].pop(orig)
            if orig in (st.get("gdrive") or {}):
                st["gdrive"][name] = st["gdrive"].pop(orig)
        if gd:  # 받은 영상 보관 폴더도 새 이름으로
            ch2 = get_channel(cfg, name)
            ch2["folder"] = str(gdrive.cache_dir(name))
            save_config(cfg)
    engine.kick()
    return ok(msg="채널을 저장했습니다" + (" · 구글 드라이브 영상을 곧 받아 와요" if gd else ""))


@app.post("/api/channel/delete")
def api_channel_delete():
    name = request.json["name"]
    cfg = load_config()
    cfg["channels"] = [c for c in cfg["channels"] if c["name"] != name]
    save_config(cfg)
    youtube.disconnect(name)
    return ok(msg="채널을 목록에서 뺐습니다 (폴더의 영상은 그대로)")


@app.post("/api/channel/connect")
def api_channel_connect():
    name = request.json["name"]
    if not youtube.has_client_secret():
        return err("client_secret.json 이 없습니다. 설치 안내서 2단계를 먼저 해 주세요")

    gen = _conn_gen[name] = _conn_gen.get(name, 0) + 1  # 다시 누르면 새 로그인이 이전 것을 대신함

    def run():
        _connecting[name] = "브라우저에서 로그인하고 채널을 골라 주세요"
        try:
            info = youtube.connect(name)
            with edit() as st:
                cur = st["channel_info"].get(name) or {}
                cur.update(info or {})
                st["channel_info"][name] = cur
                add_log(st, "connect", f"{name} ↔ 유튜브 '{info['title'] if info else '?'}' 연결", name)
            try:
                growth.refresh(name, deep=True)
            except Exception:
                pass
        except Exception as e:
            if _conn_gen.get(name) == gen:
                with edit() as st:
                    add_alert(st, "warn", f"{name} 연결 실패", str(e)[:200] + " · 로그인 창에 '액세스 차단됨'이 떴다면 → 화면 위 [쉽게 따라 하기]로 앱 게시를 해 주세요", channel=name)
        finally:
            if _conn_gen.get(name) == gen:
                _connecting.pop(name, None)

    threading.Thread(target=run, daemon=True).start()
    return ok(msg="브라우저 창이 열립니다. 올릴 채널 계정으로 로그인해 주세요")


@app.post("/api/channel/refresh")
def api_channel_refresh():
    cfg = load_config()
    msgs = []
    for ch in cfg["channels"]:
        if youtube.is_connected(ch["name"]):
            try:
                growth.refresh(ch["name"], deep=True)
            except Exception as e:
                msgs.append(f"{ch['name']}: {e}")
    engine.kick()
    return ok(msg="새로 읽었습니다" + (" (일부 실패: " + "; ".join(msgs) + ")" if msgs else ""))


@app.post("/api/settings")
def api_settings():
    d = request.json
    cfg = load_config()
    if "night_lock" in d:
        cfg["night_lock"].update(d["night_lock"])
    if "daily_auto" in d:
        cfg["daily_auto"].update(d["daily_auto"])
    if "min_lead_minutes" in d:
        cfg["min_lead_minutes"] = int(d["min_lead_minutes"])
    if "claude_cmd" in d:
        cfg["claude_cmd"] = d["claude_cmd"].strip() or "claude"
    if "humanize" in d:
        cfg["humanize"].update({k: d["humanize"][k] for k in ("enabled", "minutes") if k in d["humanize"]})
    if "daily_count_rules" in d:
        rules = [{"min_views": max(0, int(r["min_views"])), "count": max(1, min(12, int(r["count"])))}
                 for r in d["daily_count_rules"] if str(r.get("min_views", "")).strip() != ""]
        cfg["daily_count_rules"] = sorted(rules, key=lambda r: r["min_views"]) or cfg["daily_count_rules"]
    if "ypp" in d:
        cfg["ypp"] = d["ypp"]
        with edit() as st:  # 바뀐 기준으로 왕관 다시 판정
            for info in st["channel_info"].values():
                if info and info.get("ypp"):
                    info["tier"] = growth.tier_of(info["ypp"], cfg)
                    growth.raise_best(info)
    if "banned_words" in d:
        cfg["banned_words"] = [w.strip() for w in d["banned_words"] if w.strip()]
    if "notify" in d:
        n = d["notify"]
        if n.get("smtp_app_password") in ("●●●●", None):
            n.pop("smtp_app_password", None)
        cfg["notify"].update(n)
    save_config(cfg)
    if "daily_count_rules" in d:
        for c in cfg["channels"]:
            growth.apply_auto_count(c["name"])
    engine.kick()
    return ok(msg="설정을 저장했습니다")


@app.get("/api/setup")
def api_setup():
    return jsonify(setup.status(load_config()))


@app.post("/api/setup/ffmpeg")
def api_setup_ffmpeg():
    setup.install_ffmpeg()
    return ok(msg="ffmpeg 설치를 시작했어요")


@app.post("/api/setup/secret")
def api_setup_secret():
    d = request.json or {}
    try:
        setup.save_secret(text=d.get("text"), from_path=d.get("path"))
    except Exception as e:
        return err(e)
    return ok(msg="열쇠 파일을 넣었어요 ✓")


@app.post("/api/setup/done")
def api_setup_done():
    cfg = load_config()
    cfg["setup_done"] = bool((request.json or {}).get("done", True))
    save_config(cfg)
    return ok()


_gd = {"connecting": False, "error": ""}


@app.get("/api/gdrive/status")
def api_gdrive_status():
    if not gdrive.is_connected():
        return jsonify({"connected": False, "connecting": _gd["connecting"], "error": _gd["error"],
                        "has_secret": youtube.has_client_secret()})
    try:
        return jsonify({"connected": True, "account": gdrive.account()})
    except gdrive.DriveOff as e:
        return jsonify({"connected": True, "off": True, "url": e.url})
    except Exception as e:
        return jsonify({"connected": True, "error": str(e)[:300]})


@app.post("/api/gdrive/connect")
def api_gdrive_connect():
    if not youtube.has_client_secret():
        return err("구글 열쇠 파일이 없어요. 처음 설정의 '구글 열쇠 만들기'를 먼저 해 주세요")
    _gd["gen"] = gen = _gd.get("gen", 0) + 1  # 다시 누르면 새 로그인이 이전 것을 대신함

    def run():
        _gd.update(connecting=True, error="")
        try:
            gdrive.connect()
        except gdrive.DriveOff:
            pass  # 로그인은 됐고 드라이브 사용만 꺼짐 → 화면에서 켜는 버튼 안내
        except Exception as e:
            if _gd.get("gen") == gen:
                _gd["error"] = str(e)[:300]
        finally:
            if _gd.get("gen") == gen:
                _gd["connecting"] = False
        engine.kick()

    threading.Thread(target=run, daemon=True).start()
    return ok(msg="브라우저 창이 열려요. 영상을 넣어 둔 구글 계정으로 로그인해 주세요")


@app.post("/api/gdrive/cancel")
def api_gdrive_cancel():
    _gd["gen"] = _gd.get("gen", 0) + 1  # 열려 있던 로그인은 무시
    _gd.update(connecting=False, error="")
    return ok()


@app.post("/api/gdrive/disconnect")
def api_gdrive_disconnect():
    gdrive.disconnect()
    return ok(msg="구글 드라이브 연결을 끊었어요")


@app.get("/api/gdrive/ls")
def api_gdrive_ls():
    try:
        kind = request.args.get("kind", "")
        if kind == "recent":
            return jsonify({"ok": True, "id": "", "name": "최근에 쓴 폴더", "parent": None, "dirs": gdrive.recent_folders(), "videos": 0, "list": True})
        if kind == "shared":
            return jsonify({"ok": True, "id": "", "name": "공유 문서함", "parent": None, "dirs": gdrive.shared_folders(), "videos": 0, "list": True})
        if kind == "search":
            q = request.args.get("q", "").strip()
            return jsonify({"ok": True, "id": "", "name": f"'{q}' 찾은 결과", "parent": None, "dirs": gdrive.search_folders(q) if q else [], "videos": 0, "list": True})
        return jsonify({"ok": True, **gdrive.list_folder(request.args.get("id") or "root")})
    except gdrive.DriveOff as e:
        return jsonify({"ok": False, "off": True, "url": e.url, "error": str(e)})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)[:300]})


@app.get("/api/places")
def api_places():
    return jsonify({"pc": setup.pc_places(), "drive": setup.drive_roots(), "os": setup.platform.system()})


@app.get("/api/ls")
def api_ls():
    try:
        return jsonify({"ok": True, **setup.list_dir(request.args.get("path", ""))})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)})


@app.post("/api/mkdir")
def api_mkdir():
    d = request.json or {}
    try:
        return ok(path=setup.make_dir(d.get("parent", ""), d.get("name", "")), msg="새 폴더를 만들었어요")
    except Exception as e:
        return err(e)


@app.post("/api/pick_folder")
def api_pick_folder():
    try:
        return ok(path=setup.pick_folder((request.json or {}).get("initial", "")))
    except Exception as e:
        return err(f"폴더 선택 창을 못 열었어요. 경로를 직접 붙여넣어 주세요 ({e})")


DEFAULT_REC = ["12:00", "19:00"]


@app.get("/api/recommend")
def api_recommend():
    """채널 추천 시간: 유튜브 연결돼 있으면 내 채널 기록, 아니면 일반 추천"""
    name = request.args.get("channel", "")
    force = request.args.get("force") == "1"
    st = load_state()
    cached = (st["channel_info"].get(name) or {}).get("rec")
    if cached and not force and cached.get("day") == datetime.now().strftime("%Y-%m-%d"):
        return jsonify(cached)
    rec = {"source": "default", "times": DEFAULT_REC, "count": 0, "hours": [],
           "day": datetime.now().strftime("%Y-%m-%d")}
    if youtube.is_connected(name):
        try:
            r = youtube.recommend_times(name)
            if r and r["count"] >= 3:
                good = [h for h in r["hours"] if h["count"] >= 2][:2] or r["hours"][:2]
                rec.update(source="channel", count=r["count"], hours=r["hours"][:6],
                           times=sorted(f"{h['hour']:02d}:00" for h in good))
            elif r:
                rec.update(source="few", count=r["count"])
        except Exception as e:
            rec["error"] = str(e)[:200]
    with edit() as s2:
        s2["channel_info"].setdefault(name, {})
        if s2["channel_info"][name] is None:
            s2["channel_info"][name] = {}
        s2["channel_info"][name]["rec"] = rec
    return jsonify(rec)


@app.post("/api/channel/times")
def api_channel_times():
    d = request.json
    cfg = load_config()
    ch = get_channel(cfg, d["name"])
    if not ch:
        return err("없는 채널")
    times = sorted({t.strip() for t in d.get("times", []) if t.strip()})
    if not times:
        return err("시간을 하나 이상 골라 주세요")
    ch["publish_times"] = times
    msg = None
    if d.get("manual", True) and ch.get("auto_count", True):
        info = load_state()["channel_info"].get(ch["name"]) or {}
        if info.get("views") is not None and len(times) != growth.rule_count(info["views"], cfg):
            ch["auto_count"] = False
            msg = "하루 개수를 직접 정했어요. 조회수에 따른 자동 개수는 꺼졌어요"
    save_config(cfg)
    return ok(msg=msg) if msg else ok()


@app.post("/api/channel/autocount")
def api_channel_autocount():
    d = request.json
    cfg = load_config()
    ch = get_channel(cfg, d["name"])
    if not ch:
        return err("없는 채널")
    ch["auto_count"] = bool(d.get("enabled"))
    save_config(cfg)
    if ch["auto_count"]:
        growth.apply_auto_count(ch["name"])
    return ok(msg="조회수에 맞춰 하루 개수를 자동으로 정해요" if ch["auto_count"] else "하루 개수를 직접 정해요")


@app.post("/api/channel/celebrated")
def api_channel_celebrated():
    name = request.json["name"]
    with edit() as st:
        info = st["channel_info"].get(name) or {}
        info["celebrated"] = int(info.get("best_tier") or 0)
        st["channel_info"][name] = info
    return ok()


@app.get("/api/preview")
def api_preview():
    name = request.args.get("channel", "")
    n = int(request.args.get("n", "1"))
    cfg = load_config()
    ch = get_channel(cfg, name)
    if not ch:
        return jsonify([])
    return jsonify(engine.preview_slots(cfg, load_state(), ch, n, request.args.get("date") or None))


@app.post("/api/upload_folder")
def api_upload_folder():
    d = request.json
    n = engine.queue_from_folder(d["channel"], int(d.get("count", 9999)), newest=False, start_date=d.get("date") or None)
    return ok(msg=f"{n}개를 올릴게요" if n else "올릴 새 영상이 없어요")


_stats_cache = {}
_lc_cache = {}


@app.get("/api/views48")
def api_views48():
    """📈 48시간 조회수: 연결된 모든 채널을 한 화면에"""
    import time as _t
    cfg, st = load_config(), load_state()
    out = []
    for ch in cfg["channels"]:
        n = ch["name"]
        con = youtube.is_connected(n)
        d = {"name": n, "connected": con, **engine.views48(st, n)}
        info = st["channel_info"].get(n) or {}
        d["title"] = info.get("title", "")
        d["tier"] = info.get("best_tier", 0)
        d["channel_id"] = info.get("id", "")
        if con:
            c = _lc_cache.get(n)
            if not c or _t.time() - c[0] > 1800:
                try:
                    c = (_t.time(), youtube.daily_views(n, 10))
                except Exception:
                    c = (_t.time(), None)
                _lc_cache[n] = c
            daily = c[1] or []
            d["daily"] = daily
            last2 = [x for x in daily if x["views"] or x["likes"]][-2:]
            d["lc"] = {"likes": sum(x["likes"] for x in last2), "comments": sum(x["comments"] for x in last2)} if daily else None
            # 업로더가 직접 찍은 기록이 48시간이 안 됐으면 → 유튜브 분석의 최근 이틀 합으로 먼저 보여 줌
            if (d.get("views48") is None or (d.get("hours") or 0) < 47) and last2:
                d["views48"] = sum(x["views"] for x in last2)
                d["source"] = "analytics"
            else:
                d["source"] = "snaps"
        out.append(d)
    out.sort(key=lambda x: (x["connected"], x.get("views48") or 0), reverse=True)
    return jsonify({"channels": out, "total48": sum(x.get("views48") or 0 for x in out)})


@app.post("/api/views48/refresh")
def api_views48_refresh():
    cfg = load_config()
    only = (request.json or {}).get("name")
    done, fail = 0, []
    for ch in cfg["channels"]:
        if only and ch["name"] != only:
            continue
        if youtube.is_connected(ch["name"]):
            try:
                engine.snap_channel(ch["name"])
                done += 1
            except Exception as e:
                fail.append(f"{ch['name']}: {str(e)[:80]}")
    if only:
        _lc_cache.pop(only, None)
    else:
        _lc_cache.clear()
    return ok(msg=f"{done}개 채널을 새로 읽었어요" + (f" · 실패 {len(fail)}개" if fail else ""), fail=fail)


@app.get("/api/stats")
def api_stats():
    import time as _t
    name = request.args.get("channel", "")
    days = int(request.args.get("days", "28"))
    key = (name, days)
    if request.args.get("force") != "1" and key in _stats_cache and _t.time() - _stats_cache[key][0] < 600:
        return jsonify(_stats_cache[key][1])
    if not youtube.is_connected(name):
        return jsonify({"ok": False, "reason": "not_connected"})
    try:
        data = {"ok": True, **youtube.channel_stats(name, days)}
        data["fetched"] = datetime.now().strftime("%Y-%m-%dT%H:%M")
    except Exception as e:
        return jsonify({"ok": False, "reason": "error", "error": str(e)[:300]})
    _stats_cache[key] = (_t.time(), data)
    return jsonify(data)


@app.post("/api/run")
def api_run():
    engine.kick()
    return ok(msg="지금 바로 한 번 돌립니다")


@app.post("/api/command")
def api_command():
    text = (request.json or {}).get("text", "").strip()
    if not text:
        return err("내용을 적어 주세요")
    cfg = load_config()
    st = load_state()
    summary = [{"name": ch["name"], "free": sum(1 for f in engine.scan_channel(ch, st) if f["stage"] == "free")}
               for ch in cfg["channels"]]
    try:
        res = claude_ai.parse_command(text, summary, cfg)
    except Exception as e:
        return err(f"Claude 호출 실패: {e}")
    done = []
    for a in res.get("actions", []):
        t = a.get("type")
        if t == "queue":
            n = engine.queue_from_folder(a.get("channel", ""), a.get("count", 1), a.get("newest", True))
            done.append(f"{a.get('channel')} {n}개 업로드 대기")
        elif t == "launch_basket":
            done.append(f"고른 영상 {engine.launch()}개 업로드")
        elif t == "night_lock":
            cfg = load_config()
            cfg["night_lock"]["enabled"] = bool(a.get("enabled"))
            save_config(cfg)
            done.append("심야 금지 " + ("켬" if a.get("enabled") else "끔"))
    with edit() as s2:
        add_log(s2, "command", f"말로 시킴: {text} → {', '.join(done) or '실행 없음'}")
    return ok(msg=(res.get("reply") or "") + (f"  ({', '.join(done)})" if done else "  (실행할 동작을 찾지 못했어요)"))


@app.get("/api/system")
def api_system():
    import platform
    return jsonify({"os": platform.system(), "autostart": setup.autostart_enabled(), "version": updater.version()})


@app.get("/api/claude")
def api_claude_status():
    return jsonify({"connected": setup.claude_connected()})


@app.post("/api/claude/connect")
def api_claude_connect():
    try:
        where = setup.connect_claude()
    except Exception as e:
        return err(e)
    return ok(where=where, msg=f"{', '.join(where)}에 연결했어요. Claude 앱을 완전히 껐다가 다시 켜 주세요")


@app.post("/api/open")
def api_open():
    """전용 창 안에서 누른 바깥 링크(유튜브 스튜디오 등)는 크롬으로 열기"""
    d = request.json or {}
    u = str(d.get("url", ""))
    if not (u.startswith("http://") or u.startswith("https://")):
        return err("열 수 없는 주소예요")
    if "studio.youtube.com" in u or "youtube.com/verify" in u:
        # 유튜브 스튜디오는 그 채널 계정으로 로그인된 크롬 사용자로 열기
        cfg, st = load_config(), load_state()
        name = None
        import re as _re
        m = _re.search(r"/video/([\w-]{6,})", u)
        if m:
            name = next((v["channel"] for v in st["videos"].values() if v.get("yt_id") == m.group(1)), None)
        m = _re.search(r"/channel/(UC[\w-]+)", u)
        if not name and m:
            name = next((n for n, i in st["channel_info"].items() if (i or {}).get("id") == m.group(1)), None)
        if not name and d.get("channel") and get_channel(cfg, d["channel"]):
            name = d["channel"]
        if not name and len(cfg["channels"]) == 1:
            name = cfg["channels"][0]["name"]
        profs = setup.chrome_profiles()
        if name and len(profs) > 1:
            ch = get_channel(cfg, name)
            prof = (ch or {}).get("chrome_profile")
            if prof and any(p["dir"] == prof for p in profs):
                setup.open_url_profile(u, prof)
                return ok()
            if not d.get("any"):
                return jsonify({"ok": False, "need_profile": True, "channel": name, "profiles": profs, "url": u})
    setup.open_url(u)
    return ok()


@app.get("/api/chrome_profiles")
def api_chrome_profiles():
    return jsonify({"profiles": setup.chrome_profiles()})


@app.post("/api/channel/chrome_profile")
def api_channel_chrome_profile():
    d = request.json or {}
    cfg = load_config()
    ch = get_channel(cfg, d.get("channel", ""))
    if not ch:
        return err("채널을 찾을 수 없어요")
    ch["chrome_profile"] = d.get("profile") or ""
    save_config(cfg)
    return ok()


@app.get("/api/version")
def api_version():
    cfg = load_config()
    return jsonify({"version": updater.version(), "auto_update": cfg.get("auto_update", True),
                    "last_check": engine._upd.get("last"), "msg": engine._upd.get("msg", "")})


@app.post("/api/update/auto")
def api_update_auto():
    cfg = load_config()
    cfg["auto_update"] = bool((request.json or {}).get("enabled", True))
    save_config(cfg)
    return ok(msg="자동 업데이트를 " + ("켰어요" if cfg["auto_update"] else "껐어요"))


@app.post("/api/update/check")
def api_update_check():
    engine.check_update_now()
    engine.kick()
    return ok(msg="새 버전이 있는지 확인하고 있어요. 있으면 저절로 업데이트돼요")


@app.post("/api/update")
def api_update():
    """업데이트 파일(.zip) 하나로 업데이트 → 업로더 다시 켜기"""
    f = request.files.get("file")
    if not f:
        return err("업데이트 파일을 골라 주세요")
    st = load_state()
    if any(v.get("stage") == "uploading" for v in st["videos"].values()):
        return err("지금 영상을 올리는 중이에요. 다 올라간 뒤(몇 분 뒤)에 다시 해 주세요")
    try:
        r = updater.apply_zip(f.read())
    except Exception as e:
        return err(e)
    with edit() as s2:
        add_log(s2, "update", f"업데이트: v{r['old']} → v{r['new']} (파일 {r['files']}개) {r['pip']}")
    updater.restart()
    import os
    threading.Timer(1.0, lambda: os._exit(0)).start()
    return ok(**r, msg=f"v{r['old']} → v{r['new']} 업데이트했어요. 업로더를 다시 켜는 중이에요…")


# ───────── 설정 백업·옮기기 (컴퓨터를 바꿀 때) ─────────
BACKUP_ITEMS = ["config.json", "client_secret.json", "tokens"]


@app.post("/api/backup")
def api_backup():
    """채널·연결·설정·기록을 zip 하나로 바탕화면에 저장"""
    import zipfile
    out = setup.desktop_dir() / f"나만의자동업로더_백업_{datetime.now().strftime('%Y%m%d_%H%M')}.zip"
    n = 0
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("_업로더백업.txt", f"나만의 자동 업로더 백업 v{updater.version()} {datetime.now():%Y-%m-%d %H:%M}\n")
        for name in BACKUP_ITEMS:
            p = BASE / name
            if p.is_file():
                z.write(p, name); n += 1
            elif p.is_dir():
                for f in p.rglob("*"):
                    if f.is_file():
                        z.write(f, f.relative_to(BASE).as_posix()); n += 1
        for f in (BASE / "data").glob("*.json"):  # 업로드 기록·조회수 기록
            z.write(f, "data/" + f.name); n += 1
    setup.show_in_folder(out)
    return ok(path=str(out), msg=f"바탕화면에 백업 파일을 만들었어요: {out.name}")


@app.post("/api/restore")
def api_restore():
    """백업 zip으로 채널·연결·설정을 되살리고 업로더를 다시 켬"""
    import io
    import shutil
    import zipfile
    f = request.files.get("file")
    if not f:
        return err("백업 파일을 골라 주세요")
    st = load_state()
    if any(v.get("stage") == "uploading" for v in st["videos"].values()):
        return err("지금 영상을 올리는 중이에요. 다 올라간 뒤에 다시 해 주세요")
    try:
        z = zipfile.ZipFile(io.BytesIO(f.read()))
    except Exception:
        return err("백업 파일이 아니에요. '나만의자동업로더_백업_….zip' 파일을 골라 주세요")
    names = [n for n in z.namelist() if not n.endswith("/")]
    if "config.json" not in names:
        return err("백업 파일이 아니에요. '나만의자동업로더_백업_….zip' 파일을 골라 주세요")
    # 지금 것을 먼저 따로 보관
    keep = BASE / "data" / "backup" / f"되살리기전_{datetime.now():%Y%m%d_%H%M%S}"
    keep.mkdir(parents=True, exist_ok=True)
    for name in BACKUP_ITEMS + ["data/state.json"]:
        p = BASE / name
        try:
            if p.is_file():
                shutil.copy2(p, keep / p.name)
            elif p.is_dir():
                shutil.copytree(p, keep / name, dirs_exist_ok=True)
        except Exception:
            pass
    n = 0
    for name in names:
        parts = name.split("/")
        if ".." in parts or name.startswith("/") or ":" in parts[0]:
            continue
        if not (name in ("config.json", "client_secret.json") or parts[0] == "tokens"
                or (parts[0] == "data" and len(parts) == 2 and name.endswith(".json"))):
            continue
        dest = BASE / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(z.read(name))
        n += 1
    with edit() as s2:
        add_log(s2, "update", f"백업 파일로 되살림 (파일 {n}개, 예전 것은 {keep.name}에 보관)")
    updater.restart()
    threading.Timer(1.0, lambda: os._exit(0)).start()
    return ok(msg="되살렸어요! 업로더를 다시 켜는 중이에요…")


@app.post("/api/autostart")
def api_autostart():
    on = bool((request.json or {}).get("enabled"))
    try:
        now = setup.set_autostart(on)
    except Exception as e:
        return err(e)
    return ok(msg="컴퓨터를 켜면 업로더가 저절로 켜져요" if now else "자동 실행을 껐어요")


@app.post("/api/desktop_icon")
def api_desktop_icon():
    try:
        setup.make_desktop_icon()
    except Exception as e:
        return err(f"아이콘을 못 만들었어요: {e}")
    return ok(msg="바탕화면에 아이콘을 만들었어요")


@app.post("/api/quit")
def api_quit():
    import os
    threading.Timer(0.8, lambda: os._exit(0)).start()
    return ok(msg="업로더를 껐어요. 다시 켜려면 바탕화면 아이콘을 두 번 누르세요")


def _already_running():
    import socket
    with socket.socket() as so:
        so.settimeout(0.5)
        return so.connect_ex(("127.0.0.1", PORT)) == 0


if __name__ == "__main__":
    import os
    import sys
    # 창 없이(pythonw) 켜졌을 때는 기록을 파일로
    if sys.stdout is None or sys.stderr is None:
        log = open(BASE / "data" / "uploader.log", "a", encoding="utf-8", buffering=1)
        sys.stdout = sys.stdout or log
        sys.stderr = sys.stderr or log
    no_browser = "--no-browser" in sys.argv
    updater.HEADLESS = no_browser
    url = f"http://127.0.0.1:{PORT}"
    if "--wait-port" in sys.argv:  # 업데이트 후 다시 켤 때: 예전 업로더가 꺼질 때까지 기다림
        import time as _t
        for _ in range(60):
            if not _already_running():
                break
            _t.sleep(0.5)
    if _already_running():  # 이미 켜져 있으면 화면만 열기 (창을 닫아도 업로더는 계속 일하고 있었던 것)
        if not no_browser:
            setup.show_ui(url)
        sys.exit(0)
    setup.repair_paths()
    engine.start()
    print(f"\n  자동 업로더 실행 중 → {url}\n")
    if no_browser:  # 컴퓨터 켤 때 자동 실행: 화면 없이 조용히
        app.run(host="127.0.0.1", port=PORT, debug=False, threaded=True)
        sys.exit(0)
    srv = threading.Thread(target=lambda: app.run(host="127.0.0.1", port=PORT, debug=False, threaded=True), daemon=True)
    srv.start()
    import time as _t
    for _ in range(40):
        if _already_running():
            break
        _t.sleep(0.25)
    setup.show_ui(url)  # 전용 창 (닫힐 때까지 여기서 기다림)
    # 창을 닫아도 업로더는 뒤에서 계속 일해요. 끄려면 설정 → 업로더 끄기
    srv.join()
