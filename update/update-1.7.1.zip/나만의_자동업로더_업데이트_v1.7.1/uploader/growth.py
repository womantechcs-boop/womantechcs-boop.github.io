"""채널 성장: 총 조회수 → 하루 올릴 개수, 수익 창출(1차·2차) 판정."""
from datetime import datetime, timedelta

from . import youtube
from .store import edit, get_channel, load_config, load_state, save_config, now_iso

TIME_ORDER = ["19:00", "12:00", "21:00", "09:00", "15:00", "18:00", "07:00", "13:00", "20:00", "10:00"]


def rule_count(views, cfg):
    rules = sorted(cfg.get("daily_count_rules") or [{"min_views": 0, "count": 1}], key=lambda r: r["min_views"])
    n = 1
    for r in rules:
        if (views or 0) >= int(r["min_views"]):
            n = int(r["count"])
    return max(1, min(n, 12))


def tier_of(prog, cfg):
    """0 = 아직, 1 = 1차 조건 달성, 2 = 2차 조건 달성"""
    if not prog or not prog.get("analytics"):
        return 0
    y = cfg.get("ypp") or {}
    t1, t2 = y.get("t1", {}), y.get("t2", {})
    hours, shorts, subs = prog.get("hours365") or 0, prog.get("shorts90") or 0, prog.get("subs") or 0
    if subs >= t2.get("subs", 1000) and (hours >= t2.get("hours", 4000) or shorts >= t2.get("shorts", 10000000)):
        return 2
    if (subs >= t1.get("subs", 500) and prog.get("uploads90", 0) >= t1.get("uploads90", 3)
            and (hours >= t1.get("hours", 3000) or shorts >= t1.get("shorts", 3000000))):
        return 1
    return 0


def _pick_times(current, n, rec_hours):
    pref = [f"{h['hour']:02d}:00" for h in (rec_hours or [])] + TIME_ORDER
    cur = list(dict.fromkeys(current))
    if len(cur) > n:  # 줄이기: 추천 순서가 앞선 것부터 남김
        cur.sort(key=lambda t: pref.index(t) if t in pref else 99)
        return sorted(cur[:n])
    for t in pref:  # 늘리기: 추천 시간부터 채움
        if len(cur) >= n:
            break
        if t not in cur:
            cur.append(t)
    return sorted(cur)


def apply_auto_count(name):
    cfg = load_config()
    ch = get_channel(cfg, name)
    st = load_state()
    info = st["channel_info"].get(name) or {}
    if not ch or not ch.get("auto_count", True) or info.get("views") is None:
        return False
    n = rule_count(info["views"], cfg)
    if len(ch.get("publish_times") or []) == n:
        return False
    rec = info.get("rec") or {}
    ch["publish_times"] = _pick_times(ch.get("publish_times") or [], n, rec.get("hours"))
    save_config(cfg)
    return True


def refresh(name, deep=True):
    """채널 정보(구독자·총 조회수)와 수익 창출 진행도를 새로 읽고 저장"""
    if not youtube.is_connected(name):
        return None
    info = youtube.channel_info(name)
    prog = None
    if deep:
        try:
            prog = youtube.monetization_progress(name)
        except Exception as e:
            prog = {"error": str(e)[:200]}
    cfg = load_config()
    with edit() as st:
        cur = st["channel_info"].get(name) or {}
        cur.update(info or {})
        if prog is not None:
            cur["ypp"] = prog
            cur["tier"] = tier_of(prog, cfg)
            raise_best(cur)
        cur["last_growth"] = now_iso()
        st["channel_info"][name] = cur
    apply_auto_count(name)
    return cur


def raise_best(info):
    """왕관은 한 번 달성하면 계속 유지. 더 높은 단계를 처음 달성한 시각을 기록(하루 동안 반짝임)."""
    t = int(info.get("tier") or 0)
    if t > int(info.get("best_tier") or 0):
        info["best_tier"] = t
        info["tier_since"] = now_iso()


def shining(info, hours=24):
    t = info.get("tier_since")
    if not t:
        return False
    return datetime.now() - datetime.strptime(t, "%Y-%m-%dT%H:%M:%S") < timedelta(hours=hours)


def due(name, hours=6):
    info = load_state()["channel_info"].get(name) or {}
    t = info.get("last_growth")
    if not t:
        return True
    return datetime.now() - datetime.strptime(t, "%Y-%m-%dT%H:%M:%S") > timedelta(hours=hours)
