"""문제 알림: Gmail(앱 비밀번호)로 메일 보내기. 설정 안 하면 화면 알림만."""
import smtplib
from email.mime.text import MIMEText


def send_email(cfg, subject, body):
    n = cfg.get("notify", {})
    if not n.get("email_enabled") or not n.get("smtp_user") or not n.get("smtp_app_password"):
        return False
    msg = MIMEText(body, _charset="utf-8")
    msg["Subject"] = subject
    msg["From"] = n["smtp_user"]
    msg["To"] = n.get("to") or n["smtp_user"]
    with smtplib.SMTP_SSL("smtp.gmail.com", 465, timeout=30) as s:
        s.login(n["smtp_user"], n["smtp_app_password"].replace(" ", ""))
        s.send_message(msg)
    return True
