"""자동 검토: 올리기 전(내 컴퓨터) 검사 + 올린 뒤(유튜브 처리 상태) 검사."""
import json
import shutil
import subprocess
from pathlib import Path


def probe(file):
    from .setup import find_ffprobe
    exe = find_ffprobe()
    if not exe:
        return None
    try:
        out = subprocess.run(
            [exe, "-v", "error", "-print_format", "json", "-show_streams", "-show_format", str(file)],
            capture_output=True, timeout=60,
        )
        return json.loads(out.stdout.decode("utf-8", "ignore") or "{}")
    except Exception:
        return None


def local_check(video, cfg):
    """반환: (problems, warnings) — problems가 하나라도 있으면 올리지 않습니다."""
    problems, warnings = [], []
    f = Path(video["file"])
    if not f.exists():
        return ["영상 파일이 폴더에 없습니다 (옮겨졌거나 지워짐)"], warnings
    if f.stat().st_size < 10 * 1024:
        problems.append("파일이 너무 작습니다 (깨진 영상일 수 있음)")

    info = probe(f)
    if info is None:
        warnings.append("ffprobe가 없어 영상 자체 검사는 건너뜀 (ffmpeg 설치 권장)")
    else:
        streams = info.get("streams", [])
        vs = [s for s in streams if s.get("codec_type") == "video"]
        aus = [s for s in streams if s.get("codec_type") == "audio"]
        dur = float(info.get("format", {}).get("duration") or 0)
        if not vs:
            problems.append("영상 트랙이 없습니다")
        if not aus:
            problems.append("소리 트랙이 없습니다 (TTS/더빙 누락?)")
        if dur <= 1:
            problems.append("영상 길이가 1초 이하입니다")
        video["duration"] = round(dur, 1)
        if vs:
            w, h = int(vs[0].get("width") or 0), int(vs[0].get("height") or 0)
            video["resolution"] = f"{w}x{h}"
            if min(w, h) < 720:
                warnings.append(f"해상도가 낮습니다 ({w}x{h})")
            if h > w and dur > 180:
                warnings.append(f"세로 영상인데 {int(dur)}초라 쇼츠로 분류되지 않을 수 있습니다 (쇼츠는 최대 3분)")

    title = (video.get("title") or "").strip()
    desc = video.get("description") or ""
    tags = video.get("tags") or []
    if not title:
        problems.append("제목이 비어 있습니다")
    if len(title) > 100:
        problems.append(f"제목이 100자를 넘습니다 ({len(title)}자)")
    if "<" in title + desc or ">" in title + desc:
        problems.append("제목/설명에 < > 기호는 쓸 수 없습니다")
    if len(desc.encode("utf-8")) > 5000:
        problems.append("설명이 5000바이트를 넘습니다")
    if sum(len(t) for t in tags) + max(len(tags) - 1, 0) > 500:
        problems.append("태그 전체 길이가 500자를 넘습니다")

    text = f"{title}\n{desc}\n{' '.join(tags)}".lower()
    hits = [w for w in cfg.get("banned_words", []) if w and w.lower() in text]
    if hits:
        problems.append("금지어 포함: " + ", ".join(hits))

    if video.get("meta_source") == "fallback":
        warnings.append("Claude 제목 생성 실패로 파일 이름을 제목으로 씀 — 확인 필요")
    return problems, warnings


def remote_check(item):
    """유튜브 처리 결과 → ("pending"|"ok"|"problem", 이유)"""
    if item is None:
        return "problem", "유튜브에서 영상을 찾을 수 없습니다 (삭제됨)"
    st = item.get("status", {})
    us = st.get("uploadStatus")
    if us == "processed":
        return "ok", ""
    if us == "uploaded":
        return "pending", "유튜브 처리 중"
    if us == "rejected":
        reason = {
            "copyright": "저작권 문제로 거부됨",
            "duplicate": "중복 영상으로 거부됨",
            "inappropriate": "부적절한 콘텐츠로 거부됨",
            "termsOfUse": "이용약관 위반으로 거부됨",
            "length": "길이 제한 초과로 거부됨",
            "legal": "법적 문제로 거부됨",
            "trademark": "상표권 문제로 거부됨",
            "uploaderAccountSuspended": "계정 정지로 거부됨",
            "uploaderAccountClosed": "계정 폐쇄로 거부됨",
            "claim": "저작권 클레임으로 거부됨",
        }.get(st.get("rejectionReason"), f"거부됨 ({st.get('rejectionReason')})")
        return "problem", reason
    if us == "failed":
        return "problem", f"유튜브 처리 실패 ({st.get('failureReason', '원인 불명')})"
    if us == "deleted":
        return "problem", "유튜브에서 삭제됨"
    return "pending", f"상태 확인 중 ({us})"


COUNTRY = {"KR": "한국", "US": "미국", "JP": "일본", "CN": "중국", "TW": "대만", "GB": "영국", "DE": "독일", "FR": "프랑스"}


def _cname(codes):
    names = [COUNTRY.get(c, c) for c in codes[:6]]
    return ", ".join(names) + (f" 외 {len(codes) - 6}곳" if len(codes) > 6 else "")


def remote_risks(item):
    """유튜브가 알려 주는 공개 위험 → (막을 것[], 불이익[])"""
    blocks, risks = [], []
    if not item:
        return blocks, risks
    cd = item.get("contentDetails", {})
    rr = cd.get("regionRestriction") or {}
    if rr.get("blocked"):
        b = rr["blocked"]
        where = "한국을 포함해 " if "KR" in b else ""
        blocks.append(f"{where}일부 나라에서 영상이 막혔어요 ({_cname(b)}). 저작권 클레임일 가능성이 커요")
    if "allowed" in rr:
        a = rr.get("allowed") or []
        if "KR" not in a:
            blocks.append("한국에서 볼 수 없게 막혔어요. 저작권 클레임일 가능성이 커요")
        else:
            blocks.append(f"일부 나라에서만 볼 수 있게 제한됐어요 (허용: {_cname(a)}). 저작권 클레임일 가능성이 커요")
    if (cd.get("contentRating") or {}).get("ytRating") == "ytAgeRestricted":
        risks.append("연령 제한이 걸렸어요. 추천에 잘 안 뜨고 조회수·수익이 크게 줄어요")
    stt = item.get("status", {})
    if stt.get("madeForKids") and not stt.get("selfDeclaredMadeForKids"):
        risks.append("유튜브가 '아동용 영상'으로 지정했어요. 댓글·알림이 꺼지고 수익이 줄어요")
    return blocks, risks


def publish_checks(v, ch, st, item=None):
    """공개 전 다시 확인할 것 → [{"lv": "risk"|"check", "t": 내용}]"""
    out = []
    b, r = remote_risks(item)
    out += [{"lv": "risk", "t": x} for x in r]
    if ch.get("copyright_check"):
        out.append({"lv": "check", "t": "저작권 주의 채널이에요. 유튜브 스튜디오에서 이 영상에 '저작권' 표시가 없는지 확인해 주세요"})
    w = " ".join(v.get("warnings") or [])
    if "썸네일 설정 실패" in w:
        out.append({"lv": "risk", "t": "썸네일이 안 들어갔어요. 채널 휴대폰 인증(youtube.com/verify)을 해야 썸네일을 넣을 수 있어요. 지금은 영상 중간 화면이 썸네일로 나가요"})
    if "쇼츠로 분류되지" in w:
        out.append({"lv": "risk", "t": "세로 영상인데 3분이 넘어서 쇼츠로 안 잡힐 수 있어요"})
    if "해상도가 낮습니다" in w:
        out.append({"lv": "check", "t": "화질이 낮아요 (" + (v.get("resolution") or "") + "). 흐리게 보일 수 있어요"})
    if v.get("meta_source") == "fallback":
        out.append({"lv": "check", "t": "제목을 자동으로 못 만들어서 파일 이름이 그대로 제목이에요"})
    t = (v.get("title") or "").strip()
    if t and any(o["id"] != v["id"] and o["channel"] == v["channel"] and (o.get("title") or "").strip() == t
                 and o["stage"] in ("review", "check", "scheduled", "published") for o in st["videos"].values()):
        out.append({"lv": "check", "t": "같은 채널에 제목이 똑같은 영상이 있어요. 중복으로 보일 수 있어요"})
    return b, out


def build_report(v, ch, st, item=None):
    """스튜디오 '제한사항'처럼 항목별 검사표.
    status: ok(✅) / block(🔴 공개하면 안 됨) / risk(🟠 불이익) / check(🟡 다시 확인) / unknown(❓ 직접 확인) / info"""
    R = []
    add = lambda cat, status, text, studio=None: R.append({"cat": cat, "s": status, "t": text, "studio": studio})
    stt = (item or {}).get("status", {})
    up = stt.get("uploadStatus")
    rej = stt.get("rejectionReason") if up == "rejected" else None
    cd = (item or {}).get("contentDetails", {})
    rr = cd.get("regionRestriction") or {}
    w = " ".join(v.get("warnings") or [])
    have = item is not None

    # 1 저작권
    if rej in ("copyright", "claim"):
        add("저작권", "block", "저작권 문제로 유튜브가 영상을 막았어요")
    elif up == "deleted":
        add("저작권", "block", "유튜브에서 영상이 삭제됐어요 (저작권 신고일 수 있어요)")
    elif have:
        add("저작권", "ok", "저작권 신고로 막힌 기록이 없어요")
    else:
        add("저작권", "unknown", "아직 유튜브에 올라가기 전이라 확인 전이에요")

    # 2 소유권 주장 (Content ID)
    blocks, _ = remote_risks(item)
    region = [b for b in blocks if "나라" in b or "한국" in b]
    if region:
        add("소유권 주장", "block", region[0], "copyright")
    elif have:
        add("소유권 주장", "unknown",
            "막힌 나라는 없어요. 다만 수익만 가져가는 소유권 주장은 유튜브가 알려 주지 않아서 스튜디오에서 확인해야 해요"
            + (" (저작권 주의 채널)" if ch.get("copyright_check") else ""), "copyright")
    else:
        add("소유권 주장", "unknown", "올린 뒤에 확인할 수 있어요")

    # 3 수익 창출 제한
    add("수익 창출 제한", "unknown",
        "광고 제한(노란 달러 표시)은 유튜브가 알려 주지 않아요. 수익 창출 중인 채널이면 스튜디오에서 확인해 주세요",
        "monetization" if have else None)

    # 4 연령 제한
    if (cd.get("contentRating") or {}).get("ytRating") == "ytAgeRestricted":
        add("연령 제한", "risk", "연령 제한이 걸렸어요. 추천에 잘 안 뜨고 조회수·수익이 크게 줄어요")
    elif have:
        add("연령 제한", "ok", "연령 제한 없음")

    # 5 아동용 지정
    if stt.get("madeForKids") and not stt.get("selfDeclaredMadeForKids"):
        add("아동용 지정", "risk", "유튜브가 '아동용'으로 지정했어요. 댓글·알림이 꺼지고 수익이 줄어요")
    elif have:
        add("아동용 지정", "ok", "아동용 아님")

    # 6 유튜브 규칙
    if rej in ("inappropriate", "termsOfUse", "uploaderAccountSuspended", "uploaderAccountClosed"):
        add("유튜브 규칙", "block", "유튜브 규칙(커뮤니티 가이드·약관)에 걸려서 막혔어요")
    elif have:
        add("유튜브 규칙", "ok", "규칙 위반으로 막힌 기록이 없어요")

    # 7 상표권·법적 문제
    if rej in ("trademark", "legal"):
        add("상표권·법적 문제", "block", "상표권 또는 법적 문제로 막혔어요")
    elif have:
        add("상표권·법적 문제", "ok", "문제 없음")

    # 8 중복
    t = (v.get("title") or "").strip()
    dup = t and any(o["id"] != v["id"] and o["channel"] == v["channel"] and (o.get("title") or "").strip() == t
                    and o["stage"] in ("review", "check", "scheduled", "published") for o in st["videos"].values())
    if rej == "duplicate":
        add("중복 영상", "block", "이미 올린 영상과 똑같아서 유튜브가 막았어요")
    elif dup:
        add("중복 영상", "check", "같은 채널에 제목이 똑같은 영상이 있어요. 중복으로 보일 수 있어요")
    else:
        add("중복 영상", "ok", "겹치는 영상 없음")

    # 9 영상 상태
    if "쇼츠로 분류되지" in w:
        add("영상 상태", "risk", "세로 영상인데 3분이 넘어서 쇼츠로 안 잡힐 수 있어요")
    elif "해상도가 낮습니다" in w:
        add("영상 상태", "check", f"화질이 낮아요 ({v.get('resolution', '')}). 흐리게 보일 수 있어요")
    else:
        add("영상 상태", "ok", "소리·화질·길이 정상" + (f" ({v.get('duration')}초)" if v.get("duration") else ""))

    # 10 썸네일
    if "썸네일 설정 실패" in w:
        add("썸네일", "risk", "썸네일이 안 들어갔어요. 채널 휴대폰 인증(youtube.com/verify)을 하면 다음 영상부터 들어가요")
    elif v.get("thumb"):
        add("썸네일", "ok", "썸네일 들어감")
    else:
        add("썸네일", "info", "썸네일 파일이 없어서 유튜브가 자동으로 고른 화면이 나가요")

    # 11 제목·설명
    if v.get("meta_source") == "fallback":
        add("제목·설명", "check", "제목을 자동으로 못 만들어서 파일 이름이 그대로 제목이에요")
    else:
        add("제목·설명", "ok", "제목·설명·태그 준비됨")

    # 12 저작권 주의 채널 직접 확인
    if ch.get("copyright_check"):
        add("직접 확인 (저작권 주의 채널)", "check",
            "원본 영상·음악을 쓰는 채널이라 공개 전에 스튜디오에서 '저작권' 표시가 없는지 한 번 봐 주세요", "copyright")
    return R


JUDGE_NOTE = ("유튜브가 막은 나라·저작권 거절·삭제가 없어요 → 공개해도 돼요. "
              "(수익만 나눠 가져가는 소유권 주장은 유튜브가 프로그램에 알려 주지 않아요. 수익이 이상하면 스튜디오에서 보세요)")


def judge(item, waited_min):
    """업로더가 스스로 내리는 저작권·소유권 판단 → (ok: bool, 설명)"""
    b, _ = remote_risks(item)
    if item is None:
        return False, "유튜브에서 영상을 찾을 수 없어요 (삭제됐을 수 있어요)"
    st = item.get("status", {})
    if st.get("uploadStatus") in ("rejected", "deleted", "failed"):
        return False, "유튜브가 영상을 거절했어요: " + str(st.get("rejectionReason") or st.get("failureReason") or st.get("uploadStatus"))
    if b:
        return False, " / ".join(b)
    return True, f"올리고 {waited_min}분 동안 지켜봤어요. " + JUDGE_NOTE
