"""구글 드라이브(인터넷) 연결: 다른 컴퓨터에서 드라이브에 올린 영상을 이 컴퓨터로 받아 와서 올림.

- 연결: 열쇠(client_secret.json)로 '드라이브 읽기' 권한만 받아 tokens/_google_drive.json 에 저장
  (채널 토큰 이름은 _safe()가 앞의 '_'를 지우므로 겹치지 않음)
- 채널 폴더가 드라이브 폴더면 config 채널에 gdrive={"id","name"} 이 있고,
  실제 영상은 BASE/구글드라이브_받은영상/<채널> 로 미리 몇 개씩 내려받아 둠 (engine._step_gdrive)
"""
import io
import os
import re
from datetime import datetime
from pathlib import Path

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from googleapiclient.http import MediaIoBaseDownload

from .store import BASE, VIDEO_EXT

SCOPES = ["https://www.googleapis.com/auth/drive.readonly"]
TOKEN = BASE / "tokens" / "_google_drive.json"
CACHE = BASE / "구글드라이브_받은영상"
FOLDER_MIME = "application/vnd.google-apps.folder"
ENABLE_URL = "https://console.cloud.google.com/apis/library/drive.googleapis.com"
SIDE_EXT = {".jpg", ".jpeg", ".png", ".webp", ".txt", ".json"}


class DriveOff(Exception):
    """구글 프로젝트에서 'Google Drive API'가 꺼져 있음"""
    def __init__(self, url=ENABLE_URL):
        super().__init__("구글 드라이브 사용이 아직 꺼져 있어요")
        self.url = url


def is_connected():
    return TOKEN.exists()


def _creds():
    if not TOKEN.exists():
        raise RuntimeError("구글 드라이브가 아직 연결되지 않았어요")
    creds = Credentials.from_authorized_user_file(str(TOKEN))
    if not creds.valid:
        if creds.expired and creds.refresh_token:
            creds.refresh(Request())
            TOKEN.write_text(creds.to_json(), encoding="utf-8")
        else:
            raise RuntimeError("구글 드라이브 로그인이 만료됐어요. 다시 연결해 주세요")
    return creds


def _svc():
    return build("drive", "v3", credentials=_creds(), cache_discovery=False)


def _call(req):
    """API 실행. 드라이브 API가 꺼져 있으면 DriveOff (켜는 주소 포함)"""
    try:
        return req.execute()
    except HttpError as e:
        txt = str(e)
        if e.resp.status == 403 and ("accessNotConfigured" in txt or "SERVICE_DISABLED" in txt
                                     or "has not been used" in txt or "is disabled" in txt):
            m = re.search(r"https://console\.developers\.google\.com/apis/api/drive\.googleapis\.com/overview\?project=\d+", txt)
            raise DriveOff(m.group(0) if m else ENABLE_URL)
        raise


def connect():
    from .youtube import CLIENT_SECRET, run_login
    if not CLIENT_SECRET.exists():
        raise RuntimeError("구글 열쇠 파일(client_secret.json)이 없어요. 처음 설정을 먼저 해 주세요")
    flow = InstalledAppFlow.from_client_secrets_file(str(CLIENT_SECRET), SCOPES)
    creds = run_login(flow, "select_account consent")
    TOKEN.parent.mkdir(exist_ok=True)
    TOKEN.write_text(creds.to_json(), encoding="utf-8")
    return account()


def disconnect():
    if TOKEN.exists():
        TOKEN.unlink()


def account():
    r = _call(_svc().about().get(fields="user(emailAddress,displayName)"))
    u = r.get("user") or {}
    return {"email": u.get("emailAddress", ""), "name": u.get("displayName", "")}


def _is_video(f):
    return (f.get("mimeType", "").startswith("video/")
            or Path(f.get("name", "")).suffix.lower() in VIDEO_EXT)


def _list(q, fields, order="name", limit=1000):
    svc = _svc()
    out, token = [], None
    while True:
        r = _call(svc.files().list(q=q, fields="nextPageToken, files(" + fields + ")", orderBy=order,
                                   pageSize=min(1000, limit), pageToken=token,
                                   supportsAllDrives=True, includeItemsFromAllDrives=True))
        out += r.get("files", [])
        token = r.get("nextPageToken")
        if not token or len(out) >= limit:
            return out[:limit]


def folder_info(fid):
    if fid == "root":
        return {"id": "root", "name": "내 드라이브", "parent": None}
    f = _call(_svc().files().get(fileId=fid, fields="id,name,parents", supportsAllDrives=True))
    return {"id": f["id"], "name": f["name"], "parent": (f.get("parents") or [None])[0]}


def list_folder(fid="root"):
    """폴더 안의 하위 폴더 + 영상 개수"""
    me = folder_info(fid)
    items = _list(f"'{fid}' in parents and trashed=false", "id,name,mimeType", order="folder,name")
    dirs = [{"id": f["id"], "name": f["name"]} for f in items if f["mimeType"] == FOLDER_MIME]
    videos = sum(1 for f in items if _is_video(f))
    return {"id": me["id"], "name": me["name"], "parent": me["parent"], "dirs": dirs, "videos": videos}


def recent_folders(limit=40):
    """최근에 바뀐 폴더 (내 드라이브·컴퓨터·공유 문서함 모두)"""
    items = _list(f"mimeType='{FOLDER_MIME}' and trashed=false", "id,name", order="modifiedTime desc", limit=limit)
    return [{"id": f["id"], "name": f["name"]} for f in items]


def shared_folders(limit=100):
    items = _list(f"mimeType='{FOLDER_MIME}' and sharedWithMe and trashed=false", "id,name", limit=limit)
    return [{"id": f["id"], "name": f["name"]} for f in items]


def search_folders(text, limit=50):
    t = text.replace("\\", "\\\\").replace("'", "\\'")
    items = _list(f"mimeType='{FOLDER_MIME}' and name contains '{t}' and trashed=false", "id,name", limit=limit)
    return [{"id": f["id"], "name": f["name"]} for f in items]


def folder_files(fid):
    """채널용 드라이브 폴더의 파일 (오래된 것부터)"""
    return _list(f"'{fid}' in parents and trashed=false and mimeType!='{FOLDER_MIME}'",
                 "id,name,mimeType,size,createdTime", order="createdTime")


def cache_dir(channel_name):
    from .youtube import _safe
    p = CACHE / _safe(channel_name)
    p.mkdir(parents=True, exist_ok=True)
    return p


def safe_name(name):
    return re.sub(r'[\\/:*?"<>|]+', "_", name).strip() or "video"


def download(f, dest_dir, name=None):
    """파일 하나 내려받기 (.part 로 받은 뒤 이름 바꿈 → 받는 중인 파일은 업로더가 안 집음)"""
    name = name or safe_name(f["name"])
    dest = Path(dest_dir) / name
    part = dest.with_name(dest.name + ".part")
    req = _svc().files().get_media(fileId=f["id"], supportsAllDrives=True)
    with io.FileIO(str(part), "wb") as fh:
        dl = MediaIoBaseDownload(fh, req, chunksize=16 * 1024 * 1024)
        done = False
        while not done:
            _, done = dl.next_chunk(num_retries=3)
    os.replace(part, dest)
    try:  # 드라이브에 올라간 순서대로 정렬되게 파일 시간을 맞춤
        ts = datetime.strptime(f["createdTime"][:19], "%Y-%m-%dT%H:%M:%S").timestamp()
        os.utime(dest, (ts, ts))
    except Exception:
        pass
    return dest


def companions(files, video):
    """같은 이름의 썸네일·대본 파일 (예: 영상.jpg, 영상.meta.json, 영상.txt)"""
    stem = Path(video["name"]).stem
    out = []
    for f in files:
        if f["id"] == video["id"] or _is_video(f):
            continue
        n = f["name"]
        if Path(n).suffix.lower() in SIDE_EXT and (n.startswith(stem + ".") or n.startswith(stem + "_thumb")):
            out.append(f)
    return out
