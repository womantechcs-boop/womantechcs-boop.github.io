"""Claude Code(claude -p)로 제목·설명·태그 생성 + '말로 시키기' 해석.

Claude Code가 설치·로그인돼 있으면 따로 API 키가 필요 없습니다.
"""
import json
import re
import shutil
import subprocess
from pathlib import Path


def _run_claude(cmd_name, prompt, timeout=240):
    from .setup import find_claude
    exe = find_claude(cmd_name)
    if not exe:
        raise RuntimeError(f"'{cmd_name}' 명령을 찾을 수 없습니다 (Claude Code 설치 확인)")
    out = subprocess.run(
        [exe, "-p", prompt, "--output-format", "text"],
        capture_output=True, timeout=timeout,
    )
    text = out.stdout.decode("utf-8", "ignore")
    if out.returncode != 0 and not text.strip():
        raise RuntimeError(out.stderr.decode("utf-8", "ignore")[-400:] or "claude 실행 실패")
    return text


def _extract_json(text):
    m = re.search(r"\{.*\}", text, re.S)
    if not m:
        raise ValueError("JSON을 찾지 못함")
    return json.loads(m.group(0))


def find_script(video_file):
    """영상과 같은 이름의 .txt/.srt/.md 가 있으면 대본으로 씁니다."""
    p = Path(video_file)
    for ext in (".txt", ".srt", ".md"):
        q = p.with_suffix(ext)
        if q.exists():
            try:
                return q.read_text(encoding="utf-8", errors="ignore")[:8000]
            except Exception:
                pass
    return ""


def make_metadata(channel, video_file, cfg):
    """반환: dict(title, description, tags, meta_source)"""
    p = Path(video_file)

    # 1) 직접 써둔 '영상이름.meta.json' 이 있으면 그대로 사용
    manual = p.with_name(p.stem + ".meta.json")
    if manual.exists():
        try:
            d = json.loads(manual.read_text(encoding="utf-8"))
            return {
                "title": d.get("title", p.stem)[:100],
                "description": d.get("description", ""),
                "tags": d.get("tags", []),
                "hashtags": d.get("hashtags", []),
                "meta_source": "file",
            }
        except Exception:
            pass

    # 2) Claude가 생성
    script = find_script(video_file)
    script_part = ("영상 대본/내용:\n" + script) if script else "(대본 없음 — 파일 이름만 보고 판단)"
    lang = {"ko": "한국어", "en": "영어", "ja": "일본어"}.get(channel.get("language"), channel.get("language"))
    prompt = f"""너는 유튜브 채널 '{channel['name']}'의 업로드 담당자다.
채널 설명·스타일: {channel.get('style') or '(없음)'}
작성 언어: {lang}
영상 파일 이름: {p.stem}
{script_part}

이 영상의 유튜브 제목, 설명, 태그를 만들어라.
- 제목: 55자 이내 (뒤에 해시태그가 붙음), 클릭하고 싶게 하되 내용과 다른 낚시는 금지, 제목에는 # 넣지 말 것
- 제목 해시태그: 정확히 5개, # 없이 띄어쓰기 없는 낱말로. 첫 번째는 주인공(등장인물) 이름 — 대본·파일 이름·채널 설명에서 알 수 있을 때만, 모르면 지어내지 말고 작품 제목이나 핵심 낱말로. 나머지는 작품 제목·장르·핵심 내용 순
- 설명: 2~5문장 + 관련 해시태그 3개 이내
- 태그: 8~15개, 영상 내용과 직접 관련된 것만 (무관하거나 오해 소지 있는 태그는 유튜브 정책 위반)
- < > 기호 금지
다른 말 없이 JSON 한 개만 출력: {{"title": "...", "description": "...", "tags": ["...", "..."], "hashtags": ["주인공이름", "...", "...", "...", "..."]}}"""
    try:
        d = _extract_json(_run_claude(cfg.get("claude_cmd", "claude"), prompt))
        tags = [str(t).strip().lstrip("#") for t in d.get("tags", []) if str(t).strip()]
        return {
            "title": str(d.get("title", p.stem)).strip()[:100],
            "description": str(d.get("description", "")).strip(),
            "tags": tags[:20],
            "hashtags": [str(t).strip().lstrip("#") for t in d.get("hashtags", []) if str(t).strip()][:5],
            "meta_source": "claude",
        }
    except Exception as e:
        return {
            "title": p.stem.replace("_", " ")[:100],
            "description": "",
            "tags": [],
            "meta_source": "fallback",
            "meta_error": str(e)[:300],
        }


def parse_command(text, channels_summary, cfg):
    """'영어채널에 방금 만든 영상 2개 올려' → 실행할 동작 목록"""
    prompt = f"""유튜브 자동 업로더의 명령 해석기다. 사용자의 말을 동작 JSON으로 바꿔라.
채널 목록(이름, 올릴 수 있는 영상 수): {json.dumps(channels_summary, ensure_ascii=False)}
가능한 동작:
- {{"type":"queue","channel":"채널이름","count":숫자,"newest":true/false}}  → 그 채널 폴더에서 영상을 골라 바로 업로드 대기열에 넣음 (newest=true면 최근 파일부터)
- {{"type":"launch_basket"}} → 고른 영상 전부 업로드 시작
- {{"type":"night_lock","enabled":true/false}}
채널 이름은 위 목록 중 가장 가까운 것으로 정확히 적어라. 해석할 수 없으면 actions를 빈 배열로.
JSON 한 개만 출력: {{"actions":[...], "reply":"사용자에게 보여줄 한 줄 확인 문장"}}

사용자의 말: {text}"""
    return _extract_json(_run_claude(cfg.get("claude_cmd", "claude"), prompt, timeout=120))
