"""YouTube Data API 연결: 채널별 로그인, 비공개 업로드, 상태 확인, 예약 공개."""
import re
from pathlib import Path

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload

from .store import BASE

SCOPES = [
    "https://www.googleapis.com/auth/youtube",
    "https://www.googleapis.com/auth/yt-analytics.readonly",
    "https://www.googleapis.com/auth/yt-analytics-monetary.readonly",
]
ANALYTICS_SCOPE = "https://www.googleapis.com/auth/yt-analytics.readonly"
MONEY_SCOPE = "https://www.googleapis.com/auth/yt-analytics-monetary.readonly"
CLIENT_SECRET = BASE / "client_secret.json"
TOKENS = BASE / "tokens"
TOKENS.mkdir(exist_ok=True)


class NotConnected(Exception):
    pass


def _safe(name):
    return re.sub(r"[^\w가-힣-]+", "_", name).strip("_") or "channel"


def token_path(channel_name):
    return TOKENS / f"{_safe(channel_name)}.json"


def has_client_secret():
    return CLIENT_SECRET.exists()


def is_connected(channel_name):
    return token_path(channel_name).exists()


def _creds(channel_name):
    p = token_path(channel_name)
    if not p.exists():
        raise NotConnected(f"'{channel_name}' 채널이 아직 유튜브에 연결되지 않았습니다")
    # 예전에 연결한 토큰(업로드 권한만 있음)도 그대로 쓰도록 저장된 권한으로 읽음
    creds = Credentials.from_authorized_user_file(str(p))
    if not creds.valid:
        if creds.expired and creds.refresh_token:
            creds.refresh(Request())
            p.write_text(creds.to_json(), encoding="utf-8")
        else:
            raise NotConnected(f"'{channel_name}' 로그인이 만료됐습니다. 다시 연결해 주세요")
    return creds


def _service(channel_name):
    return build("youtube", "v3", credentials=_creds(channel_name), cache_discovery=False)


def granted(channel_name):
    """이 채널 연결이 받은 권한들"""
    try:
        return set(_creds(channel_name).scopes or [])
    except Exception:
        return set()


LOGIN_TIMEOUT = 300  # 로그인 창을 닫아 버려도 5분 뒤엔 저절로 포기


def run_login(flow, prompt):
    """브라우저 로그인. 창을 닫거나 5분 안에 안 끝내면 RuntimeError"""
    try:
        from .setup import chrome_browser
        creds = flow.run_local_server(port=0, prompt=prompt, open_browser=True, timeout_seconds=LOGIN_TIMEOUT,
                                      browser=chrome_browser())  # 로그인 창도 크롬으로
    except Exception as e:
        raise RuntimeError("로그인이 끝나지 않았어요 (창을 닫았거나 시간이 지났어요). 다시 눌러 주세요") from e
    if not creds or not getattr(creds, "token", None):
        raise RuntimeError("로그인이 끝나지 않았어요 (창을 닫았거나 시간이 지났어요). 다시 눌러 주세요")
    return creds


def connect(channel_name):
    """브라우저가 열리고, 올릴 채널(브랜드 계정 포함)을 고르면 토큰이 저장됩니다."""
    if not has_client_secret():
        raise RuntimeError("client_secret.json 파일이 없습니다 (설치 안내서 2단계)")
    flow = InstalledAppFlow.from_client_secrets_file(str(CLIENT_SECRET), SCOPES)
    creds = run_login(flow, "consent")
    token_path(channel_name).write_text(creds.to_json(), encoding="utf-8")
    return channel_info(channel_name)


def disconnect(channel_name):
    p = token_path(channel_name)
    if p.exists():
        p.unlink()


def channel_info(channel_name):
    yt = _service(channel_name)
    r = yt.channels().list(part="snippet,statistics", mine=True).execute()
    items = r.get("items") or []
    if not items:
        return None
    it = items[0]
    return {
        "id": it["id"],
        "title": it["snippet"]["title"],
        "handle": it["snippet"].get("customUrl", ""),
        "subs": int(it.get("statistics", {}).get("subscriberCount", 0) or 0),
        "hidden_subs": it.get("statistics", {}).get("hiddenSubscriberCount", False),
        "views": int(it.get("statistics", {}).get("viewCount", 0) or 0),
        "videos": int(it.get("statistics", {}).get("videoCount", 0) or 0),
    }


def title_with_tags(title, tags, limit=100):
    """제목 끝에 #해시태그를 붙입니다 (유튜브 제목 100자 안에서, 최대 5개)."""
    title = (title or "").strip()
    if "#" in title:
        return title[:limit]
    out = title
    n = 0
    for t in tags or []:
        t = "".join(str(t).replace("#", "").split())
        if not t or ("#" + t) in out:
            continue
        cand = f"{out} #{t}"
        if len(cand) > limit:
            continue
        out = cand
        n += 1
        if n >= 5:
            break
    return out[:limit]


def upload_private(channel, video, progress_cb=None):
    """항상 '비공개'로 올립니다. 공개는 검토 통과 후 schedule()이 합니다."""
    yt = _service(channel["name"])
    title = video["title"]
    if channel.get("title_hashtags", True):
        import re
        tags = (video.get("hashtags") or []) + (video.get("tags") or []) or re.findall(r"#([^\s#]+)", video.get("description", ""))
        title = title_with_tags(title, tags)
    body = {
        "snippet": {
            "title": title,
            "description": video.get("description", ""),
            "tags": video.get("tags") or [],
            "categoryId": str(channel.get("category_id") or "24"),
            "defaultLanguage": channel.get("language") or "ko",
            "defaultAudioLanguage": channel.get("language") or "ko",
        },
        "status": {
            "privacyStatus": "private",
            "selfDeclaredMadeForKids": False,
            "containsSyntheticMedia": bool(channel.get("synthetic_media", True)),
            "embeddable": bool(channel.get("embeddable", False)),
        },
    }
    if not body["snippet"]["tags"]:
        del body["snippet"]["tags"]  # 빈 태그는 400 오류
    media = MediaFileUpload(video["file"], chunksize=8 * 1024 * 1024, resumable=True)
    req = yt.videos().insert(
        part="snippet,status",
        body=body,
        media_body=media,
        notifySubscribers=bool(channel.get("notify_subscribers", True)),
    )
    resp = None
    while resp is None:
        status, resp = req.next_chunk()
        if status and progress_cb:
            progress_cb(int(status.progress() * 100))
    vid = resp["id"]

    warnings = []
    try:  # 유료 프로모션 표시 (기본: 아니요)
        yt.videos().update(part="paidProductPlacementDetails", body={
            "id": vid, "paidProductPlacementDetails": {"hasPaidProductPlacement": bool(channel.get("paid_promo", False))}}).execute()
    except Exception:
        pass  # 유튜브 기본값도 '아니요'라서 실패해도 괜찮음
    thumb = video.get("thumb")
    if thumb and Path(thumb).exists():
        try:
            yt.thumbnails().set(videoId=vid, media_body=MediaFileUpload(thumb)).execute()
        except Exception as e:  # 썸네일은 채널 인증(전화번호) 필요
            warnings.append(f"썸네일 설정 실패: {e}")
    return vid, warnings


def get_video(channel_name, yt_id):
    yt = _service(channel_name)
    r = yt.videos().list(part="status,processingDetails,contentDetails,snippet", id=yt_id).execute()
    items = r.get("items") or []
    return items[0] if items else None


def _status_body(current_status):
    keep = ["embeddable", "license", "publicStatsViewable", "selfDeclaredMadeForKids", "containsSyntheticMedia"]
    return {k: current_status[k] for k in keep if k in current_status}


def schedule(channel_name, yt_id, publish_at_utc_iso):
    """비공개 영상에 예약 공개 시간을 넣습니다. 그 시각에 유튜브가 알아서 공개합니다."""
    yt = _service(channel_name)
    item = get_video(channel_name, yt_id)
    if not item:
        raise RuntimeError("유튜브에서 영상을 찾을 수 없습니다 (삭제됐을 수 있음)")
    st = _status_body(item["status"])
    st["privacyStatus"] = "private"
    st["publishAt"] = publish_at_utc_iso
    yt.videos().update(part="status", body={"id": yt_id, "status": st}).execute()


def unschedule(channel_name, yt_id):
    """예약을 지우고 비공개로 둡니다."""
    yt = _service(channel_name)
    item = get_video(channel_name, yt_id)
    if not item:
        return
    st = _status_body(item["status"])
    st["privacyStatus"] = "private"
    yt.videos().update(part="status", body={"id": yt_id, "status": st}).execute()


def delete(channel_name, yt_id):
    _service(channel_name).videos().delete(id=yt_id).execute()


def recommend_times(channel_name, max_videos=50):
    """내 채널 지난 영상들의 공개 시각과 조회수를 보고 잘 된 시간대를 추천.
    (YouTube Data API만 사용 · 약 3단위)"""
    from datetime import datetime, timezone
    yt = _service(channel_name)
    ch = yt.channels().list(part="contentDetails", mine=True).execute().get("items") or []
    if not ch:
        return None
    uploads = ch[0]["contentDetails"]["relatedPlaylists"]["uploads"]
    items = yt.playlistItems().list(part="contentDetails", playlistId=uploads,
                                    maxResults=max_videos).execute().get("items", [])
    ids = [i["contentDetails"]["videoId"] for i in items]
    if not ids:
        return {"count": 0, "hours": []}
    vids = yt.videos().list(part="snippet,statistics", id=",".join(ids)).execute().get("items", [])
    now = datetime.now(timezone.utc)
    by_hour = {}
    for v in vids:
        pub = datetime.fromisoformat(v["snippet"]["publishedAt"].replace("Z", "+00:00"))
        age_days = max((now - pub).total_seconds() / 86400, 1)
        if age_days < 2:  # 막 올린 영상은 아직 조회수가 덜 쌓여서 제외
            continue
        views = int(v.get("statistics", {}).get("viewCount", 0) or 0)
        h = pub.astimezone().hour  # 내 컴퓨터 시간대 기준
        by_hour.setdefault(h, []).append(views)
    hours = []
    for h, vs in by_hour.items():
        vs.sort()
        med = vs[len(vs) // 2]
        hours.append({"hour": h, "count": len(vs), "median_views": med})
    hours.sort(key=lambda x: (x["count"] >= 2, x["median_views"]), reverse=True)
    return {"count": sum(x["count"] for x in hours), "hours": hours}


# ───────────────────────── 채널 성적 ─────────────────────────
class NeedAnalytics(Exception):
    pass


def _q(ya, start, end, metrics, **kw):
    return ya.reports().query(ids="channel==MINE", startDate=start, endDate=end, metrics=metrics, **kw).execute()


def daily_views(channel_name, days=10):
    """유튜브 분석: 날짜별 조회수·좋아요·댓글 (최근 며칠은 1~2일 늦게 채워질 수 있음)"""
    from datetime import date, timedelta
    ya = build("youtubeAnalytics", "v2", credentials=_creds(channel_name), cache_discovery=False)
    end = date.today()
    r = _q(ya, (end - timedelta(days=days)).isoformat(), end.isoformat(), "views,likes,comments", dimensions="day", sort="day")
    return [{"day": row[0], "views": int(row[1] or 0), "likes": int(row[2] or 0), "comments": int(row[3] or 0)}
            for row in (r.get("rows") or [])]


def likes_comments_2d(channel_name):
    """최근 이틀 좋아요·댓글 (유튜브 분석은 1~2일 늦게 채워질 수 있음)"""
    from datetime import date, timedelta
    ya = build("youtubeAnalytics", "v2", credentials=_creds(channel_name), cache_discovery=False)
    end = date.today()
    r = _q(ya, (end - timedelta(days=2)).isoformat(), end.isoformat(), "likes,comments")
    row = (r.get("rows") or [[0, 0]])[0]
    return {"likes": int(row[0] or 0), "comments": int(row[1] or 0)}


def channel_stats(channel_name, days=28):
    """반환 dict: info, recent(Data API) + analytics(가능하면) + revenue(가능하면)"""
    from datetime import date, datetime, timedelta, timezone
    yt = _service(channel_name)
    out = {"days": days, "analytics": False, "analytics_error": None, "revenue": {"ok": False, "reason": ""}}

    # 1) 채널 기본 (항상)
    ch = (yt.channels().list(part="snippet,statistics,contentDetails", mine=True).execute().get("items") or [None])[0]
    if not ch:
        raise RuntimeError("채널 정보를 읽지 못했어요")
    stt = ch.get("statistics", {})
    out["info"] = {
        "title": ch["snippet"]["title"], "handle": ch["snippet"].get("customUrl", ""),
        "thumb": ((ch["snippet"].get("thumbnails") or {}).get("default") or {}).get("url", ""),
        "subs": int(stt.get("subscriberCount", 0) or 0), "views": int(stt.get("viewCount", 0) or 0),
        "videos": int(stt.get("videoCount", 0) or 0),
    }

    # 2) 최근 영상 30개 (항상)
    uploads = ch["contentDetails"]["relatedPlaylists"]["uploads"]
    ids = [i["contentDetails"]["videoId"] for i in
           yt.playlistItems().list(part="contentDetails", playlistId=uploads, maxResults=30).execute().get("items", [])]
    meta = {}
    if ids:
        for v in yt.videos().list(part="snippet,statistics,contentDetails", id=",".join(ids)).execute().get("items", []):
            sn, st2 = v["snippet"], v.get("statistics", {})
            meta[v["id"]] = {
                "id": v["id"], "title": sn["title"],
                "thumb": ((sn.get("thumbnails") or {}).get("medium") or (sn.get("thumbnails") or {}).get("default") or {}).get("url", ""),
                "published": datetime.fromisoformat(sn["publishedAt"].replace("Z", "+00:00")).astimezone().strftime("%Y-%m-%dT%H:%M"),
                "views": int(st2.get("viewCount", 0) or 0), "likes": int(st2.get("likeCount", 0) or 0),
                "comments": int(st2.get("commentCount", 0) or 0), "duration": v.get("contentDetails", {}).get("duration", ""),
            }
    out["recent"] = [meta[i] for i in ids if i in meta]

    # 3) 분석 (권한 있으면)
    g = granted(channel_name)
    if ANALYTICS_SCOPE not in g:
        out["analytics_error"] = "need_reconnect"
        return out
    end = date.today()
    start = end - timedelta(days=days - 1)
    S, E = start.isoformat(), end.isoformat()
    try:
        ya = build("youtubeAnalytics", "v2", credentials=_creds(channel_name), cache_discovery=False)
        m = "views,estimatedMinutesWatched,subscribersGained,subscribersLost,averageViewPercentage"
        tot = _q(ya, S, E, m).get("rows") or [[0, 0, 0, 0, 0]]
        t = tot[0]
        out["totals"] = {"views": int(t[0]), "minutes": int(t[1]), "subs_net": int(t[2]) - int(t[3]),
                         "subs_gained": int(t[2]), "avp": round(float(t[4] or 0), 1)}
        daily = _q(ya, S, E, "views,subscribersGained", dimensions="day", sort="day").get("rows") or []
        out["daily"] = [{"d": r[0], "views": int(r[1]), "subs": int(r[2])} for r in daily]
        top = _q(ya, S, E, "views,averageViewPercentage,estimatedMinutesWatched",
                 dimensions="video", sort="-views", maxResults=10).get("rows") or []
        need = [r[0] for r in top if r[0] not in meta]
        if need:
            for v in yt.videos().list(part="snippet", id=",".join(need[:50])).execute().get("items", []):
                sn = v["snippet"]
                meta[v["id"]] = {"id": v["id"], "title": sn["title"],
                                 "thumb": ((sn.get("thumbnails") or {}).get("medium") or {}).get("url", ""),
                                 "published": sn["publishedAt"][:16]}
        out["top"] = [{**meta.get(r[0], {"id": r[0], "title": r[0], "thumb": ""}),
                       "p_views": int(r[1]), "avp": round(float(r[2] or 0), 1), "minutes": int(r[3])} for r in top]
        src = _q(ya, S, E, "views", dimensions="insightTrafficSourceType", sort="-views").get("rows") or []
        out["traffic"] = [{"src": r[0], "views": int(r[1])} for r in src]
        out["analytics"] = True
    except Exception as e:
        msg = str(e)
        if "has not been used" in msg or "SERVICE_DISABLED" in msg or "is disabled" in msg:
            out["analytics_error"] = "api_disabled"
        elif "insufficient" in msg.lower() or "scope" in msg.lower():
            out["analytics_error"] = "need_reconnect"
        else:
            out["analytics_error"] = "error: " + msg[:200]
        return out

    # 4) 수익 (수익 창출 승인 채널만)
    if MONEY_SCOPE not in g:
        out["revenue"] = {"ok": False, "reason": "need_reconnect"}
        return out
    try:
        r = _q(ya, S, E, "estimatedRevenue,estimatedAdRevenue").get("rows") or [[0, 0]]
        rd = _q(ya, S, E, "estimatedRevenue", dimensions="day", sort="day").get("rows") or []
        total = float(r[0][0] or 0)
        views = out["totals"]["views"]
        out["revenue"] = {"ok": True, "total": round(total, 2), "ad": round(float(r[0][1] or 0), 2),
                          "rpm": round(total / views * 1000, 2) if views else 0,
                          "daily": {x[0]: float(x[1] or 0) for x in rd}}
    except Exception as e:
        msg = str(e)
        out["revenue"] = {"ok": False, "reason": "not_monetized" if ("403" in msg or "Forbidden" in msg or "forbidden" in msg) else "error: " + msg[:150]}
    return out


def monetization_progress(channel_name):
    """수익 창출(1차·2차) 조건 진행도. 시청 시간·쇼츠 조회수는 분석 권한이 있을 때만."""
    from datetime import date, datetime, timedelta, timezone
    yt = _service(channel_name)
    ch = (yt.channels().list(part="statistics,contentDetails", mine=True).execute().get("items") or [None])[0]
    if not ch:
        return None
    out = {"subs": int(ch.get("statistics", {}).get("subscriberCount", 0) or 0),
           "uploads90": 0, "hours365": None, "shorts90": None, "analytics": False}
    since = datetime.now(timezone.utc) - timedelta(days=90)
    up = ch["contentDetails"]["relatedPlaylists"]["uploads"]
    items = yt.playlistItems().list(part="contentDetails", playlistId=up, maxResults=50).execute().get("items", [])
    ids = []
    for i in items:
        pub = i["contentDetails"].get("videoPublishedAt")
        if pub and datetime.fromisoformat(pub.replace("Z", "+00:00")) >= since:
            ids.append(i["contentDetails"]["videoId"])
    if ids:
        for v in yt.videos().list(part="status", id=",".join(ids)).execute().get("items", []):
            if v.get("status", {}).get("privacyStatus") == "public":
                out["uploads90"] += 1
    if ANALYTICS_SCOPE in granted(channel_name):
        try:
            ya = build("youtubeAnalytics", "v2", credentials=_creds(channel_name), cache_discovery=False)
            end = date.today()
            r1 = _q(ya, (end - timedelta(days=364)).isoformat(), end.isoformat(), "estimatedMinutesWatched",
                    dimensions="creatorContentType").get("rows") or []
            out["hours365"] = int(sum(float(x[1] or 0) for x in r1 if x[0] != "SHORTS") / 60)
            r2 = _q(ya, (end - timedelta(days=89)).isoformat(), end.isoformat(), "views",
                    dimensions="creatorContentType").get("rows") or []
            out["shorts90"] = int(sum(float(x[1] or 0) for x in r2 if x[0] == "SHORTS"))
            out["analytics"] = True
        except Exception as e:
            out["analytics_error"] = str(e)[:200]
    return out
