"""업로드 엔진: 고르기 완료 → 업로드 대기 → (비공개 업로드) → 심사 대기 → 예약 공개 / 문제.

단계(stage)
  basket     고른 영상
  queued     업로드 대기 (이 컴퓨터에서 올릴 차례를 기다림)
  uploading  올리는 중
  review     심사 대기 (유튜브 처리 결과 확인 중)
  scheduled  공개 예정 (예약 시간 걸림)
  published  공개됨
  problem    문제 (비공개로 대기 + 알림)
"""
import os
import random
import threading
import time
import traceback
from datetime import datetime, timedelta, timezone
from pathlib import Path

from . import claude_ai, gdrive, growth, notify, review, youtube
from .store import (VIDEO_EXT, add_alert, add_log, edit, get_channel, load_config,
                    load_state, now_iso, video_id_for)

ACTIVE = {"queued", "uploading", "review", "check", "scheduled", "published"}
_kick = threading.Event()
_busy = {"what": ""}


# ───────────────────────── 시간 도우미 ─────────────────────────
def _parse_local(s):
    return datetime.strptime(s[:16], "%Y-%m-%dT%H:%M")


def _to_utc_iso(local_str, sec=0):
    return (_parse_local(local_str) + timedelta(seconds=int(sec or 0))).astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.000Z")


def is_night(cfg, now=None):
    nl = cfg.get("night_lock", {})
    if not nl.get("enabled"):
        return False
    h = (now or datetime.now()).hour
    s, e = int(nl.get("start", 0)), int(nl.get("end", 7))
    return s <= h < e if s < e else (h >= s or h < e)


def _times(ch):
    out = []
    for t in ch.get("publish_times") or ["19:00"]:
        try:
            hh, mm = [int(x) for x in str(t).strip().split(":")]
            out.append((hh, mm))
        except Exception:
            pass
    return sorted(set(out)) or [(19, 0)]


def _taken(st, channel, exclude=None):
    """이미 쓰인 공개 시간표 칸 (흔들기 전 원래 시각 기준)"""
    return {
        (v.get("publish_base") or v["publish_at"])[:16] for v in st["videos"].values()
        if v["channel"] == channel and v["stage"] in ACTIVE and v.get("publish_at") and v["id"] != exclude
    }


def humanize(base, cfg, earliest=None):
    """정시에 딱 맞춰 공개하지 않도록 정한 시각 앞뒤로 몇 분씩 흔들기.
    반환: (실제 공개 시각 'YYYY-MM-DDTHH:MM', 초)"""
    h = cfg.get("humanize") or {}
    if not h.get("enabled", True):
        return base, 0
    span = max(3, int(h.get("minutes", 20)))
    b = _parse_local(base)
    earliest = earliest or datetime.now() + timedelta(minutes=15)
    for _ in range(50):
        off = random.randint(-span, span)
        t = b + timedelta(minutes=off)
        if abs(off) < 3 or t.minute % 5 == 0 or t < earliest:  # 정각·5분 단위·너무 이른 시각은 피함
            continue
        return t.strftime("%Y-%m-%dT%H:%M"), random.randint(1, 59)
    t = max(b, earliest) + timedelta(minutes=random.randint(3, span))
    if t.minute % 5 == 0:
        t += timedelta(minutes=1)
    return t.strftime("%Y-%m-%dT%H:%M"), random.randint(1, 59)


def _from_date(d):
    """'날짜 지정'으로 고른 날 (YYYY-MM-DD) → 그날 0시"""
    try:
        return datetime.strptime(d[:10], "%Y-%m-%d") if d else None
    except Exception:
        return None


def _assign(v, cfg, st, ch, earliest=None):
    """공개 시간표에서 빈 칸을 잡고, 실제 공개 시각은 살짝 흔들어 저장
    v["not_before"] 가 있으면 (날짜 지정) 그날부터 공개"""
    nb = _from_date(v.get("not_before"))
    if nb:
        base_e = earliest or datetime.now() + timedelta(minutes=int(cfg.get("min_lead_minutes", 60)))
        earliest = max(base_e, nb)
    base = next_slot(cfg, st, ch, exclude=v["id"], earliest=earliest)
    v["publish_base"] = base
    if base:
        v["publish_at"], v["publish_sec"] = humanize(base, cfg, earliest)
    else:
        v["publish_at"], v["publish_sec"] = None, 0


def next_slot(cfg, st, ch, exclude=None, earliest=None):
    earliest = earliest or datetime.now() + timedelta(minutes=int(cfg.get("min_lead_minutes", 60)))
    taken = _taken(st, ch["name"], exclude)
    day = datetime.now().date()
    for d in range(0, 400):
        for hh, mm in _times(ch):
            dt = datetime(day.year, day.month, day.day, hh, mm) + timedelta(days=d)
            if dt < earliest:
                continue
            s = dt.strftime("%Y-%m-%dT%H:%M")
            if s not in taken:
                return s
    return None


def preview_slots(cfg, st, ch, n, start_date=None):
    """앞으로 n개를 올리면 언제 공개될지 미리 계산 (start_date: 날짜 지정)"""
    out, earliest = [], None
    nb = _from_date(start_date)
    if nb:
        earliest = max(datetime.now() + timedelta(minutes=int(cfg.get("min_lead_minutes", 60))), nb)
    taken = set(_taken(st, ch["name"]))
    fake = {"videos": {k: v for k, v in st["videos"].items()}}
    for i in range(max(0, n)):
        s = next_slot(cfg, fake, ch, earliest=earliest)
        if not s:
            break
        out.append(s)
        fake["videos"][f"_p{i}"] = {"id": f"_p{i}", "channel": ch["name"], "stage": "queued", "publish_at": s}
    return out


# ───────────────────────── 폴더 읽기 ─────────────────────────
def _thumb_for(p):
    for ext in (".jpg", ".jpeg", ".png", ".webp"):
        q = p.with_suffix(ext)
        if q.exists():
            return str(q)
        q = p.with_name(p.stem + "_thumb" + ext)
        if q.exists():
            return str(q)
    return None


DONE_DIR = "업로드완료"


def _move_done(vid):
    """유튜브에 다 올라간 영상(+같은 이름의 썸네일·대본)을 채널 폴더 안 '업로드완료' 폴더로 옮김"""
    st = load_state()
    v = st["videos"].get(vid)
    if not v or not v.get("file"):
        return
    src = Path(v["file"])
    if not src.is_file() or src.parent.name == DONE_DIR:
        return
    dest_dir = src.parent / DONE_DIR
    try:
        dest_dir.mkdir(exist_ok=True)
        dest, k = dest_dir / src.name, 1
        while dest.exists():
            k += 1
            dest = dest_dir / f"{src.stem} ({k}){src.suffix}"
        side = [q for q in src.parent.iterdir()
                if q.is_file() and q != src and (q.name.startswith(src.stem + ".") or q.name.startswith(src.stem + "_thumb"))]
        os.replace(src, dest)
        moved_thumb = None
        for q in side:
            nq = dest_dir / (dest.stem + q.name[len(src.stem):])
            if not nq.exists():
                os.replace(q, nq)
                if v.get("thumb") and Path(v["thumb"]) == q:
                    moved_thumb = str(nq)
        with edit() as s2:
            x = s2["videos"].get(vid)
            if x:
                x["file"] = str(dest)
                if moved_thumb:
                    x["thumb"] = moved_thumb
                add_log(s2, "move", f"'{DONE_DIR}' 폴더로 옮김: {src.name}", x["channel"], vid)
    except Exception as e:
        with edit() as s2:
            add_log(s2, "error", f"'{DONE_DIR}' 폴더로 못 옮김: {src.name} — {str(e)[:150]}", v["channel"], vid)


def scan_channel(ch, st):
    """채널 폴더의 영상 파일 목록 + 각 파일의 상태
    ('업로드완료' 폴더로 옮긴 영상도 같이 보여 줌 — 상태는 저장된 기록에서 찾음)"""
    folder = Path(ch.get("folder") or "")
    files = []
    done = folder / DONE_DIR
    if ch.get("folder") and done.is_dir():
        by_file = {str(Path(v.get("file") or "")): v for v in st["videos"].values() if v.get("channel") == ch["name"]}
        for p in done.iterdir():
            v = by_file.get(str(p))
            if v and p.is_file() and p.suffix.lower() in VIDEO_EXT:
                files.append({"path": str(p), "name": p.name, "size": p.stat().st_size, "mtime": p.stat().st_mtime,
                              "thumb": v.get("thumb"), "id": v["id"], "stage": v["stage"]})
    if ch.get("folder") and folder.is_dir():
        for p in folder.iterdir():
            if p.is_file() and p.suffix.lower() in VIDEO_EXT:
                vid = video_id_for(p)
                v = st["videos"].get(vid)
                files.append({
                    "path": str(p),
                    "name": p.name,
                    "size": p.stat().st_size,
                    "mtime": p.stat().st_mtime,
                    "thumb": _thumb_for(p),
                    "id": vid,
                    "stage": v["stage"] if v else "free",
                })
    files.sort(key=lambda f: f["mtime"], reverse=True)
    return files


# ───────────────────────── 사용자 동작 ─────────────────────────
def add_to_basket(channel, paths):
    cfg = load_config()
    ch = get_channel(cfg, channel)
    if not ch:
        raise ValueError("없는 채널")
    added = 0
    with edit() as st:
        for path in paths:
            p = Path(path)
            vid = video_id_for(p)
            if vid in st["videos"]:
                continue
            st["videos"][vid] = {
                "id": vid, "channel": channel, "file": str(p), "name": p.name,
                "thumb": _thumb_for(p), "stage": "basket", "added": now_iso(),
                "title": "", "description": "", "tags": [], "meta_status": "none",
                "publish_at": None, "publish_fixed": False, "yt_id": None,
                "problems": [], "warnings": [], "progress": 0,
            }
            added += 1
    kick()
    return added


def launch(ids=None, channel=None):
    """고른 영상 → 업로드 대기. 공개 예정 시각을 채널 시간표에서 자동 배정."""
    cfg = load_config()
    n = 0
    with edit() as st:
        for v in sorted(st["videos"].values(), key=lambda x: x["added"]):
            if v["stage"] != "basket":
                continue
            if ids and v["id"] not in ids:
                continue
            if channel and v["channel"] != channel:
                continue
            ch = get_channel(cfg, v["channel"])
            if not ch:
                continue
            if not (v.get("publish_fixed") and v.get("publish_at")):
                _assign(v, cfg, st, ch)
            v["stage"] = "queued"
            v["queued_at"] = now_iso()
            n += 1
        if n:
            add_log(st, "launch", f"{n}개 업로드 대기로 이동")
    kick()
    return n


def queue_from_folder(channel, count, newest=True, start_date=None):
    """채널 폴더에서 아직 안 올린 영상 count개를 골라 바로 업로드 대기로.
    start_date(YYYY-MM-DD)를 주면 그날부터 공개 (날짜 지정)"""
    cfg = load_config()
    ch = get_channel(cfg, channel)
    if not ch:
        return 0
    st = load_state()
    free = [f for f in scan_channel(ch, st) if f["stage"] == "free"]
    if not newest:
        free.reverse()
    picked = [f["path"] for f in free[: max(0, int(count))]]
    add_to_basket(channel, picked)
    ids = [video_id_for(p) for p in picked]
    if ids:
        with edit() as st2:
            for i in ids:
                if i in st2["videos"]:
                    st2["videos"][i]["not_before"] = start_date[:10] if _from_date(start_date) else None
    return launch(ids=ids) if ids else 0


def update_video(vid, title=None, description=None, tags=None, publish_at=None):
    with edit() as st:
        v = st["videos"][vid]
        if title is not None:
            v["title"] = title.strip()[:100]
        if description is not None:
            v["description"] = description
        if tags is not None:
            v["tags"] = [t.strip().lstrip("#") for t in tags if t.strip()]
        if title is not None or description is not None or tags is not None:
            v["meta_status"] = "ready"
            v["meta_source"] = "manual"
        if publish_at is not None:
            if publish_at == "":
                v["publish_fixed"] = False
            else:
                v["publish_at"] = publish_at[:16]
                v["publish_base"] = publish_at[:16]
                v["publish_sec"] = 0
                v["publish_fixed"] = True
    kick()


def video_action(vid, action):
    cfg = load_config()
    st = load_state()
    v = st["videos"].get(vid)
    if not v:
        raise ValueError("영상 없음")
    ch = get_channel(cfg, v["channel"])

    if action == "remove":  # 아직 안 올린 것만 목록에서 빼기
        if v["stage"] not in ("basket", "queued", "problem") or v.get("yt_id"):
            raise ValueError("이미 유튜브에 올라간 영상은 '유튜브에서 내리기'를 쓰세요")
        with edit() as s2:
            s2["videos"].pop(vid, None)
        return "목록에서 뺐습니다"

    if action == "regen_meta":
        with edit() as s2:
            s2["videos"][vid]["meta_status"] = "none"
        kick()
        return "제목·설명·태그를 다시 만듭니다"

    if action == "retry":  # 다시 검토
        with edit() as s2:
            x = s2["videos"][vid]
            x["problems"] = []
            x["stage"] = "review" if x.get("yt_id") else "queued"
            x.pop("retry_after", None)
            add_log(s2, "retry", f"다시 검토: {x['title'] or x['name']}", x["channel"], vid)
        kick()
        return "다시 검토합니다"

    if action == "approve":  # 문제 무시하고 예약 공개
        with edit() as s2:
            x = s2["videos"][vid]
            x["problems"] = []
            if x.get("yt_id"):
                x["stage"] = "review"
                x["force_ok"] = True
            else:
                x["stage"] = "queued"
                x["skip_local"] = True
            add_log(s2, "approve", f"직접 승인: {x['title'] or x['name']}", x["channel"], vid)
        kick()
        return "승인했습니다. 지정 시각에 공개됩니다"

    if action == "confirm":  # 확인했어요 → 예약 공개
        with edit() as s2:
            x = s2["videos"][vid]
            x["confirmed"] = list(set((x.get("confirmed") or []) + [c["t"] for c in (x.get("checks") or [])]))
            x["checks"] = []
            x["stage"] = "review"
            x["last_check"] = None
            x["prechecked"] = False
            for a in s2["alerts"]:
                if a.get("video") == vid:
                    a["ack"] = True
            add_log(s2, "confirm", f"확인 후 공개 예약: {x['title'] or x['name']}", x["channel"], vid)
        kick()
        return "확인했어요. 정해진 시간에 공개돼요"

    if action == "hold":  # 예약 취소, 비공개 보류
        if v.get("yt_id"):
            youtube.unschedule(ch["name"], v["yt_id"])
        with edit() as s2:
            x = s2["videos"][vid]
            x["stage"] = "problem"
            x["problems"] = ["직접 보류함 (비공개 상태)"]
            add_log(s2, "hold", f"보류: {x['title'] or x['name']}", x["channel"], vid)
        return "예약을 취소하고 비공개로 보류했습니다"

    if action == "delete_youtube":  # 내리기 (되돌릴 수 없음)
        if v.get("yt_id"):
            youtube.delete(ch["name"], v["yt_id"])
        with edit() as s2:
            x = s2["videos"].pop(vid, None)
            add_log(s2, "delete", f"유튜브에서 내림: {x['title'] or x['name']}", x["channel"], vid)
        return "유튜브에서 내렸습니다. 영상은 다시 '여분'으로 돌아갑니다"

    raise ValueError("알 수 없는 동작")


# ───────────────────────── 엔진 루프 ─────────────────────────
def _problem(vid, reasons, cfg, where):
    with edit() as st:
        v = st["videos"][vid]
        v["stage"] = "problem"
        v["problems"] = reasons
        title = f"{v['channel']} · {v['title'] or v['name']}"
        add_alert(st, "problem", title, " / ".join(reasons), video=vid, channel=v["channel"])
        add_log(st, "problem", f"[{where}] {title}: {' / '.join(reasons)}", v["channel"], vid)
    try:
        notify.send_email(cfg, f"[자동 업로더] 문제 발생 - {title}",
                          f"{title}\n\n" + "\n".join("- " + r for r in reasons) +
                          "\n\n영상은 비공개로 대기 중입니다. 대시보드에서 확인해 주세요.")
    except Exception as e:
        with edit() as st:
            add_log(st, "error", f"알림 메일 실패: {e}")


def _step_daily_auto(cfg):
    da = cfg.get("daily_auto", {})
    if not da.get("enabled"):
        return
    today = datetime.now().strftime("%Y-%m-%d")
    st = load_state()
    if st.get("last_daily_run") == today or datetime.now().strftime("%H:%M") < da.get("time", "09:00"):
        return
    with edit() as s2:
        s2["last_daily_run"] = today
    total = 0
    for ch in cfg["channels"]:
        st = load_state()
        horizon = datetime.now() + timedelta(hours=24)
        need, earliest = 0, None
        while True:  # 앞으로 24시간 안의 빈 공개 시간 수만큼 채움
            s = next_slot(cfg, st, ch, earliest=earliest)
            if not s or _parse_local(s) > horizon:
                break
            need += 1
            earliest = _parse_local(s) + timedelta(minutes=1)
        if need:
            total += queue_from_folder(ch["name"], need, newest=False)
    with edit() as s2:
        add_log(s2, "auto", f"매일 자동: {total}개 업로드 대기로")


def _step_meta(cfg):
    st = load_state()
    todo = [v for v in st["videos"].values()
            if v["stage"] in ("basket", "queued") and v.get("meta_status") == "none"]
    for v in todo[:3]:
        ch = get_channel(cfg, v["channel"])
        if not ch:
            continue
        with edit() as s2:
            if v["id"] in s2["videos"]:
                s2["videos"][v["id"]]["meta_status"] = "working"
        _busy["what"] = f"제목 만드는 중: {v['name']}"
        meta = claude_ai.make_metadata(ch, v["file"], cfg)
        with edit() as s2:
            x = s2["videos"].get(v["id"])
            if x:
                x.update(meta)
                x["meta_status"] = "ready"
                if meta.get("meta_source") == "fallback":
                    add_alert(s2, "warn", f"{x['channel']} · {x['name']}",
                              "Claude 제목 생성 실패: " + meta.get("meta_error", ""), video=x["id"], channel=x["channel"])


def _step_upload(cfg):
    if is_night(cfg):
        return
    st = load_state()
    now = datetime.now()
    if st.get("next_upload_after") and _parse_local(st["next_upload_after"]) > now:
        return  # 연달아 올리지 않고 몇 분씩 쉬었다가 올림
    cands = [v for v in st["videos"].values()
             if v["stage"] == "queued" and v.get("meta_status") == "ready"
             and (not v.get("retry_after") or _parse_local(v["retry_after"]) <= now)]
    cands.sort(key=lambda v: (v.get("publish_at") or "9999", v.get("queued_at", "")))
    if not cands:
        return
    v = cands[0]
    ch = get_channel(cfg, v["channel"])
    if not ch:
        return

    if not v.get("skip_local"):
        problems, warnings = review.local_check(v, cfg)
        with edit() as s2:
            x = s2["videos"][v["id"]]
            x["warnings"] = warnings
            x["duration"] = v.get("duration")
            x["resolution"] = v.get("resolution")
        if problems:
            _save_report(v["id"], ch, None)
            _problem(v["id"], problems, cfg, "올리기 전 검사")
            return

    if not youtube.is_connected(ch["name"]):
        with edit() as s2:
            add_alert(s2, "warn", f"{ch['name']} 채널 연결 필요",
                      "채널 카드의 ⋯ → '유튜브 연결'을 눌러 로그인해 주세요", channel=ch["name"])
            s2["videos"][v["id"]]["retry_after"] = (now + timedelta(minutes=5)).strftime("%Y-%m-%dT%H:%M")
        return

    with edit() as s2:
        s2["videos"][v["id"]]["stage"] = "uploading"
        s2["videos"][v["id"]]["progress"] = 0
    _busy["what"] = f"업로드 중: {v['title']}"

    def prog(pct):
        with edit() as s3:
            if v["id"] in s3["videos"]:
                s3["videos"][v["id"]]["progress"] = pct

    try:
        st = load_state()
        yt_id, warns = youtube.upload_private(ch, st["videos"][v["id"]], prog)
    except Exception as e:
        msg = str(e)
        with edit() as s2:
            x = s2["videos"][v["id"]]
            x["stage"] = "queued"
            x["retry_after"] = (now + timedelta(minutes=30)).strftime("%Y-%m-%dT%H:%M")
            hint = " (오늘 업로드 한도 초과 — 내일 다시 시도)" if "quota" in msg.lower() or "uploadLimitExceeded" in msg else ""
            add_alert(s2, "warn", f"{ch['name']} 업로드 실패{hint}", msg[:300], video=v["id"], channel=ch["name"])
            add_log(s2, "error", f"업로드 실패: {v['title']} — {msg[:200]}", ch["name"], v["id"])
        return

    with edit() as s2:
        x = s2["videos"][v["id"]]
        h = cfg.get("humanize") or {}
        if h.get("enabled", True):
            gap = random.randint(int(h.get("upload_gap_min", 3)), max(int(h.get("upload_gap_min", 3)), int(h.get("upload_gap_max", 9))))
            s2["next_upload_after"] = (datetime.now() + timedelta(minutes=gap, seconds=random.randint(0, 59))).strftime("%Y-%m-%dT%H:%M:%S")
        x["yt_id"] = yt_id
        x["stage"] = "review"
        x["uploaded_at"] = now_iso()
        x["progress"] = 100
        x["warnings"] = (x.get("warnings") or []) + warns
        add_log(s2, "upload", f"비공개 업로드 완료: {x['title']} (https://youtu.be/{yt_id})", ch["name"], x["id"])
        if any("썸네일 설정 실패" in w for w in warns):
            add_alert(s2, "warn", f"썸네일이 안 들어갔어요: {ch['name']} 채널 휴대폰 인증 필요",
                      "유튜브는 채널 휴대폰 인증을 해야 썸네일을 넣게 해 줘요. 아래 버튼을 눌러 한 번만 인증하면 다음 영상부터 썸네일이 들어가요",
                      channel=ch["name"])
    if cfg.get("move_done", True):
        _move_done(v["id"])


def _step_review(cfg):
    st = load_state()
    now = datetime.now()
    for v in [v for v in st["videos"].values() if v["stage"] == "review"]:
        if v.get("last_check") and (now - _parse_local(v["last_check"])).total_seconds() < 50:
            continue
        ch = get_channel(cfg, v["channel"])
        if not ch:
            continue
        with edit() as s2:
            s2["videos"][v["id"]]["last_check"] = now.strftime("%Y-%m-%dT%H:%M:%S")
        try:
            item = youtube.get_video(ch["name"], v["yt_id"])
        except Exception as e:
            with edit() as s2:
                add_log(s2, "error", f"상태 확인 실패: {e}", ch["name"], v["id"])
            continue
        verdict, reason = review.remote_check(item)
        if v.get("force_ok") and verdict == "problem" and item is not None:
            verdict = "ok"
        if verdict == "pending":
            up = _parse_local(v.get("uploaded_at") or now_iso())
            if (now - up) > timedelta(hours=3):
                _problem(v["id"], [f"3시간 넘게 처리가 안 끝남 ({reason})"], cfg, "심사")
            continue
        if verdict == "problem":
            _save_report(v["id"], ch, item)
            _problem(v["id"], [reason], cfg, "심사")
            continue

        # 저작권 주의 채널: 소유권 주장(Content ID)은 올리고 몇 분~수십 분 뒤에 붙어서, 정해 둔 시간만큼 지켜본 뒤 판단
        auto = cfg.get("auto_judge", True)
        wait_min = int(cfg.get("copyright_wait_minutes", 30))
        up = _parse_local(v.get("uploaded_at") or now_iso())
        if auto and ch.get("copyright_check") and not v.get("force_ok") and (now - up) < timedelta(minutes=wait_min):
            left = wait_min - int((now - up).total_seconds() // 60)
            with edit() as s2:
                s2["videos"][v["id"]]["judge"] = f"저작권 자동 확인 중이에요 (약 {left}분 뒤 판단)"
            continue

        # 공개해도 되는지 검사
        _save_report(v["id"], ch, item)
        st2 = load_state()
        x = st2["videos"][v["id"]]
        blocks, checks = review.publish_checks(x, ch, st2, item)
        if blocks and not x.get("force_ok"):
            with edit() as s2:
                s2["videos"][v["id"]]["judge"] = "🔴 공개하면 안 돼요: " + " / ".join(blocks)
            _problem(v["id"], ["공개하면 안 돼요: " + b for b in blocks], cfg, "공개 전 검사")
            continue
        confirmed = set(x.get("confirmed") or [])
        new_checks = [c for c in checks if c["t"] not in confirmed]
        if auto:
            # 사람 확인을 기다리지 않음: 막힌 게 없으면 공개 예약, 알아 둘 것은 알림으로만
            ok_, why = review.judge(item, int((now - up).total_seconds() // 60))
            notes = [c["t"] for c in new_checks if "저작권 주의 채널" not in c["t"]]
            with edit() as s2:
                y = s2["videos"][v["id"]]
                y["judge"] = "✅ " + why + ((" · 알아 둘 것: " + " / ".join(notes)) if notes else "")
                y["confirmed"] = sorted(confirmed | {c["t"] for c in new_checks})
                if notes:
                    add_alert(s2, "warn", f"알아 두세요 (공개는 그대로 진행): {y['channel']} · {y['title']}",
                              " / ".join(notes), video=y["id"], channel=y["channel"])
            new_checks = []
        if new_checks and not x.get("force_ok"):
            _need_check(v["id"], new_checks, cfg)
            continue

        # 통과 → 예약 공개
        slot, sec, base = x.get("publish_at"), x.get("publish_sec", 0), x.get("publish_base")
        if not slot or _parse_local(slot) < now + timedelta(minutes=15):
            tmp = dict(x)
            _assign(tmp, cfg, st2, ch, earliest=now + timedelta(minutes=15))
            slot, sec, base = tmp["publish_at"], tmp["publish_sec"], tmp["publish_base"]
        try:
            youtube.schedule(ch["name"], v["yt_id"], _to_utc_iso(slot, sec))
        except Exception as e:
            _problem(v["id"], [f"예약 공개 설정 실패: {str(e)[:200]}",
                               "미검증 API로 올린 영상이 잠겼을 수 있습니다 (설치 안내서 '잠금' 항목 참고)"], cfg, "예약")
            continue
        with edit() as s2:
            x = s2["videos"][v["id"]]
            x["publish_at"] = slot
            x["publish_sec"] = sec
            x["publish_base"] = base
            x["stage"] = "scheduled"
            x.pop("force_ok", None)
            add_log(s2, "schedule", f"검토 통과 → {slot.replace('T', ' ')} 공개 예약: {x['title']}", ch["name"], x["id"])


def _save_report(vid, ch, item):
    with edit() as st:
        v = st["videos"].get(vid)
        if v:
            v["report"] = review.build_report(v, ch, st, item)


def _need_check(vid, checks, cfg):
    with edit() as st:
        v = st["videos"][vid]
        v["stage"] = "check"
        v["checks"] = checks
        title = f"{v['channel']} · {v['title'] or v['name']}"
        add_alert(st, "warn", "공개 전 확인 필요: " + title, " / ".join(c["t"] for c in checks), video=vid, channel=v["channel"])
        add_log(st, "check", f"공개 전 확인 필요: {title}", v["channel"], vid)
    try:
        notify.send_email(cfg, f"[자동 업로더] 공개 전 확인이 필요해요 - {title}",
                          f"{title}\n\n" + "\n".join("- " + c["t"] for c in checks) +
                          "\n\n확인하기 전까지 공개되지 않고 비공개로 기다려요.")
    except Exception:
        pass


def _step_autojudge(cfg):
    """자동 판단이 켜져 있으면, 사람 확인을 기다리던 영상(check)을 다시 검토로 돌려 업로더가 판단하게"""
    if not cfg.get("auto_judge", True):
        return
    st = load_state()
    ids = [v["id"] for v in st["videos"].values() if v["stage"] == "check"]
    if not ids:
        return
    with edit() as s2:
        for i in ids:
            x = s2["videos"].get(i)
            if x and x["stage"] == "check":
                x["stage"] = "review"
                x["last_check"] = None
                add_log(s2, "check", f"자동 판단으로 넘김: {x.get('title') or x['name']}", x["channel"], i)
        for a in s2["alerts"]:
            if a.get("video") in ids and str(a.get("title", "")).startswith("공개 전 확인 필요"):
                a["ack"] = True


def _step_precheck(cfg):
    """공개 1시간 전에 한 번 더 검사 (저작권 클레임은 늦게 붙기도 해요)"""
    st = load_state()
    now = datetime.now()
    for v in [v for v in st["videos"].values() if v["stage"] == "scheduled" and not v.get("prechecked")]:
        if not v.get("publish_at") or _parse_local(v["publish_at"]) - now > timedelta(minutes=70):
            continue
        ch = get_channel(cfg, v["channel"])
        if not ch:
            continue
        try:
            item = youtube.get_video(ch["name"], v["yt_id"])
        except Exception:
            continue
        with edit() as s2:
            s2["videos"][v["id"]]["prechecked"] = True
        _save_report(v["id"], ch, item)
        blocks, risks = review.remote_risks(item)
        confirmed = set(v.get("confirmed") or [])
        risks = [r for r in risks if r not in confirmed]
        if not blocks and not risks:
            continue
        try:
            youtube.unschedule(ch["name"], v["yt_id"])
        except Exception:
            pass
        if blocks:
            _problem(v["id"], ["공개 직전 검사에서 발견 · 공개하면 안 돼요: " + b for b in blocks], cfg, "공개 1시간 전 검사")
        else:
            _need_check(v["id"], [{"lv": "risk", "t": "공개 직전 검사에서 발견: " + r} for r in risks], cfg)


def _step_published(cfg):
    st = load_state()
    now = datetime.now()
    for v in [v for v in st["videos"].values() if v["stage"] == "scheduled"]:
        if not v.get("publish_at") or _parse_local(v["publish_at"]) > now - timedelta(minutes=2):
            continue
        if v.get("last_check") and (now - _parse_local(v["last_check"])).total_seconds() < 120:
            continue
        ch = get_channel(cfg, v["channel"])
        with edit() as s2:
            s2["videos"][v["id"]]["last_check"] = now.strftime("%Y-%m-%dT%H:%M:%S")
        try:
            item = youtube.get_video(ch["name"], v["yt_id"])
        except Exception:
            continue
        if item and item["status"].get("privacyStatus") == "public":
            with edit() as s2:
                s2["videos"][v["id"]]["stage"] = "published"
                s2["videos"][v["id"]]["published_at"] = now_iso()
                add_log(s2, "public", f"공개됨: {v['title']}", ch["name"], v["id"])
            _cleanup_drive_copy(v)
        elif _parse_local(v["publish_at"]) < now - timedelta(minutes=30):
            _problem(v["id"], ["예약 시각이 지났는데 공개되지 않았습니다",
                               "미검증 API 잠금일 가능성이 큽니다 — YouTube Studio에서 확인"], cfg, "공개 확인")


def _step_growth(cfg):
    """6시간마다 채널 조회수·수익 창출 진행도 갱신 + 하루 개수 자동 조정"""
    for ch in cfg["channels"]:
        if youtube.is_connected(ch["name"]) and growth.due(ch["name"]):
            try:
                growth.refresh(ch["name"], deep=True)
            except Exception as e:
                with edit() as st:
                    add_log(st, "error", f"채널 정보 갱신 실패: {e}", ch["name"])
                    info = st["channel_info"].setdefault(ch["name"], {}) or {}
                    info["last_growth"] = now_iso()
                    st["channel_info"][ch["name"]] = info


# ───────────────────────── 48시간 조회수 (매시간 채널 총 조회수를 찍어 두고 차이로 계산) ─────────────────────────
SNAP_EVERY = 60 * 60  # 1시간
SNAP_KEEP_DAYS = 15


def snap_channel(name, st=None):
    """지금 채널 총 조회수·구독자를 한 번 찍어 둠 (유튜브 할당량 1)"""
    info = youtube.channel_info(name)
    if not info:
        return None
    now = datetime.now()
    with edit() as s2:
        arr = s2.setdefault("snaps", {}).setdefault(name, [])
        arr.append([now.strftime("%Y-%m-%dT%H:%M"), int(info.get("views") or 0), int(info.get("subs") or 0)])
        cut = (now - timedelta(days=SNAP_KEEP_DAYS)).strftime("%Y-%m-%dT%H:%M")
        s2["snaps"][name] = [x for x in arr if x[0] >= cut]
        cur = s2["channel_info"].get(name) or {}
        cur.update({k: info[k] for k in ("views", "subs", "videos", "title", "handle") if k in info})
        s2["channel_info"][name] = cur
    return info


_upd = {"next": time.time() + 120, "last": None, "msg": ""}


def _step_autoupdate(cfg):
    """완전 자동 업데이트: 3시간마다 GitHub 페이지에서 새 버전 확인 → 있으면 받아서 적용하고 다시 켜기
    (영상을 올리는 중이면 끝난 뒤로 미룸)"""
    from . import updater
    if not cfg.get("auto_update", True) or time.time() < _upd["next"]:
        return
    _upd["next"] = time.time() + updater.CHECK_EVERY
    _upd["last"] = now_iso()
    try:
        info = updater.check_remote()
    except Exception as e:
        _upd["msg"] = f"확인 못 함: {str(e)[:120]}"
        return
    v = str(info.get("version", ""))
    if not v or not updater.is_newer(v):
        _upd["msg"] = "최신 버전이에요"
        return
    st = load_state()
    if any(x.get("stage") == "uploading" for x in st["videos"].values()):
        _upd["next"] = time.time() + 10 * 60
        _upd["msg"] = f"v{v} 발견 · 업로드가 끝나면 업데이트해요"
        return
    try:
        r = updater.download_and_apply(info)
    except Exception as e:
        _upd["msg"] = f"업데이트 실패: {str(e)[:150]}"
        with edit() as s2:
            add_log(s2, "error", f"자동 업데이트 실패 (v{v}): {str(e)[:200]}")
        return
    with edit() as s2:
        add_log(s2, "update", f"자동 업데이트: v{r['old']} → v{r['new']} {info.get('notes') or ''}".strip())
    updater.restart()
    os._exit(0)


def check_update_now():
    _upd["next"] = 0


def _step_snaps(cfg):
    st = load_state()
    now = datetime.now()
    for ch in cfg["channels"]:
        if not youtube.is_connected(ch["name"]):
            continue
        arr = (st.get("snaps") or {}).get(ch["name"]) or []
        if arr and (now - _parse_local(arr[-1][0])).total_seconds() < SNAP_EVERY:
            continue
        try:
            snap_channel(ch["name"])
        except Exception:
            pass


def views48(st, name):
    """최근 48시간 조회수 = 지금 총 조회수 − 48시간 전 총 조회수 (기록이 짧으면 있는 만큼)"""
    arr = (st.get("snaps") or {}).get(name) or []
    if not arr:
        return {"views48": None, "hours": 0, "points": []}
    now = datetime.now()
    last = arr[-1]
    since = (now - timedelta(hours=48)).strftime("%Y-%m-%dT%H:%M")
    before = [x for x in arr if x[0] <= since]
    base = before[-1] if before else arr[0]
    hours = round((_parse_local(last[0]) - _parse_local(base[0])).total_seconds() / 3600, 1)
    pts = [x for x in arr if x[0] >= base[0]]
    return {"views48": max(0, last[1] - base[1]), "subs48": last[2] - base[2], "hours": hours,
            "total": last[1], "subs": last[2], "at": last[0],
            "points": [[x[0], x[1] - base[1]] for x in pts]}


def _step_gdrive(cfg):
    """구글 드라이브(인터넷) 폴더 채널: 아직 안 받은 영상을 오래된 것부터 몇 개씩 미리 내려받음"""
    chs = [c for c in cfg["channels"] if (c.get("gdrive") or {}).get("id")]
    if not chs or not gdrive.is_connected():
        return
    now = datetime.now()
    st = load_state()
    for ch in chs:
        g = (st.get("gdrive") or {}).get(ch["name"]) or {}
        if g.get("folder") != ch["gdrive"]["id"]:
            g = {"folder": ch["gdrive"]["id"], "got": []}
        if g.get("checked") and not g.get("more") and (now - _parse_local(g["checked"])).total_seconds() < 180:
            continue
        g["more"] = False
        try:
            files = gdrive.folder_files(ch["gdrive"]["id"])
            got = set(g.get("got") or [])
            pending = [f for f in files if gdrive._is_video(f) and f["id"] not in got]
            free = sum(1 for f in scan_channel(ch, st) if f["stage"] == "free")
            target = max(len(_times(ch)) * 2, 3)
            if pending and free < target:
                f = pending[0]
                _busy["what"] = f"구글 드라이브에서 받는 중: {f['name']}"
                dest = gdrive.cache_dir(ch["name"])
                # 예전에 올린 영상과 이름이 같으면 (2), (3)… 을 붙여 새 영상으로 인식되게
                base = gdrive.safe_name(f["name"])
                stem, ext = Path(base).stem, Path(base).suffix
                name, k = base, 1
                while (dest / name).exists() or video_id_for(dest / name) in st["videos"]:
                    k += 1
                    name = f"{stem} ({k}){ext}"
                new_stem = Path(name).stem
                for c in gdrive.companions(files, f):
                    try:
                        gdrive.download(c, dest, gdrive.safe_name(new_stem + c["name"][len(Path(f["name"]).stem):]))
                    except Exception:
                        pass
                gdrive.download(f, dest, name)
                got.add(f["id"])
                pending = pending[1:]
                g["more"] = bool(pending) and free + 1 < target
                with edit() as s2:
                    add_log(s2, "drive", f"구글 드라이브에서 받아 옴: {f['name']}", ch["name"])
            g.update(got=sorted(got), left=len(pending), error="", error_url="")
        except gdrive.DriveOff as e:
            g.update(error=str(e), error_url=e.url)
        except Exception as e:
            g.update(error=str(e)[:200], error_url="")
        g["checked"] = now.strftime("%Y-%m-%dT%H:%M:%S")
        with edit() as s2:
            old_err = ((s2.get("gdrive") or {}).get(ch["name"]) or {}).get("error")
            s2.setdefault("gdrive", {})[ch["name"]] = g
            if g.get("error") and g["error"] != old_err:
                add_alert(s2, "warn", f"{ch['name']} 구글 드라이브 영상을 못 받아 왔어요", g["error"], channel=ch["name"])
        st = load_state()
        if g.get("more"):
            kick()


def _cleanup_drive_copy(v):
    """공개된 영상의 '내려받은 사본'은 지워서 컴퓨터 공간 아끼기 (드라이브 원본은 그대로)"""
    try:
        p = Path(v.get("file") or "").resolve()
        if str(p).startswith(str(gdrive.CACHE.resolve())) and p.is_file():
            p.unlink()
    except Exception:
        pass


def tick():
    cfg = load_config()
    for step in (_step_autoupdate, _step_gdrive, _step_snaps, _step_growth, _step_daily_auto, _step_meta, _step_upload, _step_autojudge, _step_review, _step_precheck, _step_published):
        try:
            step(cfg)
        except Exception as e:
            with edit() as st:
                add_log(st, "error", f"{step.__name__}: {e}")
            traceback.print_exc()
        finally:
            _busy["what"] = ""


def kick():
    _kick.set()


def busy():
    return _busy["what"]


def start():
    def loop():
        # 재시작 시 '올리는 중'에 멈춘 것은 다시 대기열로
        with edit() as st:
            for v in st["videos"].values():
                if v["stage"] == "uploading":
                    v["stage"] = "queued"
                if v.get("meta_status") == "working":
                    v["meta_status"] = "none"
        while True:
            tick()
            _kick.wait(20)
            _kick.clear()

    t = threading.Thread(target=loop, daemon=True)
    t.start()
