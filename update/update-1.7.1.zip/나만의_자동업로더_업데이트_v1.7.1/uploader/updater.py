"""업데이트 파일(.zip) 하나로 업데이트하기

- 받은 zip(업데이트용·Windows용·Mac용·원본 아무거나) 안에서 app.py 가 있는 폴더를 찾아
  프로그램 파일만 덮어씀. 내 설정·채널 연결·구글 열쇠·받은 영상·설치물은 절대 안 건드림.
- requirements.txt 가 바뀌었으면 필요한 부품을 자동으로 설치
- 끝나면 업로더를 껐다가 다시 켬 (화면은 저절로 새로 고쳐짐)
"""
import io
import os
import stat
import subprocess
import sys
import zipfile
from pathlib import Path, PurePosixPath

from .store import BASE

VERSION_FILE = BASE / "VERSION"
# 자동 업데이트: 나눠 준 사람의 GitHub 페이지에 올린 안내 파일 (latest.json)
UPDATE_URL = "https://womantechcs-boop.github.io/update/latest.json"
CHECK_EVERY = 3 * 60 * 60  # 3시간마다 확인
HEADLESS = False  # 화면 없이 켜진 업로더(컴퓨터 켤 때 자동 실행)면 True → 다시 켤 때도 화면 없이
# 업데이트해도 절대 덮어쓰지 않는 것 (개인 정보·설치물·받은 영상)
PROTECT = {"config.json", "client_secret.json", "data", "tokens", ".venv", "배포",
           "구글드라이브_받은영상", "__pycache__", ".git"}


def version(base=BASE):
    try:
        return (Path(base) / "VERSION").read_text(encoding="utf-8").strip() or "0"
    except Exception:
        return "0"


def _vtuple(v):
    out = []
    for x in str(v).lstrip("vV").split("."):
        try:
            out.append(int(x))
        except ValueError:
            out.append(0)
    return tuple(out)


def _root_in_zip(names):
    """zip 안에서 app.py 가 있는 폴더 (예: '나만의_자동업로더_Windows/')"""
    cands = [n[: -len("app.py")] for n in names if n == "app.py" or n.endswith("/app.py")]
    if not cands:
        raise RuntimeError("업데이트 파일이 아니에요. '나만의_자동업로더' 압축 파일(.zip)을 골라 주세요")
    return min(cands, key=len)


def apply_zip(data: bytes):
    """zip 내용(bytes)으로 업데이트. 반환: {"old","new","files","pip"}"""
    try:
        z = zipfile.ZipFile(io.BytesIO(data))
    except zipfile.BadZipFile:
        raise RuntimeError("압축 파일(.zip)이 아니거나 망가졌어요. 다시 받아 주세요")
    names = [n for n in z.namelist() if not n.endswith("/")]
    root = _root_in_zip(names)
    new_ver = "0"
    if root + "VERSION" in names:
        new_ver = z.read(root + "VERSION").decode("utf-8", "ignore").strip() or "0"
    old_ver = version()
    old_req = (BASE / "requirements.txt").read_bytes() if (BASE / "requirements.txt").exists() else b""

    count = 0
    backup = BASE / "data" / "backup" / f"v{old_ver}"
    for n in names:
        if not n.startswith(root):
            continue
        rel = PurePosixPath(n[len(root):])
        if not rel.parts or rel.parts[0] in PROTECT or rel.suffix in (".pyc", ".log"):
            continue
        if ".." in rel.parts:
            continue
        dest = BASE.joinpath(*rel.parts)
        body = z.read(n)
        if dest.is_file():  # 혹시 몰라 예전 파일은 data/backup/v예전버전 에 보관
            try:
                b = backup.joinpath(*rel.parts)
                if not b.exists():
                    b.parent.mkdir(parents=True, exist_ok=True)
                    b.write_bytes(dest.read_bytes())
            except Exception:
                pass
        dest.parent.mkdir(parents=True, exist_ok=True)
        tmp = dest.with_name(dest.name + ".new")
        tmp.write_bytes(body)
        os.replace(tmp, dest)
        if dest.suffix in (".command", ".sh"):
            try:
                dest.chmod(dest.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
            except Exception:
                pass
        count += 1

    pip_msg = ""
    new_req = (BASE / "requirements.txt").read_bytes() if (BASE / "requirements.txt").exists() else b""
    if new_req != old_req:
        try:
            py = sys.executable.replace("pythonw.exe", "python.exe")
            r = subprocess.run([py, "-m", "pip", "install", "-q", "-r", str(BASE / "requirements.txt")],
                               cwd=str(BASE), capture_output=True, text=True, timeout=900,
                               creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            pip_msg = "필요한 부품도 새로 설치했어요" if r.returncode == 0 else "부품 설치 중 문제: " + (r.stderr or r.stdout)[-300:]
        except Exception as e:
            pip_msg = f"부품 설치 중 문제: {e}"
    try:  # 전용 창 부품이 없으면 한 번 깔아 봄 (실패해도 괜찮아요: 크롬 앱 창으로 열림)
        import importlib.util
        if importlib.util.find_spec("webview") is None:
            py = sys.executable.replace("pythonw.exe", "python.exe")
            subprocess.run([py, "-m", "pip", "install", "-q", "pywebview>=5.0"], cwd=str(BASE), capture_output=True,
                           timeout=600, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    except Exception:
        pass
    return {"old": old_ver, "new": new_ver, "files": count, "pip": pip_msg,
            "older": _vtuple(new_ver) < _vtuple(old_ver)}


def check_remote(url=None):
    """GitHub 페이지의 latest.json 읽기 → {"version","url","sha256","notes"}"""
    import requests
    r = requests.get(url or UPDATE_URL, timeout=15, headers={"Cache-Control": "no-cache"})
    r.raise_for_status()
    info = r.json()
    from urllib.parse import urljoin
    info["url"] = urljoin(url or UPDATE_URL, info.get("url") or "")
    return info


def is_newer(v):
    return _vtuple(v) > _vtuple(version())


def download_and_apply(info):
    """업데이트 파일 받기 → 지문(sha256) 확인 → 적용"""
    import hashlib
    import requests
    r = requests.get(info["url"], timeout=120)
    r.raise_for_status()
    data = r.content
    want = (info.get("sha256") or "").lower()
    if want and hashlib.sha256(data).hexdigest() != want:
        raise RuntimeError("받은 업데이트 파일이 망가졌어요 (지문이 달라요). 다음에 다시 시도할게요")
    return apply_zip(data)


def restart():
    """업로더를 새로 켜고 (지금 것은 곧 꺼짐) — 새 것은 포트가 빌 때까지 기다렸다가 켜짐"""
    args = [sys.executable, str(BASE / "app.py"), "--wait-port"]  # 새 버전 창이 다시 열림
    if HEADLESS:
        args.append("--no-browser")
    kw = {"cwd": str(BASE), "close_fds": True}
    if os.name == "nt":
        kw["creationflags"] = 0x00000008 | 0x00000200  # DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
    else:
        kw["start_new_session"] = True
    subprocess.Popen(args, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, **kw)
