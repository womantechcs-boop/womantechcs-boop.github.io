﻿# 나만의 자동 업로더 - 설치·업데이트 도우미 (설치하기.bat 이 부름)
# 1) 켜져 있는 업로더 끄기  2) 예전에 다른 폴더에 설치한 업로더가 있으면 내 설정을 가져오기
# 3) 프로그램 파일을 정해진 설치 폴더(DEST)로 복사 (내 설정·연결·열쇠는 절대 안 건드림)
param([string]$Src, [string]$Dest)
$ErrorActionPreference = 'SilentlyContinue'
$Src = (Resolve-Path -LiteralPath $Src).Path.TrimEnd('\'); $Dest = $Dest.TrimEnd('\')

# 1) 켜져 있는 업로더 끄기
try { Invoke-WebRequest -UseBasicParsing -Method Post -Uri 'http://127.0.0.1:5577/api/quit' -TimeoutSec 3 -ContentType 'application/json' -Body '{}' | Out-Null; Start-Sleep -Seconds 2 } catch {}
Get-CimInstance Win32_Process -Filter "Name like 'python%'" | Where-Object { $_.CommandLine -like '*app.py*' -and ($_.CommandLine -like '*자동업로더*' -or $_.CommandLine -like '*auto-uploader*' -or $_.CommandLine -like '*MyAutoUploader*') } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }

New-Item -ItemType Directory -Force -Path $Dest | Out-Null

# 2) 예전 설치 찾기 (처음 이 방식으로 설치할 때 한 번만)
if (-not (Test-Path (Join-Path $Dest 'config.json'))) {
  $c = @()
  $lnk = Join-Path ([Environment]::GetFolderPath('Desktop')) '나만의 자동 업로더.lnk'
  if (Test-Path $lnk) { $c += (New-Object -ComObject WScript.Shell).CreateShortcut($lnk).WorkingDirectory }
  $vbs = Join-Path ([Environment]::GetFolderPath('Startup')) '나만의 자동 업로더.vbs'
  if (Test-Path $vbs) { $m = [regex]::Match((Get-Content $vbs -Raw), 'CurrentDirectory = "([^"]+)"'); if ($m.Success) { $c += $m.Groups[1].Value } }
  $c += $Src
  Get-ChildItem -LiteralPath $env:USERPROFILE -Directory -ErrorAction SilentlyContinue | Where-Object { Test-Path (Join-Path $_.FullName 'config.json') } | ForEach-Object { $c += $_.FullName }
  foreach ($root in @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('MyDocuments'), (Join-Path $env:USERPROFILE 'Downloads'))) {
    if (Test-Path $root) {
      Get-ChildItem -LiteralPath $root -Filter 'config.json' -Recurse -Depth 5 -File -ErrorAction SilentlyContinue |
        Where-Object { Test-Path (Join-Path $_.DirectoryName 'app.py') } | ForEach-Object { $c += $_.DirectoryName }
    }
  }
  # 채널 연결(tokens)·열쇠·채널이 제일 많은 것 → 같으면 최근 것 (빈 새 설치를 고르지 않게)
  function Score($d) {
    $n = 0
    $t = Join-Path $d 'tokens'; if (Test-Path $t) { $n += 100 * @(Get-ChildItem -LiteralPath $t -File).Count }
    if (Test-Path (Join-Path $d 'client_secret.json')) { $n += 50 }
    try { $n += 10 * @((Get-Content -LiteralPath (Join-Path $d 'config.json') -Raw -Encoding UTF8 | ConvertFrom-Json).channels).Count } catch {}
    return $n
  }
  $best = $c | Where-Object { $_ -and ($_.TrimEnd('\') -ne $Dest) -and (Test-Path (Join-Path $_ 'config.json')) -and (Test-Path (Join-Path $_ 'app.py')) } |
    Sort-Object -Unique | Sort-Object @{ Expression = { Score $_ }; Descending = $true }, @{ Expression = { (Get-Item (Join-Path $_ 'config.json')).LastWriteTime }; Descending = $true } |
    Select-Object -First 1
  if ($best) {
    Write-Host "   예전 업로더의 설정을 가져와요: $best"
    foreach ($f in @('config.json', 'client_secret.json')) { if (Test-Path (Join-Path $best $f)) { Copy-Item -LiteralPath (Join-Path $best $f) -Destination $Dest -Force } }
    foreach ($d in @('tokens', 'data', '구글드라이브_받은영상')) {
      if (Test-Path (Join-Path $best $d)) { robocopy (Join-Path $best $d) (Join-Path $Dest $d) /E /NFL /NDL /NJH /NJS /NP | Out-Null }
    }
    Set-Content -LiteralPath (Join-Path $Dest 'data\옮겨온_곳.txt') -Value $best -Encoding UTF8
  }
}

# 3) 프로그램 파일 복사 (설치 폴더에서 바로 누른 거면 건너뜀)
if ($Src -ne $Dest) {
  robocopy $Src $Dest /E /NFL /NDL /NJH /NJS /NP /XD .venv data tokens 배포 구글드라이브_받은영상 __pycache__ .git /XF config.json client_secret.json | Out-Null
}
exit 0
