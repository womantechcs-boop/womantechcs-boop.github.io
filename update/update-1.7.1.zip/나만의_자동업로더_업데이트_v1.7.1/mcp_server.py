"""나만의 자동 업로더 ↔ Claude 연결 (MCP 서버)

Claude 데스크톱 앱(또는 Claude Code)이 이 파일을 실행해서 업로더를 조종해요.
업로더(app.py, 127.0.0.1:5577)에 말을 거는 얇은 다리일 뿐이라, 실제 일은 업로더가 해요.
업로더가 꺼져 있으면 화면 없이 조용히 켜요.

연결은 업로더 ⚙️ 설정 → 🤖 Claude와 연결하기 (uploader/setup.py connect_claude) 가 해 줘요.
"""
import json
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

BASE = Path(__file__).resolve().parent
URL = "http://127.0.0.1:5577"

try:  # mcp 1.x
    from mcp.server.fastmcp import FastMCP as _Server
except Exception:  # mcp 2.x
    from mcp.server.mcpserver import MCPServer as _Server

INSTRUCTIONS = (
    "나만의 자동 업로더(유튜브 자동 업로드 프로그램)를 조종하는 도구예요. "
    "업로더·채널·영상·예약·조회수에 관한 일은 PowerShell이나 파일 탐색 같은 명령 대신 꼭 이 도구들을 먼저 쓰세요. "
    "저작권·소유권 판단은 업로더가 스스로 해요(list_videos의 copyright_judgement). 사용자에게 스튜디오에서 직접 확인하라고 하지 말고, 그 판단을 쉽게 전해 주세요. "
    "썸네일이 안 들어가면 유튜브 채널 휴대폰 인증(https://www.youtube.com/verify, 구글 2단계 인증과 다름)이 필요하다고 알려 주세요. "
    "영상을 유튜브에서 지우거나 내리는 일(video_action의 delete_youtube, hold)은 하기 전에 사용자에게 먼저 물어보세요. "
    "사용자는 40~60대일 수 있으니 쉬운 한국어로 짧게 답하세요."
)
try:
    mcp = _Server("my-auto-uploader", instructions=INSTRUCTIONS)
except TypeError:
    mcp = _Server("my-auto-uploader")


# ───────────────────────── 업로더에 말 걸기 ─────────────────────────
def _alive():
    try:
        urllib.request.urlopen(URL + "/api/version", timeout=2).read()
        return True
    except Exception:
        return False


def _ensure_running():
    if _alive():
        return
    py = sys.executable.replace("python.exe", "pythonw.exe") if sys.platform == "win32" else sys.executable
    kw = {"cwd": str(BASE), "stdin": subprocess.DEVNULL, "stdout": subprocess.DEVNULL, "stderr": subprocess.DEVNULL}
    if sys.platform == "win32":
        kw["creationflags"] = 0x00000008 | 0x00000200
    else:
        kw["start_new_session"] = True
    subprocess.Popen([py, str(BASE / "app.py"), "--no-browser"], **kw)
    for _ in range(40):
        time.sleep(0.5)
        if _alive():
            return
    raise RuntimeError("업로더를 켜지 못했어요. 바탕화면 아이콘으로 업로더를 켠 뒤 다시 시켜 주세요")


def _get(path, **params):
    _ensure_running()
    q = ("?" + urllib.parse.urlencode({k: v for k, v in params.items() if v is not None})) if params else ""
    with urllib.request.urlopen(URL + path + q, timeout=60) as r:
        return json.loads(r.read().decode("utf-8"))


def _post(path, body=None):
    _ensure_running()
    req = urllib.request.Request(URL + path, data=json.dumps(body or {}).encode("utf-8"),
                                 headers={"Content-Type": "application/json"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=120) as r:
            return json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        try:
            return json.loads(e.read().decode("utf-8"))
        except Exception:
            return {"ok": False, "error": str(e)}


STAGE_KO = {"basket": "고른 영상", "queued": "업로드 대기", "uploading": "올리는 중", "review": "심사 대기",
            "check": "확인 필요", "problem": "문제", "scheduled": "공개 예정", "published": "공개됨"}


# ───────────────────────── Claude가 쓸 수 있는 일 ─────────────────────────
@mcp.tool()
def get_status() -> dict:
    """업로더 전체 상태를 봐요: 버전, 채널마다 오늘 올린 수·예약·재고·유튜브 연결·등급(깡통/1차/2차 수창), 문제·경고 수, 지금 하는 일."""
    s = _get("/api/state")
    v = _get("/api/version")
    vids = s.get("videos", [])
    return {
        "version": v.get("version"),
        "now_doing": s.get("busy") or "",
        "problems": sum(1 for x in vids if x.get("stage") == "problem"),
        "needs_check": sum(1 for x in vids if x.get("stage") == "check"),
        "alerts": [{"id": a["id"], "title": a.get("title"), "detail": a.get("detail")} for a in s.get("alerts", [])][:10],
        "channels": [{
            "name": c["name"], "connected": c.get("connected"),
            "tier": ["깡통", "1차 수창", "2차 수창"][min(int(c.get("tier") or 0), 2)],
            "today_uploaded": c.get("today_uploaded"), "reserved": c.get("reserved"), "stock": c.get("stock"),
            "per_day": c.get("per_day"), "publish_times": c.get("publish_times"), "total_views": c.get("views"),
        } for c in s.get("channels", [])],
    }


@mcp.tool()
def list_videos(channel: str = "", stage: str = "") -> list:
    """영상 목록을 봐요. channel(채널 이름)이나 stage(queued, review, check, problem, scheduled, published 등)로 거를 수 있어요."""
    s = _get("/api/state")
    out = []
    for v in s.get("videos", []):
        if channel and v.get("channel") != channel:
            continue
        if stage and v.get("stage") != stage:
            continue
        out.append({"id": v["id"], "channel": v.get("channel"), "title": v.get("title") or v.get("name"),
                    "stage": STAGE_KO.get(v.get("stage"), v.get("stage")), "stage_code": v.get("stage"),
                    "publish_at": v.get("publish_at"), "youtube_id": v.get("yt_id"),
                    "problem": v.get("problem") or v.get("problems") or v.get("issues"),
                    "copyright_judgement": v.get("judge") or ""})
    return out[:100]


@mcp.tool()
def upload_from_folder(channel: str, count: int = 1, start_date: str = "") -> dict:
    """채널 폴더에서 아직 안 올린 영상을 오래된 것부터 count개 골라 올려요.
    정해 둔 공개 시간에 하루 몇 개씩 공개돼요. start_date(YYYY-MM-DD)를 주면 그날부터 공개해요."""
    return _post("/api/upload_folder", {"channel": channel, "count": int(count), "date": start_date or None})


@mcp.tool()
def set_publish_times(channel: str, times: list[str]) -> dict:
    """채널의 매일 공개 시간을 바꿔요. 예: ["12:00", "19:00"] → 하루 2개."""
    return _post("/api/channel/times", {"name": channel, "times": times, "manual": True})


@mcp.tool()
def video_action(video_id: str, action: str) -> dict:
    """영상 하나를 처리해요. action:
    approve(문제 무시하고 공개 진행), confirm(저작권 확인 끝, 공개 진행), hold(비공개로 멈추기),
    retry(다시 올리기), regen_meta(제목·설명 다시 만들기), remove(목록에서 빼기), delete_youtube(유튜브에서 지우기)."""
    return _post("/api/video/action", {"id": video_id, "action": action})


@mcp.tool()
def channel_report(channel: str, days: int = 28) -> dict:
    """채널 성적표: 누적 조회수·구독자, 기간(days일) 조회수·시청 시간·구독 증감, 최근 영상 30개 조회수, 수익(권한 있을 때)."""
    d = _get("/api/stats", channel=channel, days=int(days))
    if d.get("ok") and d.get("recent"):
        d["recent"] = [{k: v.get(k) for k in ("title", "published", "views", "likes", "comments")} for v in d["recent"]]
    return d


@mcp.tool()
def views_48h() -> dict:
    """연결된 모든 채널의 최근 48시간 조회수와 합계를 봐요."""
    d = _get("/api/views48")
    for c in d.get("channels", []):
        c.pop("points", None)
        c.pop("daily", None)
    return d


@mcp.tool()
def ack_alert(alert_id: str) -> dict:
    """알림 하나를 '확인함'으로 치워요 (get_status의 alerts에 있는 id)."""
    return _post("/api/alert/ack", {"id": alert_id})


@mcp.tool()
def set_night_lock(enabled: bool) -> dict:
    """심야(밤 12시~아침 7시) 업로드 금지를 켜거나 꺼요."""
    return _post("/api/settings", {"night_lock": {"enabled": bool(enabled)}})


@mcp.tool()
def check_update_now() -> dict:
    """GitHub에 새 버전이 있는지 바로 확인하고, 있으면 자동으로 업데이트해요."""
    return _post("/api/update/check", {})


if __name__ == "__main__":
    mcp.run()
