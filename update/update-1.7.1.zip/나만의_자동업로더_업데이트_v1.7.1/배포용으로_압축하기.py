"""나눠 줄 압축 파일 만들기 (Windows용, Mac용)

사용법:  python 배포용으로_압축하기.py
결과:    배포/나만의 자동 업로더 설치하기.zip  ← 이것 하나만 나눠 주면 돼요. 안에:
           나만의_자동업로더_Windows.zip / 나만의_자동업로더_Mac.zip
           나만의_자동업로더_업데이트_Windows_v버전.zip / 나만의_자동업로더_업데이트_Mac_v버전.zip
           나만의_자동업로더_원본_고치는용.zip
           나만의_자동업로더_설명서_전체.html
         (각각 따로도 배포/ 폴더에 만들어져요)

버전 올리기: VERSION 파일의 숫자를 바꾼 뒤 이 파일을 실행하세요.
이미 설치한 사람도 새 압축을 풀고 '설치하기'만 두 번 누르면 업데이트 끝
(항상 내 사용자 폴더의 'MyAutoUploader'에 설치되고, 내 설정·연결은 그대로 남아요).

내 설정·채널 연결·구글 열쇠는 자동으로 빠져요.
"""
import os
import time
import stat
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
OUT = HERE / "배포"
NAME = "나만의_자동업로더"

# 절대 넣지 않을 것 (개인 정보·설치물)
EXCLUDE_NAMES = {".venv", "data", "tokens", "config.json", "client_secret.json", "__pycache__",
                 "배포", ".git", ".DS_Store", ".vscode", ".idea", "구글드라이브_받은영상"}
EXCLUDE_SUFFIX = {".pyc", ".log", ".tmp", ".broken"}

GUIDE = "나만의_자동업로더_설명서_전체.html"
COMMON = ["VERSION", "app.py", "mcp_server.py", "requirements.txt", "uploader", "static", "고치는_방법.md", "CLAUDE.md",
          "배포용으로_압축하기.py", ".gitignore", GUIDE]
ONLY = {
    "Windows": ["설치하기.bat", "install_tools", "설치_안내서_Windows.txt"],
    "Mac": ["설치하기.command", "설치_안내서_Mac.txt"],
}


def _files(rel):
    p = HERE / rel
    if not p.exists():
        return
    if p.is_file():
        yield p
        return
    for root, dirs, files in os.walk(p):
        dirs[:] = [d for d in dirs if d not in EXCLUDE_NAMES]
        for f in files:
            fp = Path(root) / f
            if f in EXCLUDE_NAMES or fp.suffix in EXCLUDE_SUFFIX or ".broken-" in f:
                continue
            yield fp


def check():
    """빠진 파일이 있으면 알려 줌 (원본 폴더에서 실행해야 두 가지 다 만들어져요)"""
    missing = [r for r in COMMON + ONLY["Windows"] + ONLY["Mac"] if not (HERE / r).exists() and r != ".gitignore"]
    if missing:
        print("⚠ 이 파일이 없어요:", ", ".join(missing))
        print("  '원본(고치는용)' 폴더에서 실행해야 Windows·Mac 둘 다 제대로 만들어져요.")


def build(os_name):
    OUT.mkdir(exist_ok=True)
    zpath = OUT / f"{NAME}_{os_name}.zip"
    top = f"{NAME}_{os_name}"
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
        for rel in COMMON + ONLY[os_name]:
            for fp in _files(rel):
                arc = f"{top}/{fp.relative_to(HERE).as_posix()}"
                info = zipfile.ZipInfo(arc, date_time=time.localtime(fp.stat().st_mtime)[:6])
                info.compress_type = zipfile.ZIP_DEFLATED
                mode = 0o755 if fp.suffix in (".command", ".sh") else 0o644
                info.external_attr = (stat.S_IFREG | mode) << 16
                z.writestr(info, fp.read_bytes())
    return zpath


def version():
    try:
        return (HERE / "VERSION").read_text(encoding="utf-8").strip()
    except Exception:
        return "0"


def _add(z, fp, arc):
    info = zipfile.ZipInfo(arc, date_time=time.localtime(fp.stat().st_mtime)[:6])
    info.compress_type = zipfile.ZIP_DEFLATED
    mode = 0o755 if fp.suffix in (".command", ".sh") else 0o644
    info.external_attr = (stat.S_IFREG | mode) << 16
    z.writestr(info, fp.read_bytes())


def build_update():
    """이미 설치한 사람용 업데이트 파일 (프로그램 파일만, Windows·Mac 공용)"""
    OUT.mkdir(exist_ok=True)
    for old in OUT.glob(f"{NAME}_업데이트_v*.zip"):
        old.unlink()
    zpath = OUT / f"{NAME}_업데이트_v{version()}.zip"
    top = f"{NAME}_업데이트_v{version()}"
    # 설치하기.bat/.command 는 일부러 뺌: 풀어서 설치하기를 누르면 '새 업로더'가 따로 생겨 처음 상태처럼 보이기 때문
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr(f"{top}/⚠ 풀지 마세요 - 업로더 설정에서 고르세요.txt",
                   "이 파일은 설치 파일이 아니에요.\r\n\r\n"
                   "압축을 풀지 말고, 업로더를 켠 뒤\r\n"
                   "  ⚙️ 설정 → 🔄 업데이트하기 → [📦 업데이트 파일 고르기]\r\n"
                   "에서 이 zip 파일을 그대로 골라 주세요.\r\n\r\n"
                   "내 채널·연결·설정은 그대로 남고 프로그램만 새 버전으로 바뀌어요.\r\n")
        for rel in COMMON:
            for fp in _files(rel):
                _add(z, fp, f"{top}/{fp.relative_to(HERE).as_posix()}")
    return zpath


def build_update_os(os_name):
    """업데이트 전용 파일: 압축을 풀고 '업데이트하기'를 두 번 누르면 내 설정은 그대로 두고 새 버전으로만 바뀜
    (설치하기와 같은 일을 하지만, 이름을 '업데이트하기'로 해서 헷갈리지 않게)"""
    OUT.mkdir(exist_ok=True)
    for old in OUT.glob(f"{NAME}_업데이트_{os_name}_v*.zip"):
        old.unlink()
    v = version()
    zpath = OUT / f"{NAME}_업데이트_{os_name}_v{v}.zip"
    top = f"{NAME}_업데이트_{os_name}_v{v}"
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
        for rel in COMMON + ONLY[os_name]:
            for fp in _files(rel):
                arc = fp.relative_to(HERE).as_posix()
                if arc in ("설치하기.bat", "설치하기.command"):
                    arc = arc.replace("설치하기", "업데이트하기")
                _add(z, fp, f"{top}/{arc}")
    return zpath


def build_github():
    """자동 업데이트용: 배포/GitHub에_올릴것/update/ 안에 latest.json + update-버전.zip
    → GitHub 저장소(womantechcs-boop.github.io)에 'update' 폴더째 끌어다 올리면, 모든 사람 업로더가 3시간 안에 알아서 업데이트"""
    import hashlib
    import json
    v = version()
    d = OUT / "GitHub에_올릴것" / "update"
    if d.exists():
        for f in d.iterdir():
            f.unlink()
    d.mkdir(parents=True, exist_ok=True)
    zname = f"update-{v}.zip"
    zpath = d / zname
    top = f"{NAME}_업데이트_v{v}"
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
        for rel in COMMON + ONLY["Windows"] + ONLY["Mac"]:
            for fp in _files(rel):
                _add(z, fp, f"{top}/{fp.relative_to(HERE).as_posix()}")
    sha = hashlib.sha256(zpath.read_bytes()).hexdigest()
    notes = os.environ.get("UPDATE_NOTES", "")
    (d / "latest.json").write_text(json.dumps({"version": v, "url": zname, "sha256": sha, "notes": notes},
                                              ensure_ascii=False, indent=2), encoding="utf-8")
    return d


def build_all(parts):
    """나눠 줄 묶음 하나: 나만의 자동 업로더 설치하기.zip"""
    zpath = OUT / "나만의 자동 업로더 설치하기.zip"
    top = "나만의 자동 업로더 설치하기"
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
        for fp in parts + [HERE / GUIDE]:
            _add(z, fp, f"{top}/{fp.name}")
    return zpath


def build_source():
    """고치는용 원본 (Windows·Mac 파일 모두 포함, 개인 파일은 제외)"""
    OUT.mkdir(exist_ok=True)
    zpath = OUT / f"{NAME}_원본_고치는용.zip"
    top = f"{NAME}_원본_고치는용"
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
        for rel in COMMON + ONLY["Windows"] + ONLY["Mac"]:
            for fp in _files(rel):
                arc = f"{top}/{fp.relative_to(HERE).as_posix()}"
                info = zipfile.ZipInfo(arc, date_time=time.localtime(fp.stat().st_mtime)[:6])
                info.compress_type = zipfile.ZIP_DEFLATED
                mode = 0o755 if fp.suffix in (".command", ".sh") else 0o644
                info.external_attr = (stat.S_IFREG | mode) << 16
                z.writestr(info, fp.read_bytes())  # 파이썬 zipfile은 한글 이름을 UTF-8로 표시해서 Windows에서도 안 깨져요
    return zpath


if __name__ == "__main__":
    check()
    print("버전:", version())
    for old in OUT.glob(f"{NAME}_업데이트_v*.zip"):
        old.unlink()  # 이제 따로 안 만듦: 새 Windows/Mac 압축의 '설치하기'가 곧 업데이트
    parts = [build("Windows"), build("Mac"), build_update_os("Windows"), build_update_os("Mac"), build_source()]
    for p in parts:
        print("만들었어요:", p)
    print("만들었어요 (이것 하나만 나눠 주면 돼요):", build_all(parts))
    print("자동 업데이트용 (GitHub에 'update' 폴더째 올리기):", build_github())
