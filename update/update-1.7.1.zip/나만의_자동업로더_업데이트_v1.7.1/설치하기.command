#!/bin/bash
# 나만의 자동 업로더 - 설치·업데이트 (어디서 눌러도 항상 ~/MyAutoUploader 에 설치)
SRC="$(cd "$(dirname "$0")" && pwd)"
DEST="$HOME/MyAutoUploader"
clear
echo ""
echo "  ☁  나만의 자동 업로더를 설치(업데이트)해요. 창을 닫지 말고 기다려 주세요."
echo "     이미 설치했다면 내 채널·연결·설정은 그대로 두고 새 버전으로만 바꿔요."
echo ""
xattr -dr com.apple.quarantine "$SRC" 2>/dev/null

echo "  [1/5] 프로그램 파일을 옮기고 있어요..."
# 켜져 있는 업로더 끄기
curl -s -m 3 -X POST -H 'Content-Type: application/json' -d '{}' http://127.0.0.1:5577/api/quit >/dev/null 2>&1 && sleep 2
mkdir -p "$DEST"
# 예전에 다른 폴더에 설치한 업로더가 있으면 내 설정 가져오기 (처음 한 번만)
if [ ! -f "$DEST/config.json" ]; then
  CANDS=()
  RUN="$HOME/Desktop/나만의 자동 업로더.app/Contents/MacOS/run"
  [ -f "$RUN" ] && CANDS+=("$(sed -n 's/^cd "\(.*\)"$/\1/p' "$RUN" | head -1)")
  CANDS+=("$SRC")
  while IFS= read -r f; do CANDS+=("$(dirname "$f")"); done < <(find "$HOME/Desktop" "$HOME/Documents" "$HOME/Downloads" -maxdepth 5 -name config.json 2>/dev/null)
  # 채널 연결(tokens)·열쇠가 제일 많은 것 → 같으면 최근 것 (빈 새 설치를 고르지 않게)
  BEST=""; BS=-1; BT=0
  for d in "${CANDS[@]}"; do
    [ -n "$d" ] && [ "$d" != "$DEST" ] && [ -f "$d/config.json" ] && [ -f "$d/app.py" ] || continue
    s=$(( $(ls "$d/tokens" 2>/dev/null | wc -l) * 100 ))
    [ -f "$d/client_secret.json" ] && s=$((s + 50))
    t=$(stat -f %m "$d/config.json" 2>/dev/null || echo 0)
    if [ "$s" -gt "$BS" ] || { [ "$s" -eq "$BS" ] && [ "$t" -gt "$BT" ]; }; then BS=$s; BT=$t; BEST="$d"; fi
  done
  if [ -n "$BEST" ]; then
    echo "     예전 업로더의 설정을 가져와요: $BEST"
    for f in config.json client_secret.json; do [ -f "$BEST/$f" ] && cp -p "$BEST/$f" "$DEST/"; done
    for d in tokens data 구글드라이브_받은영상; do [ -d "$BEST/$d" ] && mkdir -p "$DEST/$d" && cp -Rp "$BEST/$d/." "$DEST/$d/"; done
    mkdir -p "$DEST/data"; echo "$BEST" > "$DEST/data/옮겨온_곳.txt"
  fi
fi
if [ "$SRC" != "$DEST" ]; then
  rsync -a --exclude .venv --exclude data --exclude tokens --exclude 배포 --exclude 구글드라이브_받은영상 \
        --exclude __pycache__ --exclude .git --exclude config.json --exclude client_secret.json "$SRC/" "$DEST/"
fi
cd "$DEST" || exit 1

if [ ! -x ".venv/bin/python" ]; then
  # ── 파이썬 찾기 ──
  PY=""
  for c in /Library/Frameworks/Python.framework/Versions/3.1*/bin/python3 /opt/homebrew/bin/python3 /usr/local/bin/python3; do
    if [ -x "$c" ] && "$c" -c 'import sys; sys.exit(0 if sys.version_info>=(3,9) else 1)' 2>/dev/null; then PY="$c"; break; fi
  done
  if [ -z "$PY" ] && xcode-select -p >/dev/null 2>&1 && /usr/bin/python3 -c 'import sys; sys.exit(0 if sys.version_info>=(3,9) else 1)' 2>/dev/null; then
    PY=/usr/bin/python3
  fi
  if [ -z "$PY" ]; then
    echo "  [2/5] 파이썬 설치 프로그램을 받고 있어요 (1~2분)..."
    curl -L --progress-bar -o /tmp/python-setup.pkg "https://www.python.org/ftp/python/3.12.7/python-3.12.7-macos11.pkg"
    echo "  설치 창이 뜨면 '계속' → '동의' → '설치'를 눌러 주세요. (맥 비밀번호를 물어볼 수 있어요)"
    open -W /tmp/python-setup.pkg
    PY=/Library/Frameworks/Python.framework/Versions/3.12/bin/python3
  fi
  if [ ! -x "$PY" ]; then
    echo ""
    echo "  파이썬 설치에 실패했어요. https://www.python.org 에서 설치한 뒤 이 파일을 다시 열어 주세요."
    read -n 1 -s -r -p "  아무 키나 누르면 닫혀요"
    exit 1
  fi
  "$PY" -m venv .venv
fi

echo "  [3/5] 필요한 프로그램을 확인하고 있어요 (처음엔 1~2분)..."
.venv/bin/python -m pip install -q --disable-pip-version-check -r requirements.txt
if [ $? -ne 0 ]; then
  echo "  설치 중 문제가 생겼어요. 인터넷 연결을 확인하고 이 파일을 다시 열어 주세요."
  rm -rf .venv
  read -n 1 -s -r -p "  아무 키나 누르면 닫혀요"
  exit 1
fi

# 업로더 전용 창(별도 프로그램 창)용 부품 — 안 깔려도 크롬 앱 창으로 대신 열려요
.venv/bin/python -m pip install -q --disable-pip-version-check "pywebview>=5.0" >/dev/null 2>&1
# Claude와 연결(MCP)용 부품 — 안 깔려도 업로더는 그대로 돌아가요
.venv/bin/python -m pip install -q --disable-pip-version-check "mcp>=1.2" >/dev/null 2>&1

echo "  [4/5] 영상 검사 도구(ffmpeg)를 확인하고 있어요..."
if ! command -v ffprobe >/dev/null 2>&1 && [ -x /opt/homebrew/bin/brew -o -x /usr/local/bin/brew ]; then
  (/opt/homebrew/bin/brew install ffmpeg || /usr/local/bin/brew install ffmpeg) >/dev/null 2>&1
fi

echo "  [5/5] 바탕화면 아이콘을 만들고 있어요..."
mkdir -p data
.venv/bin/python -c "from uploader.setup import after_install; after_install()" 2>/dev/null
open "$HOME/Desktop/나만의 자동 업로더.app" 2>/dev/null || (nohup .venv/bin/python app.py >/dev/null 2>&1 &)

echo ""
echo "  ✔ 끝! 잠시 뒤 인터넷 창에 업로더 화면이 열려요."
echo "    다음부터는 바탕화면의 '나만의 자동 업로더' 아이콘을 두 번 누르세요."
echo "    새 버전이 나오면 새로 받은 '설치하기'만 다시 열면 돼요."
echo "    이 창은 닫아도 돼요."
echo ""
