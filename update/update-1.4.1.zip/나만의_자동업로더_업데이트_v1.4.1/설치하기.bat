@echo off
chcp 65001 >nul
title 나만의 자동 업로더 - 설치·업데이트
echo.
echo   ☁  나만의 자동 업로더를 설치(업데이트)해요. 창을 닫지 말고 기다려 주세요.
echo      이미 설치했다면 내 채널·연결·설정은 그대로 두고 새 버전으로만 바꿔요.
echo.

rem 업로더는 항상 이 폴더에 설치돼요 (어디서 이 파일을 눌러도 같은 곳)
set "DEST=%USERPROFILE%\MyAutoUploader"

rem 압축을 풀지 않고 압축 파일 안에서 바로 누른 경우
if not exist "%~dp0app.py" (
  echo   ⚠ 압축을 먼저 풀어 주세요.
  echo     압축 파일에서 마우스 오른쪽 버튼 → '압축 풀기' → 풀린 폴더 안의 이 파일을 다시 두 번 눌러 주세요.
  pause
  exit /b
)

rem 인터넷에서 받은 파일 차단 풀기
powershell -NoProfile -Command "Get-ChildItem -LiteralPath '%~dp0' -Recurse | Unblock-File" >nul 2>&1

echo   [1/5] 프로그램 파일을 옮기고 있어요...
rem 켜져 있는 업로더 끄기 (예전 것이 켜져 있으면 새 버전이 안 열려요)
curl.exe -s -m 3 -X POST -H "Content-Type: application/json" -d "{}" http://127.0.0.1:5577/api/quit >nul 2>&1
timeout /t 2 >nul
if not exist "%DEST%" mkdir "%DEST%"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install_tools\install_helper.ps1" -Src "%~dp0." -Dest "%DEST%"
rem 도우미가 못 했으면 여기서 직접 복사 (내 설정·연결은 빼고)
if /i not "%~dp0"=="%DEST%\" robocopy "%~dp0." "%DEST%" /E /NFL /NDL /NJH /NJS /NP /XD .venv data tokens 배포 구글드라이브_받은영상 __pycache__ .git /XF config.json client_secret.json >nul
cd /d "%DEST%"
if not exist "app.py" (
  echo   파일을 옮기지 못했어요. 이 창을 사진 찍어서 보내 주세요.
  echo   설치할 곳: %DEST%
  pause
  exit /b
)

if exist ".venv\Scripts\pythonw.exe" goto deps

rem ── 파이썬 찾기 ──
set "PYEXE="
for /f "delims=" %%i in ('py -3 -c "import sys;print(sys.executable)" 2^>nul') do set "PYEXE=%%i"
if defined PYEXE goto mkvenv
for /f "delims=" %%i in ('python -c "import sys;print(sys.executable)" 2^>nul') do set "PYEXE=%%i"
if defined PYEXE goto mkvenv
if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set "PYEXE=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
if defined PYEXE goto mkvenv

echo   [2/5] 파이썬을 설치하고 있어요 (2~3분)...
winget install -e --id Python.Python.3.12 --scope user --silent --accept-source-agreements --accept-package-agreements >nul 2>&1
if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" goto pyok
rem winget이 없으면 python.org에서 직접 받기
powershell -NoProfile -Command "Invoke-WebRequest -UseBasicParsing 'https://www.python.org/ftp/python/3.12.7/python-3.12.7-amd64.exe' -OutFile '%TEMP%\python-setup.exe'"
"%TEMP%\python-setup.exe" /quiet InstallAllUsers=0 PrependPath=1 Include_tcltk=1 Include_launcher=1
:pyok
set "PYEXE=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
if exist "%PYEXE%" goto mkvenv
echo.
echo   파이썬 자동 설치에 실패했어요.
echo   https://www.python.org 에서 파이썬을 설치한 뒤 이 파일을 다시 두 번 눌러 주세요.
pause
exit /b

:mkvenv
"%PYEXE%" -m venv .venv

:deps
echo   [3/5] 필요한 프로그램을 확인하고 있어요 (처음엔 1~2분)...
".venv\Scripts\python.exe" -m pip install -q --disable-pip-version-check -r requirements.txt
if errorlevel 1 (
  echo   설치 중 문제가 생겼어요. 인터넷 연결을 확인하고 이 파일을 다시 두 번 눌러 주세요.
  rmdir /s /q .venv
  pause
  exit /b
)

rem 업로더 전용 창(별도 프로그램 창)용 부품 — 안 깔려도 크롬 앱 창으로 대신 열려요
".venv\Scripts\python.exe" -m pip install -q --disable-pip-version-check "pywebview>=5.0" >nul 2>&1

echo   [4/5] 영상 검사 도구(ffmpeg)를 확인하고 있어요...
where ffprobe >nul 2>&1 || winget install -e --id Gyan.FFmpeg --silent --accept-source-agreements --accept-package-agreements >nul 2>&1

echo   [5/5] 바탕화면 아이콘을 만들고 있어요...
".venv\Scripts\python.exe" -c "from uploader.setup import after_install; after_install()" >nul 2>&1

start "" ".venv\Scripts\pythonw.exe" "%DEST%\app.py"
echo.
echo   ✔ 끝! 잠시 뒤 인터넷 창에 업로더 화면이 열려요.
echo     설치된 곳: %DEST%
echo     다음부터는 바탕화면의 '나만의 자동 업로더' 아이콘을 두 번 누르세요.
echo     새 버전이 나오면 새로 받은 '설치하기'만 다시 두 번 누르면 돼요.
echo     이 창은 10초 뒤 저절로 닫혀요.
timeout /t 10 >nul
