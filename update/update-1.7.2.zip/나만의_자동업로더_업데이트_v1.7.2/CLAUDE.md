# 나만의 자동 업로더 — Claude Code용 프로젝트 설명

유튜브 영상을 폴더에서 골라 **비공개 업로드 → 자동 검토 → 지정 시각 예약 공개**하는 로컬 프로그램.
40~60대 사용자에게 나눠 주는 프로그램이라 **화면 문구는 쉬운 한국어**(전문 용어 X, 존댓말 '~해요'체)로 쓴다.

## 구조
- `app.py` — Flask 서버(127.0.0.1:5577) + 모든 `/api/*` 라우트. `python app.py [--no-browser]`. 이미 켜져 있으면 브라우저만 열고 종료.
- `static/index.html` — 화면 전부 (CSS·HTML·JS 한 파일, 빌드 도구 없음). 4초마다 `/api/state`를 읽어 다시 그림.
  - `v-easy` 🏠 올리기 탭(기본, data-view=home) / `v-home` 📊 진행 상황 탭(칸반, data-view=board) — 예전 쉬운/고급 화면을 탭 하나로 합침 / `v-stats` 채널 성적 / `wiz` 처음 설정 마법사 / `v-settings`, `v-help`, `v-log`
  - 모드는 localStorage `mode` (easy|adv). 버튼 클릭 시 딸깍 소리(WebAudio, `click_`).
- `uploader/engine.py` — 20초마다 `tick()`: 매일 자동 → 제목 생성 → 업로드 → 검토 → 공개 1시간 전 재검사 → 공개 확인.
  - 단계(stage): basket → queued → uploading → review → (check | problem) → scheduled → published
- 공개 시각: `publish_base`(시간표 칸) + `publish_at`/`publish_sec`(앞뒤로 흔든 실제 시각, `engine.humanize`). 업로드 사이 쉬기 `next_upload_after`. 설정 `humanize`.
- `uploader/review.py` — 올리기 전 검사(ffprobe), 유튜브 처리 결과, 공개 위험(`remote_risks`), 항목별 검사표(`build_report`).
- `uploader/youtube.py` — OAuth(채널별 `tokens/<채널>.json`), 업로드, 예약(`publishAt`), 시간 추천, 성적(`channel_stats`: Data API + Analytics API + 수익).
- `uploader/claude_ai.py` — `claude -p`로 제목·설명·태그 생성, '말로 시키기' 해석.
- `uploader/setup.py` — 준비물 확인, 열쇠 파일 찾기, 업로더 안 폴더 고르기 창(내 PC / 구글 드라이브 데스크톱 폴더 자동 찾기, `/api/places`, `/api/ls`, `/api/mkdir`), 기본 폴더 선택 창(Win: tkinter / Mac: osascript), 자동 실행(Win: 시작프로그램 .vbs / Mac: LaunchAgent), 바탕화면 아이콘(Win: .lnk / Mac: .app).
- `uploader/gdrive.py` — 인터넷 구글 드라이브 연결(`drive.readonly`, `tokens/_google_drive.json`). 채널 폴더가 드라이브면 config 채널에 `gdrive={id,name}`, `folder`=`구글드라이브_받은영상/<채널>`. `engine._step_gdrive`가 오래된 영상부터 (하루 개수×2)개씩 미리 내려받고, 공개되면 받은 사본을 지움. 폴더 고르기 창 🌐 탭(`gdOpen`, `gdGo`, `/api/gdrive/*`). 구글 프로젝트에서 'Google Drive API'를 켜야 함(꺼져 있으면 화면에 켜는 버튼).
- `uploader/growth.py` — 6시간마다 채널 총 조회수·수익 창출 진행도 갱신. 조회수→하루 개수(`daily_count_rules`), 1차/2차 왕관(`ypp`, `tier`), 최초 1회 축하(`celebrated`). 채널 목록은 tier 높은 순 정렬.
- `uploader/store.py` — `config.json`(설정), `data/state.json`(상태). `with edit() as st:` 로 읽고-고치고-저장.
- `설치하기.bat` / `설치하기.command` — 원클릭 설치(파이썬 설치 → .venv → pip → ffmpeg → 바탕화면 아이콘 → 실행).
- `배포용으로_압축하기.py` — 개인 파일 빼고 Windows/Mac 압축 파일 생성.

## 규칙
- 사용자 파일(`config.json`, `data/`, `tokens/`, `client_secret.json`, `.venv/`, `구글드라이브_받은영상/`)은 절대 배포 압축에 넣지 않는다.
- Python 3.9 이상에서 돌아가야 한다 (f-string 안에 백슬래시 금지, `X | Y` 타입 표기 금지).
- 새 화면 문구를 넣으면 쉬운 화면 기준: 큰 글씨, 한 화면에 한 가지, 버튼에는 결과를 적는다("확인했어요, 공개 예약하기").
- `.py`를 고치면 업로더를 재시작해야 반영된다. `index.html`만 고치면 새로고침으로 충분하다.
- 오류 기록: `data/uploader.log`.

## 버전·업데이트
- 버전은 `VERSION` 파일 한 줄. 고칠 때마다 숫자를 올리고 `python 배포용으로_압축하기.py` 실행.
- 결과 `배포/나만의 자동 업로더 설치하기.zip`(전체 묶음).
- 설치하기(.bat/.command)는 어디서 눌러도 항상 `~/MyAutoUploader`(Windows: `%USERPROFILE%\MyAutoUploader`)에 설치 = 업데이트. 켜진 업로더 끄기 → (처음이면) 예전 설치 폴더를 찾아 config·tokens·data·열쇠를 가져옴 → 프로그램 파일만 복사. Windows 쪽 로직은 `install_tools/install_helper.ps1`(UTF-8 BOM 유지).
- 앱 안 업데이트도 있음: 설정 → 🔄 업데이트하기 에서 zip 고르기 (`uploader/updater.py`, `/api/update`).
  config.json·data·tokens·client_secret.json·.venv·구글드라이브_받은영상 은 절대 덮어쓰지 않음.
- 설명서는 `나만의_자동업로더_설명서_전체.html` (묶음과 설치 폴더에 같이 들어감).
- 올라간 영상은 채널 폴더 안 `업로드완료/`로 옮김 (`engine._move_done`, config `move_done`).
- 날짜 지정: 영상에 `not_before`(YYYY-MM-DD) → `_assign`이 그날부터 시간표 배정.
- 📈 48시간 조회수 탭(`v-v48`, `/api/views48`): `engine._step_snaps`가 1시간마다 채널 총 조회수를 `state.snaps`에 찍고 `views48()`가 48시간 전과의 차이 계산.
- 화면·로그인 창은 크롬 우선 (`setup.open_url`, `setup.chrome_browser`).
- 위쪽 탭 순서: 올리기(home) · 진행 상황(board) · 채널 성적표(perf, `loadPerf`/`renderPerfOne`, /api/stats 재사용) · 48시간 조회수(v48: 한 번 클릭 `v48Zoom` 확대, 두 번 클릭 `v48Studio`) · 업로드 기록 · 설정 · 도움말.
- 화면은 전용 창(pywebview, `setup.show_ui`/`open_window`, 설치하기가 따로 pip install). 안 되면 크롬 --app 창(`open_app_window`). 창을 닫아도 서버는 계속 돎. 전용 창 안 바깥 링크는 `/api/open`으로 크롬에서 엶 (index.html 맨 위 IN_APP).

## 새 버전 내보내기 (완전 자동 업데이트)
1. 코드 고치고 `VERSION` 숫자 올리기 (예: 1.3.1 → 1.3.2)
2. `python 배포용으로_압축하기.py` (바뀐 내용 메모를 넣으려면 `UPDATE_NOTES="..."` 환경변수)
3. 내 컴퓨터에서 `배포/나만의_자동업로더_업데이트_Windows_v…zip`으로 먼저 테스트
4. 괜찮으면 `배포/GitHub에_올릴것/update` 폴더를 GitHub 저장소 `womantechcs-boop.github.io`에 폴더째 올리기(Add file → Upload files → 끌어다 놓기 → Commit)
5. 모든 사람 업로더가 3시간 안에 `https://womantechcs-boop.github.io/update/latest.json`을 보고 알아서 업데이트 (`engine._step_autoupdate`, `updater.check_remote/download_and_apply`, sha256 확인, 업로드 중이면 미룸, 예전 파일은 data/backup/v예전 에 보관)
- 주소는 `uploader/updater.py`의 `UPDATE_URL`. GitHub 계정은 2단계 인증 필수(이 계정이 곧 모든 사람 컴퓨터에 코드를 넣는 열쇠).
- 🤖 Claude 연결(MCP): `mcp_server.py`(mcp 1.x/2.x 둘 다) — 업로더 API(127.0.0.1:5577)를 부르는 얇은 다리, 꺼져 있으면 `--no-browser`로 켬. 도구: get_status, list_videos, upload_from_folder, set_publish_times, video_action, channel_report, views_48h, ack_alert, set_night_lock, check_update_now. 등록은 설정 → 🤖 Claude와 연결하기(`setup.connect_claude`: mcp 설치 + claude_desktop_config.json의 mcpServers['my-auto-uploader'] + `claude mcp add`).
- Claude 연결 시 `setup._allow_in_claude_code`가 ~/.claude/settings.json permissions.allow에 안전한 업로더 도구(SAFE_TOOLS)를 '항상 허용'으로 넣음. video_action(지우기·내리기)은 일부러 빼서 매번 물어봄. mcp_server의 instructions가 셸 명령 대신 업로더 도구를 먼저 쓰라고 안내.
- 🛡 자동 판단(config `auto_judge`, 기본 켬): 사람 확인(check)을 기다리지 않음. 저작권 주의 채널은 업로드 후 `copyright_wait_minutes`(30분) 지켜본 뒤 `review.judge`로 판단 → 막힌 나라·거절·삭제 없으면 공개 예약, 있으면 problem. 결과는 영상 `judge` 필드(화면·MCP list_videos에 표시). 알아 둘 것(화질·중복 등)은 공개는 진행하고 알림만. `_step_autojudge`가 예전 check 영상을 review로 돌림. 공개 70분 전 `_step_precheck`가 한 번 더 확인.

- 업로드 기본값(v1.7.0~1.7.1, 채널별, 설정 ▸ 더 보기): `title_hashtags`(기본 켬, `youtube.title_with_tags` 메타 `hashtags`(Claude가 5개, 첫째 주인공 이름) → 없으면 tags/설명 해시태그, 최대 5개, 100자 안), `paid_promo`(False → 업로드 뒤 part=paidProductPlacementDetails 업데이트, 실패 무시), `synthetic_media`(기본 True; `title_hashtags` 없는 예전 채널은 load_config에서 한 번 True로), `embeddable`(False). Shorts 리믹스는 API에 없음(유튜브 기본: 오디오 리믹스만 허용).
- 창 하나만(v1.7.2): 창(pywebview)은 `setup._watch_server`가 /api/ping의 `boot` 값을 1.5초마다 봄 → 업로더가 꺼지거나 새로 켜지면(업데이트) 그 창 프로세스는 창을 닫고 종료. `updater.restart()`는 최근 30초 안에 화면이 `/api/state?ui=1`을 읽었으면(`updater.LAST_UI`) 새 창을 열고, 아니면 `--no-browser`. 크롬 앱 창(대체)은 업로더가 다시 살아났을 때 버전이 바뀌었으면 화면이 저절로 새로 고침(WAS_DOWN).
