"""처음 설정 마법사용: 준비물 자동 확인·설치, 열쇠 파일 자동 찾기, 폴더 고르기 창."""
import json
import os
import platform
import shutil
import subprocess
import threading
from pathlib import Path

from .store import BASE

IS_WIN = platform.system() == "Windows"
_install = {"ffmpeg": ""}  # 설치 진행 상태 메시지


def find_ffprobe():
    exe = shutil.which("ffprobe")
    if exe:
        return exe
    cands = []
    if IS_WIN:
        la = os.environ.get("LOCALAPPDATA", "")
        cands += [Path(la) / "Microsoft" / "WinGet" / "Links" / "ffprobe.exe"]
        pk = Path(la) / "Microsoft" / "WinGet" / "Packages"
        if pk.is_dir():
            cands += list(pk.glob("Gyan.FFmpeg*/**/bin/ffprobe.exe"))
    else:
        cands += [Path("/opt/homebrew/bin/ffprobe"), Path("/usr/local/bin/ffprobe")]
    for c in cands:
        if Path(c).exists():
            return str(c)
    return None


def find_claude(cmd="claude"):
    exe = shutil.which(cmd) or shutil.which(cmd + ".cmd")
    if exe:
        return exe
    home = Path.home()
    for c in [home / ".local" / "bin" / "claude", home / ".claude" / "local" / "claude",
              home / "AppData" / "Roaming" / "npm" / "claude.cmd", home / ".local" / "bin" / "claude.exe"]:
        if c.exists():
            return str(c)
    return None


def install_ffmpeg():
    if _install["ffmpeg"].startswith("설치 중"):
        return

    def run():
        _install["ffmpeg"] = "설치 중… (1~3분)"
        try:
            if IS_WIN:
                cmd = ["winget", "install", "-e", "--id", "Gyan.FFmpeg",
                       "--accept-source-agreements", "--accept-package-agreements"]
            elif shutil.which("brew"):
                cmd = ["brew", "install", "ffmpeg"]
            else:
                _install["ffmpeg"] = "자동 설치를 못 하는 환경입니다. ffmpeg를 직접 설치해 주세요"
                return
            r = subprocess.run(cmd, capture_output=True, timeout=900)
            _install["ffmpeg"] = "" if find_ffprobe() else \
                "설치가 끝나지 않았어요: " + r.stdout.decode("utf-8", "ignore")[-200:]
        except Exception as e:
            _install["ffmpeg"] = f"설치 실패: {e}"

    threading.Thread(target=run, daemon=True).start()


CLIENT_SECRET = BASE / "client_secret.json"


def _valid_secret(data):
    try:
        d = json.loads(data) if isinstance(data, (str, bytes)) else data
    except Exception:
        return False, "JSON 파일이 아니에요"
    if "installed" in d:
        return True, ""
    if "web" in d:
        return False, "'웹 애플리케이션' 유형으로 만들어졌어요. 유형을 '데스크톱 앱'으로 다시 만들어 주세요"
    return False, "구글 OAuth 열쇠 파일이 아니에요"


def find_secret_in_downloads():
    """다운로드 폴더에서 방금 받은 client_secret_*.json 을 자동으로 찾음"""
    dl = Path.home() / "Downloads"
    if not dl.is_dir():
        return None
    files = sorted(dl.glob("client_secret*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
    for f in files[:5]:
        ok, _ = _valid_secret(f.read_text(encoding="utf-8", errors="ignore"))
        if ok:
            return str(f)
    return None


def save_secret(text=None, from_path=None):
    if from_path:
        text = Path(from_path).read_text(encoding="utf-8")
    ok, msg = _valid_secret(text)
    if not ok:
        raise ValueError(msg)
    CLIENT_SECRET.write_text(text, encoding="utf-8")


def pick_folder(initial=""):
    """내 컴퓨터의 '폴더 선택' 창을 띄움"""
    result = {"path": ""}
    if platform.system() == "Darwin":  # Mac은 기본 폴더 선택 창 사용
        r = subprocess.run(["osascript", "-e",
                            'POSIX path of (choose folder with prompt "영상이 들어있는(들어갈) 폴더를 고르세요")'],
                           capture_output=True, timeout=600)
        return r.stdout.decode("utf-8", "ignore").strip().rstrip("/")

    def run():
        import tkinter as tk
        from tkinter import filedialog
        root = tk.Tk()
        root.withdraw()
        root.attributes("-topmost", True)
        result["path"] = filedialog.askdirectory(initialdir=initial or str(Path.home()),
                                                 title="영상이 들어있는(들어갈) 폴더를 고르세요") or ""
        root.destroy()

    t = threading.Thread(target=run)
    t.start()
    t.join(timeout=600)
    return result["path"]


def status(cfg):
    from . import youtube
    chans = cfg.get("channels", [])
    return {
        "os": platform.system(),
        "ffmpeg": bool(find_ffprobe()),
        "ffmpeg_msg": _install["ffmpeg"],
        "claude": bool(find_claude(cfg.get("claude_cmd", "claude"))),
        "secret": CLIENT_SECRET.exists(),
        "secret_found": None if CLIENT_SECRET.exists() else find_secret_in_downloads(),
        "channels": len(chans),
        "connected": sum(1 for c in chans if youtube.is_connected(c["name"])),
        "done": bool(cfg.get("setup_done")),
    }


# ───────────────────────── 컴퓨터 켜면 자동 실행 · 바탕화면 아이콘 ─────────────────────────
APP_NAME = "나만의 자동 업로더"
IS_MAC = platform.system() == "Darwin"
MAC_AGENT = Path.home() / "Library" / "LaunchAgents" / "com.my-auto-uploader.plist"


def _venv_python(windowless=False):
    """업로더를 돌리는 파이썬 (설치 때 만든 .venv)"""
    if IS_WIN:
        exe = BASE / ".venv" / "Scripts" / ("pythonw.exe" if windowless else "python.exe")
    else:
        exe = BASE / ".venv" / "bin" / "python"
    return str(exe if exe.exists() else Path(os.sys.executable))


def _win_startup_dir():
    return Path(os.environ.get("APPDATA", "")) / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup"


def _win_startup_file():
    return _win_startup_dir() / "나만의_자동_업로더.vbs"


def autostart_enabled():
    if IS_WIN:
        return _win_startup_file().exists()
    if IS_MAC:
        return MAC_AGENT.exists()
    return False


def set_autostart(enabled):
    """켜면: 컴퓨터를 켜고 로그인할 때 업로더가 화면 없이 조용히 켜져요."""
    if IS_WIN:
        f = _win_startup_file()
        if enabled:
            f.parent.mkdir(parents=True, exist_ok=True)
            py, app = _venv_python(windowless=True), str(BASE / "app.py")
            f.write_text(
                'Set sh = CreateObject("WScript.Shell")\r\n'
                f'sh.CurrentDirectory = "{BASE}"\r\n'
                f'sh.Run """{py}"" ""{app}"" --no-browser", 0, False\r\n',
                encoding="utf-16")
        elif f.exists():
            f.unlink()
        return autostart_enabled()
    if IS_MAC:
        if enabled:
            MAC_AGENT.parent.mkdir(parents=True, exist_ok=True)
            MAC_AGENT.write_text(f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>Label</key><string>com.my-auto-uploader</string>
  <key>ProgramArguments</key><array>
    <string>{_venv_python()}</string><string>{BASE / 'app.py'}</string><string>--no-browser</string>
  </array>
  <key>WorkingDirectory</key><string>{BASE}</string>
  <key>RunAtLoad</key><true/>
  <key>StandardOutPath</key><string>{BASE / 'data' / 'uploader.log'}</string>
  <key>StandardErrorPath</key><string>{BASE / 'data' / 'uploader.log'}</string>
</dict></plist>
""", encoding="utf-8")
        elif MAC_AGENT.exists():
            subprocess.run(["launchctl", "unload", str(MAC_AGENT)], capture_output=True)
            MAC_AGENT.unlink()
        return autostart_enabled()
    raise RuntimeError("Windows와 Mac에서만 쓸 수 있어요")


def repair_paths():
    """다른 폴더에서 옮겨 온 설정이면, 구글 드라이브 채널의 '받은 영상' 폴더를 지금 설치 폴더로 맞춤"""
    try:
        from . import gdrive
        from .store import load_config, save_config
        cfg, changed = load_config(), False
        for ch in cfg.get("channels", []):
            if (ch.get("gdrive") or {}).get("id"):
                want = str(gdrive.cache_dir(ch["name"]))
                if ch.get("folder") != want:
                    ch["folder"], changed = want, True
        if changed:
            save_config(cfg)
    except Exception:
        pass


def after_install():
    """설치하기가 끝날 때: 바탕화면 아이콘, (켜져 있으면) 컴퓨터 켤 때 자동 실행을 새 위치로 다시 만들기"""
    for f in (make_desktop_icon, repair_paths):
        try:
            f()
        except Exception:
            pass
    try:
        if autostart_enabled():
            set_autostart(True)
    except Exception:
        pass


def make_desktop_icon():
    """바탕화면에 귀여운 아이콘 만들기 (다시 만들기에도 사용)"""
    if IS_WIN:
        ps = f"""
$d=[Environment]::GetFolderPath('Desktop')
$s=(New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path $d '{APP_NAME}.lnk'))
$s.TargetPath='{_venv_python(windowless=True)}'
$s.Arguments='"{BASE / 'app.py'}"'
$s.WorkingDirectory='{BASE}'
$s.IconLocation='{BASE / 'static' / 'icon.ico'},0'
$s.Description='유튜브 영상을 정한 시간에 자동으로 올려요'
$s.Save()
"""
        r = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps],
                           capture_output=True, timeout=60)
        if r.returncode != 0:
            raise RuntimeError(r.stderr.decode("utf-8", "ignore")[-300:])
        return True
    if IS_MAC:
        app = Path.home() / "Desktop" / f"{APP_NAME}.app"
        mac = app / "Contents" / "MacOS"
        res = app / "Contents" / "Resources"
        mac.mkdir(parents=True, exist_ok=True)
        res.mkdir(parents=True, exist_ok=True)
        (app / "Contents" / "Info.plist").write_text(f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>CFBundleName</key><string>{APP_NAME}</string>
  <key>CFBundleDisplayName</key><string>{APP_NAME}</string>
  <key>CFBundleIdentifier</key><string>com.my-auto-uploader.launcher</string>
  <key>CFBundleExecutable</key><string>run</string>
  <key>CFBundleIconFile</key><string>icon</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>LSUIElement</key><true/>
</dict></plist>
""", encoding="utf-8")
        run = mac / "run"
        run.write_text(f'#!/bin/bash\ncd "{BASE}"\nexec "{_venv_python()}" "{BASE / "app.py"}" >> "{BASE / "data" / "uploader.log"}" 2>&1\n',
                       encoding="utf-8")
        run.chmod(0o755)
        import shutil as _sh
        _sh.copyfile(BASE / "static" / "icon.icns", res / "icon.icns")
        subprocess.run(["touch", str(app)], capture_output=True)
        return True
    raise RuntimeError("Windows와 Mac에서만 쓸 수 있어요")


# ───────────────────────── 업로더 안 폴더 고르기 (내 PC / 구글 드라이브) ─────────────────────────
from .store import VIDEO_EXT

DRIVE_NAMES = ["내 드라이브", "My Drive", "공유 드라이브", "Shared drives", "다른 컴퓨터", "Other computers", "컴퓨터", "Computers"]
DRIVE_LABEL = {"My Drive": "내 드라이브", "Shared drives": "공유 드라이브", "Other computers": "다른 컴퓨터", "Computers": "컴퓨터"}


def _first(*cands):
    for c in cands:
        if c and Path(c).is_dir():
            return str(c)
    return None


def pc_places():
    h = Path.home()
    out = []
    for name, cands in [
        ("바탕화면", [h / "Desktop", h / "OneDrive" / "Desktop", h / "OneDrive" / "바탕 화면", h / "바탕화면"]),
        ("문서", [h / "Documents", h / "OneDrive" / "Documents", h / "OneDrive" / "문서"]),
        ("다운로드", [h / "Downloads"]),
        ("동영상", [h / "Videos", h / "Movies"]),
    ]:
        p = _first(*cands)
        if p:
            out.append({"name": name, "path": p})
    if IS_WIN:
        import string
        for L in string.ascii_uppercase:
            root = f"{L}:\\"
            if os.path.isdir(root) and not any(os.path.isdir(os.path.join(root, n)) for n in DRIVE_NAMES[:2]):
                out.append({"name": f"{L}: 드라이브", "path": root})
    else:
        out.append({"name": "내 컴퓨터 전체", "path": "/"})
    return out


def drive_roots():
    """Google Drive 데스크톱이 컴퓨터에 만든 폴더 찾기"""
    roots = []
    bases = []
    if IS_WIN:
        import string
        bases += [f"{L}:\\" for L in string.ascii_uppercase if os.path.isdir(f"{L}:\\")]
        bases += [str(Path.home())]  # 미러링 방식: C:\Users\이름\내 드라이브
    elif IS_MAC:
        cs = Path.home() / "Library" / "CloudStorage"
        if cs.is_dir():
            bases += [str(p) for p in cs.iterdir() if p.name.startswith("GoogleDrive")]
        bases += ["/Volumes/GoogleDrive", str(Path.home() / "Google Drive")]
    for b in bases:
        for n in DRIVE_NAMES:
            p = os.path.join(b, n)
            if os.path.isdir(p) and not any(r["path"] == p for r in roots):
                acct = ""
                if IS_MAC and "GoogleDrive-" in b:
                    acct = b.split("GoogleDrive-")[-1]
                roots.append({"name": DRIVE_LABEL.get(n, n) + (f" ({acct})" if acct else ""), "path": p})
    # 이 컴퓨터 폴더를 드라이브와 동기화한 경우는 내 PC 쪽에 있어요
    return roots


def count_videos(path, limit=500):
    n = 0
    try:
        with os.scandir(path) as it:
            for i, e in enumerate(it):
                if i > limit:
                    break
                if e.is_file() and os.path.splitext(e.name)[1].lower() in VIDEO_EXT:
                    n += 1
    except Exception:
        return None
    return n


def list_dir(path):
    p = Path(path)
    if not p.is_dir():
        raise FileNotFoundError("폴더를 찾을 수 없어요")
    dirs = []
    try:
        entries = sorted(os.scandir(p), key=lambda e: e.name.lower())
    except PermissionError:
        raise PermissionError("이 폴더는 열 수 없어요 (권한 없음)")
    for e in entries:
        try:
            if e.is_dir() and not e.name.startswith((".", "$")) and e.name not in ("System Volume Information", "AppData", "Library"):
                dirs.append({"name": e.name, "path": e.path})
        except Exception:
            pass
    for d in dirs[:80]:
        d["videos"] = count_videos(d["path"], 200)
    parent = str(p.parent) if p.parent != p else None
    return {"path": str(p), "name": p.name or str(p), "parent": parent, "dirs": dirs[:300],
            "videos": count_videos(p), "is_drive": any(str(p).startswith(r["path"]) for r in drive_roots())}


def make_dir(parent, name):
    name = name.strip().replace("/", "").replace("\\", "")
    if not name:
        raise ValueError("폴더 이름을 적어 주세요")
    q = Path(parent) / name
    q.mkdir(exist_ok=True)
    return str(q)


# ───────────────────────── 크롬으로 열기 (엣지 대신) ─────────────────────────
def find_chrome():
    import os
    if IS_WIN:
        for base in (os.environ.get("PROGRAMFILES"), os.environ.get("PROGRAMFILES(X86)"), os.environ.get("LOCALAPPDATA")):
            if base:
                p = Path(base) / "Google" / "Chrome" / "Application" / "chrome.exe"
                if p.exists():
                    return str(p)
    elif IS_MAC:
        for p in ("/Applications/Google Chrome.app", str(Path.home() / "Applications" / "Google Chrome.app")):
            if Path(p).exists():
                return p
    return None


def chrome_browser():
    """크롬이 깔려 있으면 webbrowser 에 'chrome' 으로 등록하고 그 이름을 돌려줌 (없으면 None = 기본 브라우저)"""
    import webbrowser
    c = find_chrome()
    if not c:
        return None
    try:
        webbrowser.get("chrome-uploader")
        return "chrome-uploader"
    except Exception:
        pass
    if IS_MAC:
        webbrowser.register("chrome-uploader", None, webbrowser.MacOSXOSAScript("Google Chrome"))
    else:
        webbrowser.register("chrome-uploader", None, webbrowser.BackgroundBrowser(c))
    return "chrome-uploader"


def open_url(url):
    """업로더 화면·로그인 창은 크롬으로 (크롬이 없으면 기본 브라우저)"""
    import webbrowser
    name = chrome_browser()
    try:
        if name:
            webbrowser.get(name).open(url)
            return
    except Exception:
        pass
    webbrowser.open(url)


# ───────────────────────── 업로더 전용 창 (크롬·엣지 말고 별도 프로그램 창) ─────────────────────────
def open_window(url):
    """업로더를 '나만의 자동 업로더' 전용 창으로 띄움. 창이 닫힐 때까지 기다림.
    성공하면 True. (pywebview가 없거나 안 되면 False → 크롬 앱 창으로 대신)"""
    try:
        import webview
    except Exception:
        return False
    try:
        try:
            webview.settings["OPEN_EXTERNAL_LINKS_IN_BROWSER"] = True
        except Exception:
            pass
        store_dir = BASE / "data" / "window"
        store_dir.mkdir(parents=True, exist_ok=True)
        webview.create_window(APP_NAME, url + "/?app=1", width=1440, height=920, min_size=(1000, 680),
                              text_select=True)
        icon = BASE / "static" / ("icon.ico" if IS_WIN else "icon.png")
        kw = {"private_mode": False, "storage_path": str(store_dir)}
        try:
            webview.start(icon=str(icon), **kw)
        except TypeError:
            webview.start(**kw)
        return True
    except Exception as e:
        print("전용 창을 못 열었어요:", e)
        return False


def open_app_window(url):
    """전용 창이 안 되면: 크롬 '앱 창'(주소창·탭 없는 창)으로. 그것도 안 되면 기본 브라우저"""
    c = find_chrome()
    try:
        if c and IS_WIN:
            subprocess.Popen([c, f"--app={url}/?app=1", "--window-size=1440,920"])
            return
        if c and IS_MAC:
            subprocess.Popen(["open", "-na", "Google Chrome", "--args", f"--app={url}/?app=1", "--window-size=1440,920"])
            return
    except Exception:
        pass
    open_url(url)


def show_ui(url):
    """업로더 화면 열기: 전용 창 → (안 되면) 크롬 앱 창. 전용 창이면 닫힐 때까지 기다림"""
    if not open_window(url):
        open_app_window(url)


# ───────────────────────── Claude와 연결 (MCP) ─────────────────────────
MCP_NAME = "my-auto-uploader"


def _claude_desktop_configs():
    """Claude 데스크톱 앱 설정 파일 자리들 (일반 설치 + 마이크로소프트 스토어 설치)"""
    out = []
    if IS_WIN:
        ad = os.environ.get("APPDATA")
        if ad:
            out.append(Path(ad) / "Claude" / "claude_desktop_config.json")
        la = os.environ.get("LOCALAPPDATA")
        if la:
            for pk in (Path(la) / "Packages").glob("Claude_*"):
                out.append(pk / "LocalCache" / "Roaming" / "Claude" / "claude_desktop_config.json")
    elif IS_MAC:
        out.append(Path.home() / "Library" / "Application Support" / "Claude" / "claude_desktop_config.json")
    else:
        out.append(Path.home() / ".config" / "Claude" / "claude_desktop_config.json")
    return out


def _console_python():
    import sys
    return sys.executable.replace("pythonw.exe", "python.exe")


def connect_claude():
    """업로더를 Claude에 연결: (1) 연결 부품(mcp) 설치 (2) Claude 데스크톱 앱 설정에 등록 (3) Claude Code에도 등록(있으면)"""
    import importlib.util
    import sys
    py = _console_python()
    if importlib.util.find_spec("mcp") is None:
        r = subprocess.run([py, "-m", "pip", "install", "-q", "mcp>=1.2"], cwd=str(BASE), capture_output=True, text=True,
                           timeout=900, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        if r.returncode != 0:
            raise RuntimeError("연결 부품을 설치하지 못했어요. 인터넷 연결을 확인해 주세요. " + (r.stderr or "")[-200:])
    entry = {"command": py, "args": [str(BASE / "mcp_server.py")]}
    done = []
    for cfgp in _claude_desktop_configs():
        if not cfgp.parent.exists() and cfgp != _claude_desktop_configs()[0]:
            continue
        try:
            cfgp.parent.mkdir(parents=True, exist_ok=True)
            data = {}
            if cfgp.exists():
                try:
                    data = json.loads(cfgp.read_text(encoding="utf-8") or "{}")
                except Exception:
                    cfgp.with_name(cfgp.name + ".backup").write_bytes(cfgp.read_bytes())
                    data = {}
            data.setdefault("mcpServers", {})[MCP_NAME] = entry
            cfgp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
            done.append("Claude 데스크톱 앱")
        except Exception:
            pass
    c = find_claude()
    if c:
        try:
            subprocess.run([c, "mcp", "remove", "--scope", "user", MCP_NAME], capture_output=True, timeout=60,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            r = subprocess.run([c, "mcp", "add", "--scope", "user", MCP_NAME, "--", py, str(BASE / "mcp_server.py")],
                               capture_output=True, timeout=60, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            if r.returncode == 0:
                done.append("Claude Code")
        except Exception:
            pass
    if not done:
        raise RuntimeError("Claude 데스크톱 앱을 찾지 못했어요. claude.ai/download 에서 Claude 앱을 먼저 설치해 주세요")
    return sorted(set(done), key=done.index)


def claude_connected():
    for cfgp in _claude_desktop_configs():
        try:
            if MCP_NAME in json.loads(cfgp.read_text(encoding="utf-8")).get("mcpServers", {}):
                return True
        except Exception:
            pass
    return False
