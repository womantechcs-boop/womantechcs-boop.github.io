"""설정(config.json)과 상태(data/state.json) 저장소."""
import json
import os
import threading
import time
import uuid
import hashlib
from contextlib import contextmanager
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent
DATA = BASE / "data"
DATA.mkdir(exist_ok=True)
CONFIG_PATH = BASE / "config.json"
STATE_PATH = DATA / "state.json"

lock = threading.RLock()

DEFAULT_CONFIG = {
    "night_lock": {"enabled": True, "start": 0, "end": 7},
    "daily_auto": {"enabled": False, "time": "09:00"},
    "min_lead_minutes": 60,
    "claude_cmd": "claude",
    "banned_words": [],
    "notify": {
        "email_enabled": False,
        "smtp_user": "",
        "smtp_app_password": "",
        "to": "",
    },
    "channels": [],
    # 채널 총 조회수 → 하루 올릴 개수 (조회수가 이 숫자 이상이면 이 개수)
    "daily_count_rules": [
        {"min_views": 0, "count": 1},
        {"min_views": 10000, "count": 2},
        {"min_views": 20000, "count": 3},
    ],
    # 사람처럼 올리기: 공개 시각을 정한 시간 앞뒤로 흔들고, 연달아 올릴 땐 몇 분씩 쉬기
    "humanize": {"enabled": True, "minutes": 20, "upload_gap_min": 3, "upload_gap_max": 9},
    "auto_update": True,
    # 공개 전 판단을 업로더가 알아서 (사람 확인 안 기다림). 저작권 주의 채널은 올린 뒤 이만큼 지켜보고 판단
    "auto_judge": True,
    "copyright_wait_minutes": 30,
    # 유튜브 수익 창출 조건 (유튜브가 기준을 바꾸면 여기 숫자를 고치세요)
    "ypp": {
        "t1": {"subs": 500, "uploads90": 3, "hours": 3000, "shorts": 3000000},
        "t2": {"subs": 1000, "hours": 4000, "shorts": 10000000},
    },
}

DEFAULT_CHANNEL = {
    "name": "",
    "folder": "",
    "publish_times": ["19:00"],
    "style": "",
    "language": "ko",
    "category_id": "24",
    "synthetic_media": True,      # AI 사용 표시: 예
    "notify_subscribers": True,
    "embeddable": False,          # 퍼가기 허용: 안 함
    "paid_promo": False,          # 유료 프로모션: 아니요
    "title_hashtags": True,       # 제목 끝에 해시태그 붙이기
    "remix_off": True,            # Shorts 리믹스 끄기 알림 (스튜디오에서 한꺼번에)
    "copyright_check": False,
    "auto_count": True,
}

VIDEO_EXT = {".mp4", ".mov", ".mkv", ".webm", ".m4v", ".avi"}


def _read_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return default
    except json.JSONDecodeError:
        # 깨진 파일은 백업해두고 기본값으로
        os.replace(path, str(path) + f".broken-{int(time.time())}")
        return default


def _write_json(path, obj):
    tmp = str(path) + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
    os.replace(tmp, path)


def load_config():
    with lock:
        cfg = _read_json(CONFIG_PATH, None)
        if cfg is None:
            cfg = json.loads(json.dumps(DEFAULT_CONFIG))
            _write_json(CONFIG_PATH, cfg)
        for k, v in DEFAULT_CONFIG.items():
            cfg.setdefault(k, json.loads(json.dumps(v)))
        for k, v in DEFAULT_CONFIG["notify"].items():
            cfg["notify"].setdefault(k, v)
        for k, v in DEFAULT_CONFIG["humanize"].items():
            cfg["humanize"].setdefault(k, v)
        changed = False
        for ch in cfg["channels"]:
            if "title_hashtags" not in ch:  # v1.7.0: 업로드 기본 설정 한 번 맞춤 (AI 사용 '예')
                ch["synthetic_media"] = True
                changed = True
            for k, v in DEFAULT_CHANNEL.items():
                ch.setdefault(k, json.loads(json.dumps(v)))
        if changed:
            _write_json(CONFIG_PATH, cfg)
        return cfg


def save_config(cfg):
    with lock:
        _write_json(CONFIG_PATH, cfg)


def get_channel(cfg, name):
    for ch in cfg["channels"]:
        if ch["name"] == name:
            return ch
    return None


def _empty_state():
    return {"videos": {}, "log": [], "alerts": [], "channel_info": {}, "last_daily_run": ""}


def load_state():
    with lock:
        st = _read_json(STATE_PATH, None) or _empty_state()
        for k, v in _empty_state().items():
            st.setdefault(k, v)
        return st


def save_state(st):
    with lock:
        _write_json(STATE_PATH, st)


@contextmanager
def edit():
    """with edit() as st: ... 하면 읽고-고치고-저장까지 한 번에."""
    with lock:
        st = load_state()
        yield st
        save_state(st)


def video_id_for(path):
    return hashlib.sha1(str(Path(path).resolve()).encode("utf-8")).hexdigest()[:12]


def now_iso():
    return time.strftime("%Y-%m-%dT%H:%M:%S")


def add_log(st, kind, msg, channel=None, video=None):
    st["log"].insert(0, {"t": now_iso(), "kind": kind, "msg": msg, "channel": channel, "video": video})
    del st["log"][500:]


def add_alert(st, level, title, detail="", video=None, channel=None):
    """level: problem(빨강) / warn(노랑)"""
    # 같은 내용의 미확인 알림이 있으면 중복 생성 안 함
    for a in st["alerts"]:
        if not a["ack"] and a["title"] == title and a.get("video") == video:
            return a
    a = {
        "id": uuid.uuid4().hex[:10],
        "t": now_iso(),
        "level": level,
        "title": title,
        "detail": detail,
        "video": video,
        "channel": channel,
        "ack": False,
    }
    st["alerts"].insert(0, a)
    del st["alerts"][200:]
    return a
