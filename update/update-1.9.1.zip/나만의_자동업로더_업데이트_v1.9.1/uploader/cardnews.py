"""카드뉴스 만들기 — 템플릿(static/cardnews_templates.json)에 글·사진을 넣어 1080×1080 그림(PNG)으로 저장.

그림은 이 컴퓨터의 크롬(없으면 엣지)을 화면 없이(headless) 띄워 찍습니다. 따로 설치할 것 없음.
유튜브 '게시물'은 유튜브가 바깥 프로그램에 올리는 길을 열어 주지 않아서, 저장한 그림을 스튜디오에서 직접 올립니다.
"""
import base64
import json
import mimetypes
import os
import re
import shutil
import subprocess
import tempfile
from datetime import datetime
from pathlib import Path

from .store import BASE
from . import setup

TPL_PATH = BASE / "static" / "cardnews_templates.json"
TMP = BASE / "data" / "card_tmp"


def templates():
    return json.loads(TPL_PATH.read_text(encoding="utf-8"))


def headless_browser():
    """그림 찍기에 쓸 브라우저 실행 파일"""
    c = setup.find_chrome()
    if c and c.endswith(".app"):
        c = str(Path(c) / "Contents" / "MacOS" / "Google Chrome")
    if c and Path(c).exists():
        return c
    if setup.IS_WIN:
        for base in (os.environ.get("PROGRAMFILES(X86)"), os.environ.get("PROGRAMFILES")):
            if base:
                p = Path(base) / "Microsoft" / "Edge" / "Application" / "msedge.exe"
                if p.exists():
                    return str(p)
    if setup.IS_MAC:
        p = Path("/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge")
        if p.exists():
            return str(p)
    for n in ("google-chrome", "chromium", "chromium-browser", "chrome"):
        if shutil.which(n):
            return shutil.which(n)
    return None


def find_ffmpeg():
    exe = shutil.which("ffmpeg")
    if exe:
        return exe
    fp = setup.find_ffprobe()
    if fp:
        p = Path(fp).with_name("ffmpeg" + (".exe" if setup.IS_WIN else ""))
        if p.exists():
            return str(p)
    return None


def _fill(s, o):
    return re.sub(r"\{(\w+)\}", lambda m: _esc(o.get(m.group(1), "")), s)


def _esc(t):
    t = str(t or "")
    t = t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    return t.replace("\n", "<br>")


def _scope_css(css):
    """템플릿 CSS의 선택자 앞에 .c 를 붙임 (원본 템플릿 페이지와 같은 방식)"""
    def rep(m):
        a, sel = m.group(1), m.group(2)
        out = []
        for x in sel.split(","):
            x = x.strip()
            out.append(x if re.match(r"^\.c(?![\w-])", x) else ".c " + x)
        return a + ",".join(out) + "{"
    return re.sub(r"(^|\})\s*([^{}]+)\{", rep, css)


def _img_css(path_or_css):
    """사진 경로 → CSS 배경값 (그림 파일에 직접 넣어서 인터넷 없이도 보이게)"""
    v = str(path_or_css or "")
    if not v:
        return None
    if v.startswith("linear-gradient") or v.startswith("url("):
        return v
    p = Path(v)
    if not p.is_file():
        return None
    mt = mimetypes.guess_type(p.name)[0] or "image/jpeg"
    return f"url('data:{mt};base64,{base64.b64encode(p.read_bytes()).decode()}')"


def card_html(tpl, kind, fields, img, fonts):
    ph = _img_css(img) or "linear-gradient(160deg,#8aa4c8,#2c3e5c)"
    links = "\n".join(f'<link href="{f}" rel="stylesheet">' for f in fonts)
    body = _fill(tpl[kind], fields)
    return f"""<!doctype html><html lang="ko"><head><meta charset="utf-8">{links}<style>
html,body{{margin:0;padding:0;width:1080px;height:1080px;overflow:hidden;background:#000}}
body{{font-family:Pretendard,sans-serif}}
.c{{position:relative;width:1080px;height:1080px;overflow:hidden;box-sizing:border-box}}
.c .ph{{background:var(--img);background-size:cover;background-position:center}}
{_scope_css(tpl["css"])}</style></head><body><div class="c" style="--img:{ph}">{body}</div></body></html>"""


class _WS:
    """아주 작은 웹소켓 클라이언트 (크롬 DevTools와 이야기하는 용도, 따로 설치할 것 없음)"""
    def __init__(self, url, timeout=60):
        import socket
        import urllib.parse
        u = urllib.parse.urlparse(url)
        self.s = socket.create_connection((u.hostname, u.port), timeout=timeout)
        key = base64.b64encode(os.urandom(16)).decode()
        req = (f"GET {u.path} HTTP/1.1\r\nHost: {u.hostname}:{u.port}\r\nUpgrade: websocket\r\n"
               f"Connection: Upgrade\r\nSec-WebSocket-Key: {key}\r\nSec-WebSocket-Version: 13\r\n\r\n")
        self.s.sendall(req.encode())
        buf = b""
        while b"\r\n\r\n" not in buf:
            ch = self.s.recv(4096)
            if not ch:
                raise RuntimeError("크롬 연결 실패")
            buf += ch
        self.rest = buf.split(b"\r\n\r\n", 1)[1]
        self.n = 0

    def _recv_exact(self, n):
        while len(self.rest) < n:
            ch = self.s.recv(1 << 20)
            if not ch:
                raise RuntimeError("크롬 연결이 끊겼어요")
            self.rest += ch
        out, self.rest = self.rest[:n], self.rest[n:]
        return out

    def send(self, obj):
        import struct
        data = json.dumps(obj).encode()
        hdr = bytearray([0x81])
        n = len(data)
        if n < 126:
            hdr.append(0x80 | n)
        elif n < 65536:
            hdr.append(0x80 | 126); hdr += struct.pack(">H", n)
        else:
            hdr.append(0x80 | 127); hdr += struct.pack(">Q", n)
        mask = os.urandom(4)
        hdr += mask
        self.s.sendall(bytes(hdr) + bytes(b ^ mask[i % 4] for i, b in enumerate(data)))

    def recv(self):
        import struct
        msg = b""
        while True:
            b1, b2 = self._recv_exact(2)
            n = b2 & 0x7F
            if n == 126:
                n = struct.unpack(">H", self._recv_exact(2))[0]
            elif n == 127:
                n = struct.unpack(">Q", self._recv_exact(8))[0]
            if b2 & 0x80:
                self._recv_exact(4)
            payload = self._recv_exact(n)
            op = b1 & 0x0F
            if op == 8:
                raise RuntimeError("크롬 연결이 끊겼어요")
            if op in (0, 1, 2):
                msg += payload
                if b1 & 0x80:
                    return json.loads(msg.decode("utf-8", "ignore"))

    def call(self, method, params=None):
        self.n += 1
        my = self.n
        self.send({"id": my, "method": method, "params": params or {}})
        while True:
            m = self.recv()
            if m.get("id") == my:
                if "error" in m:
                    raise RuntimeError(str(m["error"]))
                return m.get("result", {})

    def close(self):
        try:
            self.s.close()
        except Exception:
            pass


class Shooter:
    """크롬(엣지)을 화면 없이 한 번 띄워 놓고 카드를 한 장씩 그림으로 찍음"""
    def __init__(self, browser):
        import time
        import urllib.request
        self.prof = tempfile.mkdtemp(prefix="cardshot_")
        cmd = [browser, "--headless=new", "--disable-gpu", "--hide-scrollbars", "--no-first-run",
               "--no-default-browser-check", "--disable-extensions", "--disable-background-networking",
               "--disable-component-update", "--disable-sync", f"--user-data-dir={self.prof}",
               "--remote-debugging-port=0", "--remote-allow-origins=*", "about:blank"]
        if hasattr(os, "geteuid") and os.geteuid() == 0:
            cmd.insert(1, "--no-sandbox")
        kw = {"creationflags": 0x08000000} if setup.IS_WIN else {}
        self.proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, **kw)
        port_file = Path(self.prof) / "DevToolsActivePort"
        port = None
        for _ in range(150):
            if port_file.exists():
                try:
                    port = int(port_file.read_text().split()[0])
                    break
                except Exception:
                    pass
            time.sleep(0.1)
        if not port:
            self.close()
            raise RuntimeError("그림 만들 크롬을 켜지 못했어요")
        self.port = port
        tabs = []
        for _ in range(50):
            try:
                with urllib.request.urlopen(f"http://127.0.0.1:{port}/json/list", timeout=3) as r:
                    tabs = [t for t in json.loads(r.read()) if t.get("type") == "page"]
                if tabs:
                    break
            except Exception:
                pass
            time.sleep(0.1)
        if not tabs:
            self.close()
            raise RuntimeError("그림 만들 크롬 창을 찾지 못했어요")
        self.ws = _WS(tabs[0]["webSocketDebuggerUrl"])
        self.ws.call("Emulation.setDeviceMetricsOverride",
                     {"width": 1080, "height": 1080, "deviceScaleFactor": 1, "mobile": False})

    def shot(self, html_path, png_path):
        import time
        self.ws.call("Page.navigate", {"url": Path(html_path).resolve().as_uri()})
        # 글꼴·사진이 다 뜰 때까지 기다림 (최대 15초)
        js = ("new Promise(r=>{const t=setTimeout(()=>r('t'),15000);"
              "const go=()=>Promise.all([document.fonts.ready,...[...document.images].map(i=>i.decode().catch(()=>0))])"
              ".then(()=>{clearTimeout(t);setTimeout(()=>r('ok'),300)});"
              "if(document.readyState==='complete')go();else addEventListener('load',go)})")
        for _ in range(3):
            try:
                self.ws.call("Runtime.evaluate", {"expression": js, "awaitPromise": True})
                break
            except Exception:
                time.sleep(0.5)
        r = self.ws.call("Page.captureScreenshot", {"format": "png",
                         "clip": {"x": 0, "y": 0, "width": 1080, "height": 1080, "scale": 1}})
        Path(png_path).write_bytes(base64.b64decode(r["data"]))
        return Path(png_path).stat().st_size > 1000

    def close(self):
        try:
            self.ws.close()
        except Exception:
            pass
        try:
            self.proc.kill()
            self.proc.wait(timeout=10)
        except Exception:
            pass
        shutil.rmtree(self.prof, ignore_errors=True)


def safe(t, n=40):
    t = re.sub(r'[\\/:*?"<>|\n\r\t]', " ", str(t or "")).strip()
    return re.sub(r"\s+", " ", t)[:n] or "카드뉴스"


def render(channel, tpl_no, cards, title, out_root):
    """cards: [{kind: cover|mid|end, fields:{...}, img: 경로}] → out_root/카드뉴스/날짜_제목/01.png …"""
    D = templates()
    tpl = next((t for t in D["T"] if int(t["no"]) == int(tpl_no)), None)
    if not tpl:
        raise ValueError("템플릿을 찾을 수 없어요")
    browser = headless_browser()
    if not browser:
        raise RuntimeError("그림을 만들려면 크롬(또는 엣지)이 있어야 해요")
    out = Path(out_root) / "카드뉴스" / f"{datetime.now():%Y%m%d_%H%M}_{safe(title)}"
    out.mkdir(parents=True, exist_ok=True)
    work = Path(tempfile.mkdtemp(prefix="cardnews_"))
    made = []
    sh = Shooter(browser)
    try:
        for i, c in enumerate(cards, 1):
            kind = c.get("kind") if c.get("kind") in ("cover", "mid", "end") else "mid"
            f = dict(D.get("S", {}))
            f.update({k: v for k, v in (c.get("fields") or {}).items() if v is not None})
            f["ch"] = f.get("ch") or channel
            h = work / f"{i:02d}.html"
            h.write_text(card_html(tpl, kind, f, c.get("img"), D.get("FONTS", [])), encoding="utf-8")
            png = out / f"{i:02d}.png"
            if not sh.shot(h, png):
                raise RuntimeError(f"{i}번째 장을 그림으로 만들지 못했어요")
            made.append(str(png))
    finally:
        sh.close()
        shutil.rmtree(work, ignore_errors=True)
    return {"folder": str(out), "files": made}


def frames(video_file, n=6):
    """영상에서 장면 사진 n장 뽑기 (고르게 나눠서)"""
    ff = find_ffmpeg()
    if not ff:
        raise RuntimeError("장면을 뽑으려면 ffmpeg가 필요해요 (설정 → 영상 검사 도구 설치)")
    dur = 0.0
    fp = setup.find_ffprobe()
    if fp:
        try:
            r = subprocess.run([fp, "-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1",
                                str(video_file)], capture_output=True, timeout=30)
            dur = float(r.stdout.decode().strip() or 0)
        except Exception:
            dur = 0.0
    TMP.mkdir(parents=True, exist_ok=True)
    stem = safe(Path(video_file).stem, 30).replace(" ", "_")
    out = []
    kw = {"creationflags": 0x08000000} if setup.IS_WIN else {}
    for i in range(n):
        t = (dur * (i + 1) / (n + 1)) if dur > 0 else (i * 3 + 1)
        p = TMP / f"{stem}_{i + 1:02d}.jpg"
        subprocess.run([ff, "-y", "-ss", f"{t:.2f}", "-i", str(video_file), "-frames:v", "1",
                        "-vf", "scale=1080:-2", "-q:v", "3", str(p)], capture_output=True, timeout=60, **kw)
        if p.exists() and p.stat().st_size > 0:
            out.append(str(p))
    if not out:
        raise RuntimeError("장면을 뽑지 못했어요")
    return out


def ai_text(channel, topic, pages, video=None, style=""):
    """Claude로 카드뉴스 글 채우기 → {tag, t1, t2, pages:[{m1,m2,body}], e1, e2}"""
    from . import claude_ai
    src = ""
    if video:
        src += f"\n영상 제목: {video.get('title','')}\n영상 설명: {(video.get('description') or '')[:800]}"
        try:
            sc = claude_ai.find_script(video.get("file", ""))
            if sc:
                src += f"\n대본(앞부분): {sc[:2500]}"
        except Exception:
            pass
    prompt = f"""유튜브 커뮤니티 게시물용 한국어 카드뉴스 글을 써 줘.
채널: {channel} {('· 채널 스타일: ' + style) if style else ''}
주제/메모: {topic or '(아래 영상 내용으로)'}{src}

규칙:
- 첫 장: tag(2~4글자 말머리, 예: 단독·충격·화제), t1(호기심 끄는 한 줄, 18자 이내), t2(강조 한 줄, 16자 이내)
- 중간 장 {pages}장: 각 장 m1(소제목 16자 이내), m2(강조 한 줄 16자 이내), body(2~3문장, 70자 이내)
- 마지막 장: e1(질문이나 정리 16자 이내), e2(댓글·구독 유도 16자 이내)
- 반말 섞인 친근한 말투, 과장·낚시·거짓 금지, 이모지는 꼭 필요할 때만
다른 말 없이 JSON 한 개만: {{"tag":"","t1":"","t2":"","pages":[{{"m1":"","m2":"","body":""}}],"e1":"","e2":""}}"""
    d = claude_ai._extract_json(claude_ai._run_claude("claude", prompt, timeout=180))
    d["pages"] = (d.get("pages") or [])[:pages]
    return d


# ───────── 어울리는 템플릿 추천 ─────────
GENRES = [
    ("음악·플레이리스트", ["플레이리스트", "playlist", "플리", "r&b", "알앤비", "노래", "음악", "발라드", "힙합", "재즈",
                    "팝송", "가수", "앨범", "곡", "듣기", "bgm", "lofi", "감성"], [15, 9, 5, 14, 11, 12, 26, 17]),
    ("드라마", ["드라마", "드짜", "중드", "영드", "한드", "일드", "미드", "웹드", "줄거리", "회차", "명장면", "로맨스",
             "주인공", "결말", "남주", "여주"], [26, 17, 3, 5, 22, 4, 1]),
    ("뉴스·이슈", ["뉴스", "이슈", "속보", "정치", "경제", "사건", "사고", "시사", "단독", "논란"], [1, 7, 8, 4, 3, 2]),
    ("연예·아이돌", ["아이돌", "kpop", "케이팝", "무대", "뮤직뱅크", "콘서트", "연예", "컴백", "팬"],
     [9, 11, 14, 15, 13, 12, 10]),
    ("예능·웃음", ["예능", "웃긴", "레전드", "브이로그", "vlog", "먹방", "챌린지", "몰카", "썰", "ㅋㅋ"],
     [16, 17, 18, 21, 22, 23, 20, 31]),
    ("정보·공부", ["정보", "꿀팁", "공부", "영어", "강의", "건강", "재테크", "요리", "레시피", "리뷰", "비교", "방법",
               "top", "순위", "추천"], [28, 32, 30, 29, 18, 25]),
]
# 사진에 글씨가 많아도 글이 또렷한 모양 (상자·단색 바탕)
CLEAR = [6, 36, 2, 37, 34, 27, 38, 35, 33, 7]


def suggest(channel_cfg, titles, focus=""):
    """이번 카드뉴스 내용(focus: 영상 제목·주제·글)을 먼저 보고, 채널 이름·최근 제목을 참고해 5개 추천.
    부를 때마다 조금씩 다르게: 그 분야 사진형 3개 + 글이 또렷한 모양 2개."""
    import random
    ftxt = str(focus or "").lower()
    ctxt = " ".join([channel_cfg.get("name", ""), channel_cfg.get("style", "")] + list(titles or [])).lower()
    best, score = None, 0
    for g in GENRES:
        sc = sum(ftxt.count(k) for k in g[1]) * 5 + sum(ctxt.count(k) for k in g[1])
        if sc > score:
            best, score = g, sc
    if not best:
        best = ("두루두루", [], [17, 5, 1, 26, 18, 3, 22])
    pool = list(best[2])
    photo = random.sample(pool, min(3, len(pool)))
    clear = random.sample([n for n in CLEAR if n not in photo], 2)
    return {"genre": best[0], "nos": photo + clear}
